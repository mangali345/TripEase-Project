package com.tripease;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TripEaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
