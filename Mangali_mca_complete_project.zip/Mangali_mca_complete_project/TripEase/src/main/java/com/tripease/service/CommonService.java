package com.tripease.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tripease.model.Contact;
import com.tripease.model.Feedback;
import com.tripease.repository.CommonRepository;
import com.tripease.repository.ContactRepository;

@Service
public class CommonService
{
	//it is just like chef
	
	private ContactRepository contactRepository;
	
	@Autowired
	private CommonRepository commonRepository;
	
	
     public CommonService(ContactRepository contactRepository) {
				this.contactRepository = contactRepository;
	}


	 public String addContact (Contact contact)
     {
    	 contactRepository.save(contact); 
    	 
    	 return "Contact added successfully";
    	 
     }
	 //view feedbacks
	 public List<Feedback>fetchFeedback()
	 {
		return commonRepository.fetchFeedback();
	 }
	

}
