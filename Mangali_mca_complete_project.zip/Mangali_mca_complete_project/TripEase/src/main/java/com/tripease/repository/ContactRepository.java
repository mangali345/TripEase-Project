package com.tripease.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tripease.model.Contact;

public interface ContactRepository extends JpaRepository<Contact, Integer>
{

}
