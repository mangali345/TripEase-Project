package com.tripease.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tripease.model.Feedback;

public interface FeedbackRepository extends JpaRepository<Feedback, Integer>
 {

}
