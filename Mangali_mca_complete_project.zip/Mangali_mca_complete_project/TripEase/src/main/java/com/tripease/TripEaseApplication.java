package com.tripease;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TripEaseApplication {

	public static void main(String[] args) 
	{
		SpringApplication.run(TripEaseApplication.class, args);
//		System.out.println("Hello SpringBoot");
//		System.out.println("Hello STS");
//		System.out.println("Hello STS");
//
	}

}
