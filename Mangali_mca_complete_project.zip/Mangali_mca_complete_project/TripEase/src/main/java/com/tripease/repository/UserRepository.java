package com.tripease.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tripease.model.User;

public interface UserRepository extends JpaRepository<User, String>
{
	User findByEmail(String email);

}
