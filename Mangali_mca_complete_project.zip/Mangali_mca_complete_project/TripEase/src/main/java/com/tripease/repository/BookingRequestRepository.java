package com.tripease.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.tripease.mapper.BookingRequestMapper;
import com.tripease.model.Booking;
@Repository  
public class BookingRequestRepository 

{
	@Autowired
	JdbcTemplate jdbcTemplate;
	 public List<Booking> fetchBookingRequest(String plannerEmail)
    {
		// String sql = "SELECT b.*, t.tripname FROM booking b, trip_package t WHERE b.planner_email = t.planner_email ORDER BY b.bookingrequestdate DESC";
		  

		 String sql = "SELECT b.*, t.tripname FROM booking b JOIN trip_package t ON b.tripid = t.id WHERE b.planner_email = ? ORDER BY b.bookingrequestdate DESC";
    	List<Booking> bookingRequestList = jdbcTemplate.query(sql, new BookingRequestMapper(),plannerEmail);
        return bookingRequestList;
    }

	
}