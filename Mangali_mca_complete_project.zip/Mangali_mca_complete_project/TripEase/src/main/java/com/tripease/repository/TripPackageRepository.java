package com.tripease.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tripease.model.TripPackage;


public interface TripPackageRepository extends JpaRepository<TripPackage,Integer>

{
	public List<TripPackage>findByPlannerEmail(String plannerEmail);

}
