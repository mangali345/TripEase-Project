package com.tripease.mapper;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.tripease.model.TripPackage;

public class TripPackageMapper implements RowMapper <TripPackage>{

	//id, chargeper_person, description, destination, duration, planneremail, trip_date, tripname, trip_status
	TripPackage tripPackage=null;
	@Override
	public TripPackage mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		System.out.println(rowNum);
		String email=rs.getString("planneremail");
		String tripName=rs.getString("tripname");
		String duration=rs.getString("duration");
		Integer chargeperPerson=rs.getInt("chargeper_person");
		String destination=rs.getString("destination");
		Date tripDate=rs.getDate("trip_date");
		String tripStatus=rs.getString("trip_status");
		String description=rs.getString("description");
		tripPackage=new TripPackage(email, tripName, destination, duration,chargeperPerson, description, tripDate, tripStatus);
		tripPackage.setId(rs.getInt("id"));
		
		return tripPackage;
	}
}