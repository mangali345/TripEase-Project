package com.tripease.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.tripease.dto.TravelPlannerDTO;
import com.tripease.model.Booking;
import com.tripease.model.TravelPlanner;
import com.tripease.model.TripPackage;
import com.tripease.service.TravelPlannerService;

@RequestMapping("/travelplanner")
@RestController
@CrossOrigin("*")
public class TravelPlannerController {
	private TravelPlannerService travelplannerService;
	@Autowired
	public TravelPlannerController( TravelPlannerService travelplannerService)
	{
		this.travelplannerService=travelplannerService;
	}
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	// API for TravelPlanner password update
	@PutMapping("/updatePassword/{email}")
	public String updatePassword(@PathVariable String email,
	                             @RequestBody Map<String,String> passMap)
	{
	    String oldpass = passMap.get("oldpass");
	    String newpass = passMap.get("newpass");

	    boolean status =travelplannerService.updatePassword(email, oldpass, newpass);

	    if(status)
	    {
	        return "success";
	    }
	    else
	    {
	        return "fail";
	    }
	}
	//trip Package
	@PostMapping("/addTrip")
	public String addTrip(@RequestBody TripPackage tripPackage) {

	    System.out.println("Planner Email: " + tripPackage.getPlannerEmail());
	    System.out.println("Trip Name: " + tripPackage.getTripName());

	    travelplannerService.saveTrip(tripPackage);

	    return "Trip Added Successfully";
	}

		
	
	// API to edit travel planner profile
	@PutMapping("/editProfile/{email}")
	public ResponseEntity<TravelPlanner> editProfile(@RequestBody TravelPlanner planner, @PathVariable String email) {
	    TravelPlanner plannerObj = travelplannerService.editProfile(planner, email);

	    if (plannerObj != null) {
	        return new ResponseEntity<TravelPlanner>(plannerObj, HttpStatus.OK);
	    } else {
	        return new ResponseEntity<TravelPlanner>(HttpStatus.NOT_FOUND);
	    }
	}
	
	
	@PostMapping("/registration")
	public String registration(@RequestBody TravelPlanner registration)
	{
		System.out.println("Email is"+registration.getEmail());
		System.out.println("Password is"+registration.getPassword());
		System.out.println("Name is"+registration.getName());
		System.out.println("Company is"+registration.getCompany());
		System.out.println("Phone is"+registration.getPhone());
		System.out.println("City is"+registration.getCity());
		System.out.println("Address is"+registration.getAddress());
		System.out.println("RegistrationNo is"+registration.getRegistrationNo());
		registration.setStatus("false");
		return travelplannerService.registration(registration);
	}
	@GetMapping("/travelplannerProfile/{email}")
	public ResponseEntity<TravelPlannerDTO> travelplannerProfile(@PathVariable String email)
	{
		TravelPlanner registration=travelplannerService.getProfile(email);
		TravelPlannerDTO dto=null;
		if (registration!=null)
		{
			dto=new TravelPlannerDTO(registration.getEmail(),registration.getName(),registration.getPhone(),registration.getCompany());
			return ResponseEntity.ok(dto);
		}
		else {
			return new ResponseEntity<TravelPlannerDTO>(dto,HttpStatus.NOT_FOUND);
		}
	}
	@PostMapping("/login")
	public String login(@RequestBody TravelPlanner travelplanner) {

	    System.out.println("Email is " + travelplanner.getEmail());
	    System.out.println("Password is " + travelplanner.getPassword());

	    return travelplannerService.login(travelplanner.getEmail(), travelplanner.getPassword());
	}

	//api for imageupload
		@PostMapping("/uploadPic")
		public ResponseEntity<Map<String,String>> uploadPic2(@RequestPart("profileImageDetail")TravelPlanner travelplanner, 
				@RequestPart("imageFile")MultipartFile imageFile)
		{
			System.out.println(travelplanner.getDescription());
			System.out.println(imageFile.getOriginalFilename());
			System.out.println(imageFile.getSize());
//			userService.uploadPic1(user,imageFile);
			Map<String,String>imageMap=travelplannerService.uploadPic2(travelplanner, imageFile);
			return ResponseEntity.ok(imageMap);
			}

		
		// api to view packages to company
		@GetMapping("/viewPackages/{plannerEmail:.+}")
		public List<TripPackage> viewPackage(@PathVariable String plannerEmail)
		{
			return travelplannerService.viewPackage(plannerEmail);
			
		}
		
		//api to view packages to company
		@GetMapping("/booking-requests/{plannerEmail}")
		public List<Booking> getBookingRequests(@PathVariable String plannerEmail){
			
		    return travelplannerService.getBookingRequests(plannerEmail);
		
		}
		//accept booking
		@PutMapping("/update-booking-status/{bookingId}")
		public String updateBookingStatus(@PathVariable int bookingId, @RequestBody Map<String, String> body) {
			
			String status=body.get("bookingStatus");
			System.out.println(status);
			String pResponse="";
			if(status.equals(("Accepted")))
				
					pResponse="Your trip booking has been confirmed";
			
			if(status.equals(("Rejected")))
				
				pResponse="Your trip booking has been Rejected due to some reason";
		
				
			System.out.println(pResponse);
				
		    int rows = jdbcTemplate.update(
		        "UPDATE booking SET bookingstatus = ? ,plannerresponse=? WHERE booking_id = ?",
		        status,pResponse, bookingId
		    );
	    return rows > 0 ? "updated" : "failed";
		}
		
		//code for email existence
		  @GetMapping("/checkEmail/{email}")
		  public String checkEmail(@PathVariable String email)
		  {
			  System.out.println(email);
			  return travelplannerService.checkEmail(email);
		  }
		

}
