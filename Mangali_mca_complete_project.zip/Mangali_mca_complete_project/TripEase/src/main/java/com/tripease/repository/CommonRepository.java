package com.tripease.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.tripease.mapper.FeedbackMapper;
import com.tripease.model.Feedback;

@Repository
public class CommonRepository 
{
	//it is just like inventory
    @Autowired
	private JdbcTemplate jdbcTemplate;
    
//    public List <Feedback> fetchFeedback()
//    {
//    	String sql="select * from feedback  order by id desc limit 6";
//    	 
//    List<Feedback>feedbackList=	jdbcTemplate.query(sql, new FeedbackMapper());
//    
//              return feedbackList;
//    
//       
//    	
//    }
    public List <Feedback> fetchFeedback()
    {
    	//alias means another name of the table through which we can refer the table
    	//user table -> u
    	//feedback table-> f
    	
    	String sql="select u.name,f.rating,f.review from user u,feedback f where u.email=f.email order by f.id desc limit 10";
    	 
    List<Feedback>feedbackList=	jdbcTemplate.query(sql, new FeedbackMapper());
    
              return feedbackList;
    
       
    	
    }
   

}
