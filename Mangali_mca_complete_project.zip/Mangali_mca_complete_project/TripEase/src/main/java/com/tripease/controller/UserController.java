package com.tripease.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.tripease.dto.PasswordDTO;
import com.tripease.dto.UserDTO;
import com.tripease.model.Booking;
import com.tripease.model.Feedback;
import com.tripease.model.TravelPlanner;
import com.tripease.model.TripPackage;
import com.tripease.model.User;
import com.tripease.service.UserService;
@RequestMapping("/user")
@RestController
@CrossOrigin("*")

public class UserController {
	
	private UserService userService;
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	public UserController(UserService userService)
	{
		this.userService=userService;
		
	}
	
	// Api for all companies
		@GetMapping("/allTravelPlanner")
		public ResponseEntity<List<TravelPlanner>>allTravelPlanner()
		{
			List<TravelPlanner>companyList=userService.allTravelPLanner();
			if(companyList.size()>0)
				return ResponseEntity.ok(companyList);
			else
				return ResponseEntity.notFound().build();
		}
		

	
	
	
	
	//API for image upload
	
		@PostMapping("/uploadPic")
		public ResponseEntity<?> uploadPic1(@RequestPart("profileImageDetail")User user, 
				@RequestPart("imageFile")MultipartFile imageFile)
		{
			long maxSize=2*1024*1024;
			if(imageFile.getSize()>maxSize)
			{
				return ResponseEntity.badRequest().body("file size exceedes 2MB limit");
			}
		
		{
			System.out.println(user.getDescription());
			System.out.println(imageFile.getOriginalFilename());
			System.out.println(imageFile.getSize());
//			userService.uploadPic1(user,imageFile);
			Map<String,String>imageMap=userService.uploadPic1(user, imageFile);
			return ResponseEntity.ok(imageMap);
			}
		}
	
	
	// API for editing User profile
	@PutMapping("/editProfile/{email}")
	public ResponseEntity<User> editUserProfile(@RequestBody User user, @PathVariable String email) {
	    User userObj = userService.editProfile(user, email); 
	    if (userObj != null) {
	        return new ResponseEntity<User>(userObj, HttpStatus.OK);
	    } else {
	        return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
	    }
	}
	
	
	
	
	
	
	
	@PostMapping("/registration")
	public String registration(@RequestBody User registration) 
	{
		System.out.println("Name is"+registration.getName());
		System.out.println("Emailis"+registration.getEmail());
		System.out.println("Phone is"+registration.getPhone());
		System.out.println("Password is"+registration.getPassword());
		System.out.println("City is"+registration.getCity());
		return userService.registration(registration);

	}
	@GetMapping("/userProfile/{email}")
	public ResponseEntity<UserDTO> userProfile(@PathVariable String email)
	{
		User registration=userService.getProfile(email);
		UserDTO dto= null;
		if(registration!=null)
		{
			dto=new UserDTO(registration.getName(),registration.getPhone(),registration.getCity());
			dto.setProfilePic(registration.getProfilePic());

			
			return ResponseEntity.ok(dto);
		}
		else {
			return new ResponseEntity<UserDTO>(dto,HttpStatus.NOT_FOUND);
		}
	}
	@PatchMapping("/updatePassword/{email}")
	public String updatePassword(@RequestBody PasswordDTO pd, @PathVariable String email) {
	    String message = userService.updatePassword(pd, email);
	    return message;
	}



	@PostMapping("/feedback")
	public String feedback (@RequestBody Feedback feedback)
	{
		System.out.println("Email is"+feedback.getEmail());
		System.out.println("Review is"+feedback.getReview());
		System.out.println("Rating is"+feedback.getRating());
		return userService.feedback(feedback);
	}
	@PostMapping("/login")
	public String login(@RequestBody User user) {

	    System.out.println("Email is " + user.getEmail());
	    System.out.println("Password is " + user.getPassword());

	    return userService.login(user.getEmail(), user.getPassword());
	}
	
	// view packages
	
	@GetMapping("/showTrips/{email}")
	public List<TripPackage> showTrips(@PathVariable String email) {

		
				List<TripPackage> tp=userService.getTripsByEmail(email);
				
					for(TripPackage p:tp)
		
			
		{
				
				
				System.out.println(p.getTripName());
			}
	    return userService.getTripsByEmail(email);
	}
	//API for book trips 
	
	  @GetMapping("/bookTrip/{id}/{plannerEmail}")
	    public List<TripPackage> getTripsByID(@PathVariable String id){
		  
		  List<TripPackage> bList=userService.getTripsByID(id);
		  
		  return bList;
	    
	    }
	  //booking now
	  @PostMapping("/bookTrip")
	    public Booking bookTrip(@RequestBody Booking booking) {
	        return userService.saveBooking(booking);
	    }

	//show status to user
	  @GetMapping("/viewBooking/{userEmail}")
		
		public List<Booking>viewBooking(@PathVariable String userEmail){
			
			List <Booking> booking=userService.viewBooking(userEmail);
			
			return booking;
			
			
		}
	  //code for email existence
	  @GetMapping("/checkEmail/{email}")
	  public String checkEmail(@PathVariable String email)
	  {
		  System.out.println(email);
		  return userService.checkEmail(email);
	  }
	
}