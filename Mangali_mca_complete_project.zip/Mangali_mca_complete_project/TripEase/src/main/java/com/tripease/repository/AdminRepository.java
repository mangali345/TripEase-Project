package com.tripease.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tripease.model.Admin;

public interface AdminRepository extends JpaRepository<Admin, String>
{
	

}
