package com.tripease.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class TravelPlanner {
	@Id
	@Column(name="email",length=45,nullable=false, unique=true)
	private String email;
	
	@Column(name="password",length=45,nullable=false)
	private String password;
	
	@Column(name="name",length=45,nullable=false)
	private String name;
	
	@Column(name="company",length=100,nullable=false)
	private String company;
	
	@Column(name="phone",length=10,nullable=false)
	private String phone ;
	
	@Column(name="city",length=100,nullable=false)
	private String city;
	
	@Column(name="address",length=100,nullable=false)
	private String address;
	
	@Column(name="registrationNo",length=15,nullable=false)
	private String registrationNo;
	
	private String profilePic;
	private String description;
	private String status;
	


	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getProfilePic() {
		return profilePic;
	}

	public void setProfilePic(String profilePic) {
		this.profilePic = profilePic;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getRegistrationNo() {
		return registrationNo;
	}

	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}

	public TravelPlanner(String email, String password, String name, String company, String phone, String city,
			String address, String registrationNo) {
		super();
		this.email = email;
		this.password = password;
		this.name = name;
		this.company = company;
		this.phone = phone;
		this.city = city;
		this.address = address;
		this.registrationNo = registrationNo;
	}

	public TravelPlanner() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	

}
