package com.tripease.dto;

public class TravelPlannerDTO {
	private String email,name,phone,company;
	private String profilePic;


	public String getProfilePic() {
		return profilePic;
	}

	public void setProfilePic(String profilePic) {
		this.profilePic = profilePic;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public TravelPlannerDTO(String email, String name, String phone, String company) {
		super();
		this.email = email;
		this.name = name;
		this.phone = phone;
		this.company = company;
	}

	public TravelPlannerDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
