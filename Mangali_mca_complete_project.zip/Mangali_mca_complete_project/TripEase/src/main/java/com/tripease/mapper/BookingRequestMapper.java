package com.tripease.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.jdbc.core.RowMapper;

import com.tripease.model.Booking;
import com.tripease.model.TripPackage;


public class BookingRequestMapper implements RowMapper<Booking> {

	Booking booking=null;
	@Override
	public Booking mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		

        Integer bookingId = rs.getInt("booking_id");
        Integer tripId = rs.getInt("tripid");
        String plannerEmail = rs.getString("planner_email");
        String userEmail = rs.getString("useremail");
        String userName = rs.getString("username");
        String whatsappNo = rs.getString("whatsappno");
        Integer totalPerson = rs.getInt("totalperson");
        String userMessage = rs.getString("usermessage");
        String plannerResponse = rs.getString("plannerresponse");
        String bookingStatus = rs.getString("bookingstatus");
        Date bookingRequestdate = rs.getDate("bookingrequestdate");
        String tripName = rs.getString("tripname");
        
        booking = new Booking(bookingId,tripId,plannerEmail,userEmail,userName,whatsappNo,totalPerson,userMessage,plannerResponse,bookingStatus,bookingRequestdate);

        TripPackage tp=new TripPackage();
        tp.setTripName(tripName);
        booking.setTripPackage(tp);
		return booking;
	}
	

}