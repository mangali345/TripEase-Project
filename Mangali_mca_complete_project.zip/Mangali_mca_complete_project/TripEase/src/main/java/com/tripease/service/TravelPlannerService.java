package com.tripease.service;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;

import com.tripease.model.Booking;
import com.tripease.model.TravelPlanner;
import com.tripease.model.TripPackage;
import com.tripease.model.User;
import com.tripease.repository.BookingRequestRepository;
import com.tripease.repository.CommonRepository;
import com.tripease.repository.TravelPlannerRepository;
import com.tripease.repository.TripPackageRepository;
@Service
public class TravelPlannerService {
	private TravelPlannerRepository travelplannerRepository;
	@Autowired
	private TripPackageRepository tripPackageRepository;
	@Autowired
	private CommonRepository commonRepository;
	
	//trip package
	public void saveTrip(TripPackage tripPackage) {

	    System.out.println("Saving Trip Data...");

	   	    tripPackageRepository.save(tripPackage);
	}	
	
	
	@Autowired
	public TravelPlannerService(TravelPlannerRepository travelplannerRepository)
	{
		this.travelplannerRepository= travelplannerRepository;
	}
	public TravelPlanner getProfile(String email)
	{
		Optional<TravelPlanner> opt= travelplannerRepository.findById(email);
		return opt.orElse(null);
		
	}
	 public String registration (TravelPlanner travelplanner) {
	    	
	    	Optional<TravelPlanner> opt=travelplannerRepository.findById(travelplanner.getEmail());
	    	if (opt.isPresent())
	    	{
	    		return "Travel Planner already exists";
	    	}
	    	
	        travelplannerRepository.save(travelplanner); 
	        return "Travel Planner registered successfully";
	    }
	//planner login
	public String login (String email,String password) {
		TravelPlanner existingTravelPlanner= travelplannerRepository.findByEmail(email);
		if (existingTravelPlanner==null)
		{
			return "Travel Planner not found!";
		}
		String status=existingTravelPlanner.getStatus();
		if (existingTravelPlanner.getPassword().equals(password)&& status.equals("true"))
		{
			return "Login Successful";
		}
		else {
			return "Invalid Password/Unauthorised access";
		}
	}
	
	
	public Map<String,String>uploadPic2(TravelPlanner travelplanner, MultipartFile imageFile) 
	{
		String fileName=imageFile.getOriginalFilename();
		long timeStamp=System.currentTimeMillis()%100000000;
		System.out.println(timeStamp);
		String uniqueFileName=timeStamp+"_"+fileName;
		//GO TO ROOT DIRECTORY
		String projectRoot=System.getProperty("user.dir");
		System.out.println("project root is"+projectRoot);
		
		//reach to upload directory
		String uploadDir = projectRoot+"/uploads/tpprofileimages";
		Map<String,String>imageMap=new HashMap<>();
		try {
			//setting the target folder for image upload with image name
			File targetFile=new File(uploadDir,uniqueFileName);
			imageFile.transferTo(targetFile);
			//generating image URL
			String IMAGEURL="http://localhost:9090/uploads/tpprofileimages/"+uniqueFileName;
			
			String email=travelplanner.getEmail();//coming from react
			Optional<TravelPlanner> opt =travelplannerRepository.findById(email);
			if(opt.isPresent())
			{
				TravelPlanner ad=opt.get();
				String desc=travelplanner.getDescription();//coming from react
				//update user profile image with description
				ad.setProfilePic(uniqueFileName);
				ad.setDescription(desc);
				travelplannerRepository.save(ad);
				
				imageMap.put("imageURL",IMAGEURL);
				imageMap.put("email",email);
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("image upload failed");
		}
		return imageMap;

}
	// Service method to edit Travel Planner profile
	public TravelPlanner editProfile(TravelPlanner modifiedPlanner, String email) {

	    TravelPlanner planner = travelplannerRepository.findByEmail(email);

	    if (planner != null) {
	        planner.setName(modifiedPlanner.getName());
	        planner.setPhone(modifiedPlanner.getPhone());
	        planner.setCity(modifiedPlanner.getCity());
	        planner.setAddress(modifiedPlanner.getAddress());

	        travelplannerRepository.save(planner);
	    }

	    return planner;
	}
	// Method for TravelPlanner password updation
	public boolean updatePassword(String email, String oldpass, String newpass)
	{
	    Optional<TravelPlanner> opt = travelplannerRepository.findById(email);

	    if(opt.isPresent())
	    {
	        TravelPlanner travelplanner = opt.get();

	        if(travelplanner.getPassword().equals(oldpass))
	        {
	            travelplanner.setPassword(newpass);

	            travelplannerRepository.save(travelplanner);

	            return true;
	        }
	    }

	    return false;
	}
	// view packages
	
	public List<TripPackage>viewPackage(String plannerEmail)
	{
		List<TripPackage>tripList=tripPackageRepository.findByPlannerEmail(plannerEmail);
		return tripList;
	}
	//booking request
	@Autowired
	private BookingRequestRepository bookingRequestRepository;

	public List<Booking> getBookingRequests(String plannerEmail){
	    List<Booking> list = bookingRequestRepository.fetchBookingRequest(plannerEmail);
	    return (list != null) ? list : new ArrayList<>();
	}
	
	
	 public String checkEmail(String email)
		{
	    	String status="";
			Optional<TravelPlanner>opt=travelplannerRepository.findById(email);
			if(opt.isPresent())
			{
				
				status="exists";
			}
			return status;
		}
}	


