package com.tripease.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.tripease.model.Feedback;
import com.tripease.model.User;

public class FeedbackMapper implements RowMapper<Feedback>
{
	
    Feedback feedback=null;
	@Override
	public Feedback mapRow(ResultSet rs, int rowNum) throws SQLException {
		//fetching data using single table
//		   System.out.println(rowNum);
//		   //variable name
//		   String email=rs.getString("email"); //column name
//		   String rating=rs.getString("rating");
//		   String review=rs.getString("review");
//		   
//		   //creating object of feedback class
//		   feedback=new Feedback(email, review, rating);
//		
//		
		
		
		//fetching data from user and feedback table
		
		String rating=rs.getString("rating");
		String review=rs.getString("review");
		
		String userName=rs.getString("name");
		//user has a name
		//feedback has user
		
		//user class object creation
		User u=new User();
		u.setName(userName);
		
		feedback =new Feedback();
		feedback.setRating(rating);
		feedback.setReview(review);
		feedback.setUser(u);
				return feedback;
	}

}
