package com.tripease.dto;

public class AdminDTO //it is a subset of the model or entity
{
	private String name,phone;
	private String profilePic;
	

	public String getProfilePic() {
		return profilePic;
	}

	public void setProfilePic(String profilePic) {
		this.profilePic = profilePic;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public AdminDTO(String name, String phone) {
		super();
		this.name = name;
		this.phone = phone;
	}

	public AdminDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
