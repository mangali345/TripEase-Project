package com.tripease.service;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.tripease.dto.PasswordDTO;
import com.tripease.model.Admin;
import com.tripease.model.Contact;
import com.tripease.model.TravelPlanner;
import com.tripease.repository.AdminRepository;
import com.tripease.repository.ContactRepository;
import com.tripease.repository.TravelPlannerRepository;

@Service
public class AdminService 
{   
	@Autowired
	private AdminRepository adminRepository;
	@Autowired
	private TravelPlannerRepository travelPlannerRepository;
	@Autowired
	private ContactRepository contactRepository;
	
	//method for delete contact
	public void deleteContact(Integer id)
	{
		 contactRepository.deleteById(id);
		
	}
		
	
	
	//method for all contacts
	
	public List<Contact> allContacts()//to study list and array list
	{
	  return contactRepository.findAll();//select * from contact
	}
	
	
	
	
	
	
	public Admin getProfile(String email)
	{
		Optional<Admin>opt= adminRepository.findById(email);
		Admin admin=null;
		if(opt.isPresent())
		{
			admin= opt.get();
		}
		return admin;
		
	}
	
	
	
	
	//select * from admin where email=admin.getEmail() and password=admin.getPassword()
	public String admin(Admin admin)
	{
		String email=admin.getEmail();
		String password=admin.getPassword();
		
		Optional <Admin>opt=adminRepository.findById(email);
		String message="";
		if(opt.isPresent())
		{
			Admin ad= opt.get();//fetch the value from the container(optional)
			
			if (ad.getPassword().equals(password))
				message ="success";
			else
				message="Invalid password";
		}
		else {
			message= "Invalid Email";
		}
		return message;
	}
	
	//method for password updation
	public String updatePassword(PasswordDTO pd, String email) {
	    Optional<Admin> opt = adminRepository.findById(email);
	    String status = "error"; // default

	    if(opt.isPresent()) {
	        Admin ad = opt.get();

	        // Check old password exactly as is
	        if(ad.getPassword().equals(pd.getOldpass())) {
	            // Update with new password
	            ad.setPassword(pd.getNewpass());
	            adminRepository.save(ad);
	            status = "success";
	        }
	    }

	    return status;
	}
	
	
	
	//method for editprofile
	
		public Admin editProfile(Admin modifiedAdminObject,String email)
		{
	Optional<Admin>opt=		adminRepository.findById(email);
	Admin ad=null;
	if(opt.isPresent())
	{
	ad=opt.get();//fetch admin object based on email
	//overwrite old data with modified values
	String modifiedName=modifiedAdminObject.getName();
	String modifiedPhone=modifiedAdminObject.getPhone();
	//String modifiedPassword=modifiedAdminObject.getPassword();

	ad.setName(modifiedName);
	ad.setPhone(modifiedPhone);
	//ad.setPassword(modifiedPassword);
	adminRepository.save(ad);

	}
	return ad;
			
			
		}

		
		public Map<String,String> uploadPic(Admin admin, MultipartFile imageFile)
		{
			String fileName=imageFile.getOriginalFilename();
			long timeStamp= System.currentTimeMillis()%100000000;
			System.out.println(timeStamp);
			
			String uniqueFileName=timeStamp+"_"+fileName;
			//Go to root directory
			String projectRoot=System.getProperty("user.dir");
			System.out.println("project root is"+projectRoot);
			
			//reach to upload directory
			String uploadDir=projectRoot+"/uploads/profileimages/";
			Map<String,String>imageMap=new HashMap<>();

			
			try {
				
				//setting the target folder for image upload with image name
				File targetFile=new File(uploadDir,uniqueFileName);
				imageFile.transferTo(targetFile);
				
				//generating image url
				String IMAGEURL="http://localhost:9090/uploads/profileimages/"+uniqueFileName;
				
				  String email=admin.getEmail();//coming from react
				Optional<Admin>opt=  adminRepository.findById(email);
						if(opt.isPresent())
						{
							Admin ad=opt.get();
							String desc=admin.getDescription();//coming from react
							
							//update admin profile image with description
							ad.setProfilePic(uniqueFileName);
							ad.setDescription(desc);
							adminRepository.save( ad);
							imageMap.put("imageURL", IMAGEURL);
							imageMap.put("email", email);
							
							
							
						}
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("Image upload failed");
			}
			
			return imageMap;
		}

//approval
		public String authenticatePlanner(String email) {
			
			
			
			TravelPlanner tp=travelPlannerRepository.findByEmail(email);
			
				tp.setStatus("true");
				
				travelPlannerRepository.save(tp);
					
					
					return "success";
				}
		

}
