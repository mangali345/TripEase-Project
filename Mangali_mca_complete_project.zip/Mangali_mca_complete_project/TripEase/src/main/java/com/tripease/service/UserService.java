package com.tripease.service;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.tripease.dto.PasswordDTO;
import com.tripease.model.Booking;
import com.tripease.model.Feedback;
import com.tripease.model.TravelPlanner;
import com.tripease.model.TripPackage;
import com.tripease.model.User;
import com.tripease.repository.BookingRepository;
import com.tripease.repository.FeedbackRepository;
import com.tripease.repository.TravelPlannerRepository;
import com.tripease.repository.UserRepository;
import com.tripease.repository.UserTripRepository;

@Service
public class UserService {
     
	@Autowired
    private UserRepository userRepository;  
	@Autowired
    private FeedbackRepository feedbackRepository;
	@Autowired
	private UserTripRepository userTripRepository;
	@Autowired
	private BookingRepository bookingRepository;
	
	// method for password updation for User
	public String updatePassword(PasswordDTO pd, String email) {
	    Optional<User> opt = userRepository.findById(email);
	    String status = "error"; // default

	    if (opt.isPresent()) {
	        User user = opt.get();

	        // Check old password exactly as is
	        if (user.getPassword().equals(pd.getOldpass())) {
	            // Update with new password
	            user.setPassword(pd.getNewpass());
	            userRepository.save(user);
	            status = "success";
	        }
	    }

	    return status;
	}
	
	// Service method to edit User profile
	public User editProfile(User modifiedUserObject, String email) {
	    Optional<User> opt = userRepository.findById(email); // find user by email
	    User user = null;

	    if (opt.isPresent()) {
	        user = opt.get(); // fetch user object based on email

	        // overwrite old data with modified values
	        String modifiedName = modifiedUserObject.getName();
	        String modifiedPhone = modifiedUserObject.getPhone();
	        // String modifiedPassword = modifiedUserObject.getPassword(); // optional

	        user.setName(modifiedName);
	        user.setPhone(modifiedPhone);
	        // user.setPassword(modifiedPassword); // uncomment if you want to allow password update

	        userRepository.save(user); // save updated user
	    }

	    return user; // returns null if user not found
	}
	
	
	//Api for companies
	@Autowired
	 private TravelPlannerRepository travelPlannerRepository;
	 //method for all companies
	 public List<TravelPlanner> allTravelPLanner()
	 {
		 return travelPlannerRepository.findAll();
	 }
	
	
	
	
	
    //method for delete feedback
    public void deleteFeedback(Integer id)
	{
		 feedbackRepository.deleteById(id);
	}
		

    
    public UserService(UserRepository userRepository, FeedbackRepository feedbackRepository)
    {
        this.userRepository = userRepository;
        this.feedbackRepository= feedbackRepository;
    }
    
    public User getProfile(String email)
    {
    	Optional<User> opt= userRepository.findById(email);
    	return opt.orElse(null);
    }

   
    public String registration (User user) {
    	
    	Optional<User> opt=userRepository.findById(user.getEmail());
    	if (opt.isPresent())
    	{
    		return "User already exists";
    	}
    	
        userRepository.save(user); 
        return "User registered successfully";
    }
    // i am working here
    public List<User> allUsers() {
        return userRepository.findAll();
    }

    public String feedback (Feedback feedback) {
        feedbackRepository.save(feedback); 
        return "Feedback given by user";
    }
    // i m working here
    public List<Feedback> allFeedbacks() {
        return feedbackRepository.findAll();
    }
    public String login(String email, String password) {

        User existingUser = userRepository.findByEmail(email);

        if (existingUser == null) {
            return "User not found!";
        }

        if (existingUser.getPassword().equals(password)) {
            return "Login Successful";
        }
        else {
            return "Invalid Password!";
        }
    }
    
    
    public Map<String,String> uploadPic1(User user, MultipartFile imageFile)
	{
		String fileName=imageFile.getOriginalFilename();
		long timeStamp= System.currentTimeMillis()%100000000;
		System.out.println(timeStamp);
		
		String uniqueFileName=timeStamp+"_"+fileName;
		//Go to root directory
		String projectRoot=System.getProperty("user.dir");
		System.out.println("project root is"+projectRoot);
		
		//reach to upload directory
		String uploadDir=projectRoot+"/uploads/userprofileimages/";
		Map<String,String>imageMap=new HashMap<>();

		
		try {
			
			//setting the target folder for image upload with image name
			File targetFile=new File(uploadDir,uniqueFileName);
			imageFile.transferTo(targetFile);
			
			//generating image url
			String IMAGEURL="http://localhost:9090/uploads/userprofileimages/"+uniqueFileName;
			
			  String email=user.getEmail();//coming from react
			Optional<User>opt=  userRepository.findById(email);
					if(opt.isPresent())
					{
						User ad=opt.get();
						String desc=user.getDescription();//coming from react
						
						//update admin profile image with description
						ad.setProfilePic(uniqueFileName);
						ad.setDescription(desc);
						userRepository.save( ad);
						imageMap.put("imageURL", IMAGEURL);
						imageMap.put("email", email);
						
						
						
					}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println("Image upload failed");
		}
		
		return imageMap;
	}
    
  //Show Trips
	
  	public List<TripPackage> getTripsByEmail(String email) {
  	    return userTripRepository.getTrips(email);
  	}
  //Booking trips
	
  	public List<TripPackage> getTripsByID(String id){
  		
  		return userTripRepository.getTrips(id);
  		
  	}
  	
 // Save booking
    public Booking saveBooking(Booking booking) {
        return bookingRepository.save(booking);
    }
    
 //show status to user
    public List<Booking> viewBooking(String userEmail){
		
    	List<Booking> bList=bookingRepository.findByUserEmail(userEmail);
    	
    	return bList;
    		
    	}
    public String checkEmail(String email)
	{
    	String status="";
		Optional<User>opt=userRepository.findById(email);
		if(opt.isPresent())
		{
			
			status="exists";
		}
		return status;
	}

    

}