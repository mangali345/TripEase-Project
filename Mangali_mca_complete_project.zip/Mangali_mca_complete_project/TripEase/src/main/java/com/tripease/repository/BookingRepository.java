package com.tripease.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tripease.model.Booking;

public interface BookingRepository extends JpaRepository<Booking, Integer> {
	List<Booking> findByplannerEmail(String plannerEmail);
	List<Booking> findByUserEmail(String userEmail);
	}

