package com.tripease.model;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Transient;
@Entity
public class Booking {
	@Transient 
	private TripPackage tripPackage;
    public TripPackage getTripPackage() {
		return tripPackage;
	}
	public void setTripPackage(TripPackage tripPackage) {
		this.tripPackage = tripPackage;
	}
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer bookingId;
    @Column(name = "tripid", length = 45, nullable = false)
	private Integer tripId;
    @Column(name = "planner_email", length = 45, nullable = false)
	private String plannerEmail;
    @Column(name = "useremail", length = 45, nullable = false)
	private String userEmail;
    @Column(name = "username", length = 45, nullable = false)
	private String userName;
    @Column(name = "whatsappno", length = 45, nullable = false)
	private String whatsappNo;
    @Column(name = "totalperson", length = 45, nullable = false)
	private int totalPerson;
    @Column(name = "usermessage", length = 45, nullable = false)
	private String userMessage;
    @Column(name = "plannerresponse", length = 225, nullable = false)
	private String plannerResponse;
    @Column(name = "bookingstatus", length = 45, nullable = false)
	private String bookingStatus ="pending";
    @Column(name="bookingrequestdate", nullable=false)
    private Date bookingRequestDate;
	public Integer getBookingId() {
		return bookingId;
	}
	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}
	public Integer getTripId() {
		return tripId;
	}
	public void setTripId(Integer tripId) {
		this.tripId = tripId;
	}
	public String getPlannerEmail() {
		return plannerEmail;
	}
	public void setPlannerEmail(String plannerEmail) {
		this.plannerEmail = plannerEmail;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getWhatsappNo() {
		return whatsappNo;
	}
	public void setWhatsappNo(String whatsappNo) {
		this.whatsappNo = whatsappNo;
	}
	public Integer getTotalPerson() {
		return totalPerson;
	}
	public void setTotalPerson(Integer totalPerson) {
		this.totalPerson = totalPerson;
	}
	public String getUserMessage() {
		return userMessage;
	}
	public void setUserMessage(String userMessage) {
		this.userMessage = userMessage;
	}
	public String getPlannerResponse() {
		return plannerResponse;
	}
	public void setPlannerResponse(String plannerResponse) {
		this.plannerResponse = plannerResponse;
	}
	public String getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	public Date getBookingRequestDate() {
		return bookingRequestDate;
	}
	public void setBookingRequestDate(Date bookingRequestDate) {
		this.bookingRequestDate = bookingRequestDate;
	}
	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Booking(Integer bookingId, Integer tripId, String plannerEmail, String userEmail, String userName, String whatsappNo,
			Integer totalPerson, String userMessage, String plannerResponse, String bookingStatus,
			Date bookingRequestDate) {
		super();
		this.bookingId = bookingId;
		this.tripId = tripId;
		this.plannerEmail = plannerEmail;
		 this.userEmail = userEmail;
		this.userName = userName;
		this.whatsappNo = whatsappNo;
		this.totalPerson = totalPerson;
		this.userMessage = userMessage;
		this.plannerResponse = plannerResponse;
		this.bookingStatus = bookingStatus;
		this.bookingRequestDate = bookingRequestDate;
	}
    
    
	
	

}