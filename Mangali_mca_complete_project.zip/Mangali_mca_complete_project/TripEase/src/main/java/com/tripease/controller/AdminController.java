package com.tripease.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.tripease.dto.AdminDTO;
import com.tripease.dto.PasswordDTO;
import com.tripease.model.Admin;
import com.tripease.model.Contact;
import com.tripease.model.Feedback;
import com.tripease.model.User;
import com.tripease.service.AdminService;
import com.tripease.service.UserService;
@RequestMapping("/admin")
@RestController
@CrossOrigin("*")
public class AdminController {
	private AdminService adminService;
	private UserService userService;
	@Autowired
	public AdminController(AdminService adminService ,UserService userService)
	{
		this.adminService=adminService;
		this.userService=userService;
	}
	
	//api for delete contact
	@DeleteMapping("/deleteContact/{id}")
	public ResponseEntity<String> deleteContact(@PathVariable Integer id)
	{
		adminService.deleteContact(id);
	
	return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
	
	}
	//API for delete feedback
	@DeleteMapping("/deleteFeedback/{id}")
	public ResponseEntity<String> deleteFeedback(@PathVariable Integer id)
	{
		adminService.deleteContact(id);
	
	return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
	
	}
	
	
	
	//api for update password
	
	@PatchMapping("/updatePassword/{email}")
	public String updatePassword(@RequestBody PasswordDTO pd,@PathVariable String email)
	{
		String message= adminService.updatePassword(pd, email);
		return message;
	}
	
	//API for image upload
	@PostMapping("/uploadPic")
	public ResponseEntity<Map<String,String>> uploadPic(@RequestPart("profileImageDetail")Admin admin,@RequestPart("imageFile")MultipartFile imageFile)
	{
		System.out.println(admin.getDescription());
		System.out.println(imageFile.getOriginalFilename());
		System.out.println(imageFile.getSize());
		  
		Map<String,String>imageMap=   adminService.uploadPic(admin,imageFile);
		
		return ResponseEntity.ok(imageMap);
		
	}
	
	
	
	
	
	
	//  api for edit profile
	
@PutMapping("/editProfile/{email}")
	
	public ResponseEntity<Admin>editProfile(@RequestBody Admin admin,@PathVariable String email)
	{
		Admin adminObj=adminService.editProfile(admin, email);
		if(adminObj!=null)
		return new ResponseEntity<Admin>(adminObj,HttpStatus.OK);
		
		else
		return new ResponseEntity<Admin>(HttpStatus.NOT_FOUND);	
		
	}
	
	
	
	// API for all Contacts
	@GetMapping("/allContacts")
	
	public ResponseEntity<List<Contact>> allContacts()
	{
		List<Contact>contactList= adminService.allContacts();
		if(contactList.size()>0)
			return ResponseEntity.ok(contactList);
		else
			return ResponseEntity.notFound().build();
			
	}
	// work here.......
	// API for all Users
		@GetMapping("/allUsers")
		public ResponseEntity<List<User>> allUsers() {

		    List<User> userList = userService.allUsers();

		    if (userList.size() > 0)
		        return ResponseEntity.ok(userList);
		    else
		        return ResponseEntity.notFound().build();
		}


		// API for all Feedbacks
		@GetMapping("/allFeedbacks")
		public ResponseEntity<List<Feedback>> allFeedbacks() {

		    List<Feedback> feedbackList = userService.allFeedbacks();

		    if (feedbackList.size() > 0)
		        return ResponseEntity.ok(feedbackList);
		    else
		        return ResponseEntity.notFound().build();
		}
		

	
	
	
	
	@PostMapping("/login")

		public String admin(@RequestBody Admin admin)
		{
//		System.out.println("Email is"+admin.getEmail());
//		System.out.println("Password is"+admin.getPassword());
		    return adminService.admin(admin);
		}
	
	   @GetMapping("/adminProfile/{email}") //value received from react
	   public ResponseEntity<AdminDTO> adminprofile(@PathVariable String email)
	   {
		   Admin admin = adminService.getProfile(email);
		   
		   AdminDTO dto=null;
		   
		   if(admin!=null)
		   {
			   //creating object of dto
//			   String name=admin.getName();
//			   String name=admin.getPhone();
//			   dto=new AdminDTO(name,phone);

			   
			   
			   dto=new AdminDTO(admin.getName(),admin.getPhone());
			   
			   dto.setProfilePic(admin.getProfilePic());
			   
			   return ResponseEntity.ok(dto);
		   }
		   else {
			   return new ResponseEntity<AdminDTO>(dto,HttpStatus.NOT_FOUND);
		   }
	   }
	   //approval
	   @PutMapping("/authenticatePlanner/{email}")
		
		public String authenticatePlanner(@PathVariable String email)
		{
			
			
			return adminService.authenticatePlanner(email);
		}
	}


