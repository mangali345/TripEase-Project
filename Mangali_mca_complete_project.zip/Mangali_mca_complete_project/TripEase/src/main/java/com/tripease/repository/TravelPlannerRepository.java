package com.tripease.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tripease.model.TravelPlanner;

public interface TravelPlannerRepository  extends JpaRepository<TravelPlanner, String>
{
	TravelPlanner findByEmail(String email);

}
