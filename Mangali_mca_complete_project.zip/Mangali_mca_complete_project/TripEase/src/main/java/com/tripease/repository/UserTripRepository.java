package com.tripease.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.tripease.mapper.TripPackageMapper;
import com.tripease.model.TripPackage;

@Repository
public class UserTripRepository {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<TripPackage> getTrips(String email) {

	    String sql = "SELECT * FROM trip_package WHERE planneremail = ?";

	    return jdbcTemplate.query(sql, new TripPackageMapper(), email);
	}

}