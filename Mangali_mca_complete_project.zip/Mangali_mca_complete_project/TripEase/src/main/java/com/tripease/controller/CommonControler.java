package com.tripease.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tripease.model.Contact;
import com.tripease.model.Feedback;
import com.tripease.service.CommonService;

@RestController
//@RequestMapping("/common")
//@CrossOrigin({"http://localhost:5173"})
@CrossOrigin("*")

public class CommonControler
{
	//request and response both are accept and given by controller
	// waiter is just like controller
	private CommonService commonService;
	
	
	@Autowired
	public CommonControler(CommonService commonService) {
		super();
		this.commonService = commonService;
	}



	@PostMapping("/addContact")
	public String addContact(@RequestBody Contact contact) 
	{ 
//		System.out.println("Name is"+contact.getName());
//		System.out.println("Email is"+contact.getEmail());
//		System.out.println("Phone is"+contact.getPhone());
//		System.out.println("Question is"+contact.getQuestion());
//
		return commonService.addContact(contact);
		
	}
	
	//view all feedback
	@GetMapping("/fetchFeedback")
    public ResponseEntity<List<Feedback>>fetchFeedback()
	{
		List<Feedback>fList= commonService.fetchFeedback();
		
		System.out.println(fList);
		return ResponseEntity.ok(fList);
	}
	

}
