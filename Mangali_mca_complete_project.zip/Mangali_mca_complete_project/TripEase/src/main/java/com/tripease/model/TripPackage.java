package com.tripease.model;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity

public class TripPackage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    public TripPackage() {
    }


    @Column(name = "planneremail", length = 45)
    private String plannerEmail;

    @Column(name = "tripname", length = 45, nullable = false)
    private String tripName;

    @Column(name = "destination", length = 45, nullable = false)
    private String destination;

    @Column(name = "duration", length = 45, nullable = false)
    private String duration;

    
    @Column(name = "chargeper_person", nullable = false)
    private int chargeperPerson;

    @Column(name = "description", length = 100, nullable = false)
    private String description;
    @JsonFormat(pattern="yyyy-MM-dd")
    @Column(name = "trip_date", nullable = false)
    private Date tripDate;

    
    @Column(name = "trip_status", length = 45, nullable = false)
    private String tripStatus="active";


    public TripPackage(String plannerEmail, String tripName, String destination, String duration,
                       int chargeperPerson, String description, Date tripDate, String tripStatus) {
        this.plannerEmail = plannerEmail;
        this.tripName = tripName;
        this.destination = destination;
        this.duration = duration;
        this.chargeperPerson = chargeperPerson;
        this.description = description;
        this.tripDate = tripDate;
        this.tripStatus = (tripStatus == null || tripStatus.isEmpty()) ? "active" : tripStatus;
        
    }

    // Getters & Setters

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    

    public String getPlannerEmail() { return plannerEmail; }
    public void setPlannerEmail(String plannerEmail) { this.plannerEmail = plannerEmail; }

    public String getTripName() { return tripName; }
    public void setTripName(String tripName) { this.tripName = tripName; }

    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }

    public String getDuration() { return duration; }
    public void setDuration(String duration) { this.duration = duration; }

    public int getChargeperPerson() { return chargeperPerson; }
    public void setChargeperPerson(int chargeperPerson) { this.chargeperPerson = chargeperPerson; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Date getTripDate() { return tripDate; }
    public void setTripDate(Date tripDate) { this.tripDate = tripDate; }

    public String getTripStatus() { return tripStatus; }
    public void setTripStatus(String tripStatus) { this.tripStatus = tripStatus; }
}