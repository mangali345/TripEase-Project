import React from "react"
import { BrowserRouter,Routes,Route } from "react-router-dom"
import App from "./App.jsx"
import AboutUs from "./components/common/AboutUs.jsx"
import ContactUs from "./components/common/ContactUs.jsx"
import AdminLogin from "./components/admin/AdminLogin.jsx"
import User from "./components/user/User.jsx"
import UserReg from "./components/user/UserReg.jsx"
import Feedback from "./components/user/Feedback.jsx"
import AdminDashBoard from "./components/admin/AdminDashBoard.jsx"
import UserDashBoard from "./components/user/UserDashBoard.jsx"
import AllContacts from "./components/admin/AllContacts.jsx"
import AllUsers from "./components/admin/AllUsers.jsx"
import AllFeedback from "./components/admin/AllFeedback.jsx"
import TravelPlannerLogin from "./components/company/TravelPlannerLogin.jsx"
import TravelPlannerReg from "./components/company/TravelPlannerReg.jsx"
import TravelPlannerHeader from "./components/company/TravelPlannerHeader.jsx"
import TravelPlannerHome from "./components/company/TravelPlannerHome.jsx"
import AdminEditProfile from "./components/admin/AdminEditProfile.jsx"
import UserEditProfile from "./components/user/UserEditProfile.jsx"
import TpEditProfile from "./components/company/TpEditProfile.jsx"
import ChangeAdminPassword from "./components/admin/ChangeAdminPassword.jsx"
import ChangeUserPassword from "./components/user/ChangeUserPassword.jsx"
import ChangeTpPassword from "./components/company/ChangeTpPassword.jsx"
import ProfileUpload from "./components/admin/ProfileUpload.jsx"
import UserProfileUpload from "./components/user/UserProfileUpload.jsx"
import TpProfileUpload from "./components/company/TpProfileUpload.jsx"
import FetchFeedback from "./components/common/FetchFeedback.jsx"
import AllTravelPlanner from "./components/user/AllTravelPlanner.jsx"
import RoutePlannerPage from "./components/common/RoutePlannerPage.jsx"
import UserRoutePlannerPage from "./components/user/UserRoutePlannerPage.jsx"
import TripPackage from "./components/company/TripPackage.jsx"
import TripDetails from "./components/user/TripDetails.jsx"
import CityPlaces from "./components/common/CityPlaces.jsx"
import MyTrip from "./components/company/MyTrip.jsx"
import BookTrips from "./components/user/BookTrips.jsx"
import BookingRequest from "./components/company/BookingRequest.jsx"
import BookingtripStatus from "./components/user/BookingtripStatus.jsx"
import AllCompany from "./components/admin/AllCompany.jsx"
import Help from "./components/common/Help.jsx"
import VideoGuide from "./components/common/VideoGuide.jsx"


function PathMapper() 
{
    return(

        <>
        <BrowserRouter>
        <Routes>
            <Route path="/" element={<App/>}></Route>
            <Route path="/about" element={<AboutUs/>}></Route>
            <Route path="/contact" element={<ContactUs/>}></Route>
            <Route path="login/user" element={<User/>}></Route>
            <Route path="login/company" element={<TravelPlannerLogin/>}></Route>
            <Route path="/feed" element={<Feedback/>}></Route>
            <Route path="register/user" element={<UserReg/>}></Route>
            <Route path="register/company" element={<TravelPlannerReg/>}></Route>
            <Route path="/admin" element={<AdminLogin/>}></Route>
            <Route path="/admindashboard" element={<AdminDashBoard/>}></Route>
            <Route path="/userdashboard" element={<UserDashBoard/>}></Route>
            <Route path="/travelplannerhome" element={<TravelPlannerHome/>}></Route>
            <Route path="/allContacts" element={<AllContacts/>}></Route>
            <Route path="/allusers" element={<AllUsers/>}></Route>
            <Route path="/allfeedback" element={<AllFeedback/>}></Route>
            <Route path="/alltp" element={<AllTravelPlanner/>}></Route>
            <Route path="/head" element={<TravelPlannerHeader/>}></Route>
            <Route path="/adminedit" element={<AdminEditProfile/>}></Route>
            <Route path="/useredit" element={<UserEditProfile/>}></Route>
            <Route path="/tpedit" element={<TpEditProfile/>}></Route>
            <Route path="/changepass" element={<ChangeAdminPassword/>}></Route>
            <Route path="/changeupass" element={<ChangeUserPassword/>}></Route>
            <Route path="/changetppass" element={<ChangeTpPassword/>}></Route>
            <Route path="/imageupload" element={<ProfileUpload/>}></Route>
            <Route path="/uimageupload" element={<UserProfileUpload/>}></Route>
            <Route path="/tpimageupload" element={<TpProfileUpload/>}></Route>
            <Route path="/fetchfeed" element={<FetchFeedback/>}></Route>
            <Route path="/routepp" element={<RoutePlannerPage/>}></Route>
            <Route path="/userroutepp" element={<UserRoutePlannerPage/>}></Route>
            <Route path="/trippack" element={<TripPackage/>}></Route>
            <Route path="/tripDetails/:emailId" element={<TripDetails/>}></Route>
            <Route path="/city" element={<CityPlaces/>}></Route>
            <Route path="/mytrip" element={<MyTrip/>}></Route>
            <Route path="/bookTrips/:tripId/:plannerEmail" element={<BookTrips/>}></Route>
            <Route path="/request" element={<BookingRequest/>}></Route>
            <Route path="/status" element={<BookingtripStatus/>}></Route>
            <Route path="/allplanner" element={<AllCompany/>}></Route>
            <Route path="/help" element={<Help/>}></Route>
            <Route path="/video" element={<VideoGuide/>}></Route>
           
            
        </Routes>
        </BrowserRouter>
        </>
    )
}
export default PathMapper