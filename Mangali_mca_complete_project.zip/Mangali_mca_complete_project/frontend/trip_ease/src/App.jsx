import { useEffect, useState } from "react"
import Footer from "./components/common/Footer"
import Header from "./components/common/Header"

function App() {

  const banners = ["/t1.jpg", "/t2.jpg", "/t4.jpg"]

  const allPlaces = [
    { img: "https://cdn.britannica.com/26/84526-050-45452C37/Gateway-monument-India-entrance-Mumbai-Harbour-coast.jpg", title: "Mumbai", category: "Beach" },
    { img: "https://hblimg.mmtcdn.com/content/hubble/img/desttvimg/mmt/destination/m_Rishikesh_tv_destination_img_2_l_664_996.jpg", title: "Rishikesh", category: "Mountains" },
    { img: "https://images.travelandleisureasia.com/wp-content/uploads/sites/2/2025/04/22095901/EvergreenFeatured-2025-04-22T095848.327-1600x900.jpg", title: "Haridwar", category: "Mountains" },
    { img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQeXtB2-MLZaRUlv0QSt8SzbTs49VUqdXW2GA&s", title: "Delhi", category: "City" },
    { img: "https://img.staticmb.com/mbcontent/images/crop/uploads/2025/3/up-lucknow-guide_0_1200.jpg.webp", title: "Lucknow", category: "City" },
    { img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT9S9n5iJKkIdJFwptP5SbYpbtc2TBf_t__qA&s", title: "Kanpur", category: "City" },
    { img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTzPjjYGtpOHQbW_IeKHHgPOMVw3OtpkBvUqA&s", title: "Varanasi", category: "Spiritual" },
    { img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTomol09EkDfn4Hsw-3Tx0-Iqvp2Lm66hAU_A&s", title: "Ayodhya", category: "Spiritual" },
    { img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQkBOz_kqE1W6z-aOFKADfSlsMaGHTm8pp2oA&s", title: "Agra", category: "Heritage" },
    { img: "https://s7ap1.scene7.com/is/image/incredibleindia/hawa-mahal-jaipur-rajasthan-city-1-hero?qlt=82&ts=1742200253577", title: "Jaipur", category: "Heritage" }
  ]

  const [places, setPlaces] = useState(allPlaces)
  const [current, setCurrent] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % banners.length)
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  const filterCategory = (cat) => {
    if (cat === "All") setPlaces(allPlaces)
    else setPlaces(allPlaces.filter((p) => p.category === cat))
  }

  const btnBase = {
    padding: "10px 18px",
    borderRadius: "30px",
    cursor: "pointer",
    fontWeight: "600",
    background: "rgba(255,255,255,0.8)",
    border: "1px solid rgba(0,0,0,0.05)",
    boxShadow: "0 6px 18px rgba(0,0,0,0.08)",
    transition: "all 0.25s ease",
    userSelect: "none"
  }

  return (
    <>
      <Header />

      {/* HERO */}
      <div style={{
        position: "relative",
        height: "450px",
        overflow: "hidden"
      }}>
        <img
          src={banners[current]}
          alt=""
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            filter: "brightness(0.55) saturate(1.2)"
          }}
        />

        <div style={{
          position: "absolute",
          inset: 0,
          display: "flex",
          alignItems: "center",
          paddingLeft: "70px"
        }}>
          <div style={{
            color: "white",
            background: "rgba(0,0,0,0.35)",
            backdropFilter: "blur(12px)",
            padding: "35px",
            borderRadius: "24px",
            maxWidth: "600px",
            boxShadow: "0 10px 40px rgba(0,0,0,0.3)"
          }}>
            <h1 style={{ fontSize: "48px", fontWeight: "900", marginBottom: "10px" }}>
              Explore India Like Never Before ✈️
            </h1>
            <p style={{ fontSize: "18px", opacity: 0.9 }}>
              Smart • Affordable • Memorable Journeys for Students 🎓
            </p>
          </div>
        </div>
      </div>

      {/* MAIN */}
      <div style={{
        background: "linear-gradient(135deg,#eef2ff,#f8fbff,#ffffff)",
        padding: "50px 0"
      }}>

        {/* CATEGORY */}
        <div className="container text-center">
          <h3 style={{ fontWeight: "800", marginBottom: "10px" }}>
            Explore Categories
          </h3>

          <div style={{
            display: "flex",
            justifyContent: "center",
            gap: "14px",
            marginTop: "25px",
            flexWrap: "wrap"
          }}>
            {["All", "Beach", "Mountains", "City", "Spiritual", "Heritage"]
              .map((cat, index) => (
                <div
                  key={index}
                  onClick={() => filterCategory(cat)}
                  style={btnBase}
                  onMouseEnter={(e) => {
                    e.target.style.background = "#0d6efd"
                    e.target.style.color = "#fff"
                    e.target.style.transform = "translateY(-3px) scale(1.05)"
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.background = "rgba(255,255,255,0.8)"
                    e.target.style.color = "#000"
                    e.target.style.transform = "none"
                  }}
                >
                  {cat}
                </div>
              ))}
          </div>
        </div>

        {/* CARDS */}
        <div className="container mt-5">
          <h3 style={{ fontWeight: "800" }}>Recommended Trips</h3>

          <div style={{
            display: "flex",
            gap: "22px",
            overflowX: "auto",
            padding: "25px 5px"
          }}>
            {places.map((place, index) => (
              <div
                key={index}
                style={{
                  minWidth: "250px",
                  borderRadius: "22px",
                  overflow: "hidden",
                  background: "#fff",
                  boxShadow: "0 10px 25px rgba(0,0,0,0.12)",
                  transition: "all 0.3s ease",
                  cursor: "pointer"
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "translateY(-10px)"
                  e.currentTarget.style.boxShadow = "0 18px 45px rgba(0,0,0,0.25)"
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "none"
                  e.currentTarget.style.boxShadow = "0 10px 25px rgba(0,0,0,0.12)"
                }}
              >
                <img
                  src={place.img}
                  alt=""
                  style={{
                    width: "100%",
                    height: "260px",
                    objectFit: "cover"
                  }}
                />

                <div style={{
                  padding: "14px",
                  textAlign: "center"
                }}>
                  <h6 style={{ fontWeight: "700", margin: 0 }}>
                    {place.title}
                  </h6>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* VIDEO */}
        <div style={{
          marginTop: "80px",
          padding: "60px 0",
          background: "linear-gradient(135deg,#ffffff,#eef4ff)"
        }}>
          <div className="container text-center">

            <h5 style={{ color: "#0d6efd", letterSpacing: "1px" }}>
              ✨ Featured Travel Experience
            </h5>

            <h2 style={{ fontWeight: "900", marginTop: "10px" }}>
              Experience Incredible India 🌏
            </h2>

            <p style={{
              color: "#555",
              maxWidth: "650px",
              margin: "10px auto 35px",
              fontSize: "15px"
            }}>
              Discover breathtaking destinations, rich culture, and unforgettable travel experiences.
            </p>
<div style={{
  position: "relative",
  width: "100%",
  paddingTop: "56.25%", // 16:9 ratio
  borderRadius: "22px",
  overflow: "hidden",
  boxShadow: "0 18px 50px rgba(0,0,0,0.25)"
}}>
  <iframe
    src="https://www.youtube.com/embed/1K4fL_P5rQI?si=3Alp8XRTsJvoApyi"
    title="YouTube video player"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
    allowFullScreen
    style={{
      position: "absolute",
      top: 0,
      left: 0,
      width: "100%",
      height: "100%",
      border: "none"
    }}
  ></iframe>
</div>
          </div>
        </div>

      </div>

      <Footer />
    </>
  )
}

export default App