import React from "react";
function FetchFeedbackDetails({ feedbackArray = [] }) {
     
    return (
        <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(3,1fr)",
            gap: "20px",
            padding: "40px"
        }}>

            {feedbackArray.map((item, index) => {
                
                let stars = "";
                
                if (item.rating == 1) stars = "⭐";
                else if (item.rating == 2) stars = "⭐⭐";
                else if (item.rating == 3) stars = "⭐⭐⭐";
                else if (item.rating == 4) stars = "⭐⭐⭐⭐";
                else if (item.rating == 5) stars = "⭐⭐⭐⭐⭐";
                         
                return (
                    <div key={index} style={{
                        border: "1px solid #ccc",
                        borderRadius: "10px",
                        padding: "20px",
                        boxShadow: "0px 2px 10px rgba(0,0,0,0.1)"
                    }}>

                        <p><b>Posted by: </b>{item.user.name}</p>
                        <p><b>Review:</b> {item.review}</p>
                        <p><b>Rating:</b> {stars}</p>

                    </div>
                )

            })}

        </div>
    );
}

export default FetchFeedbackDetails;