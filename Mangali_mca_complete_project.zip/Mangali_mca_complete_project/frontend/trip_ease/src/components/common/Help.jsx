import React from "react";
import Header from "../common/Header";
import Footer from "../common/Footer";

function Help() {
  return (
    <>
      <Header />

      <div style={{
        background: "linear-gradient(135deg,#0f2027,#203a43,#2c5364)",
        minHeight: "100vh",
        padding: "40px 20px",
        color: "white"
      }}>

        {/* 🔥 HERO */}
        <div style={{
          textAlign: "center",
          marginBottom: "50px"
        }}>
          <h1 style={{
            fontSize: "42px",
            fontWeight: "bold",
            letterSpacing: "1px"
          }}>
            🚀 How to Use TripEase
          </h1>

          <p style={{
            color: "#ddd",
            marginTop: "10px",
            fontSize: "18px"
          }}>
            Your complete guide to explore, plan & enjoy trips easily ✈️
          </p>
        </div>

        {/* ✨ STEPS (GLASS CARDS) */}
        <div className="container">
          <div className="row g-4">

            {[
              { icon: "📝", title: "Register", desc: "Create your account with basic details" },
              { icon: "🔑", title: "Login", desc: "Securely login to access features" },
              { icon: "🌍", title: "Explore", desc: "Browse cities and destinations" },
              { icon: "🧳", title: "Book Trips", desc: "Select and book your perfect trip" },
              { icon: "⭐", title: "Feedback", desc: "Share your experience with us" },
              { icon: "📞", title: "Support", desc: "Contact us anytime for help" }
            ].map((step, index) => (
              <div className="col-md-4" key={index}>
                <div style={{
                  background: "rgba(255,255,255,0.1)",
                  backdropFilter: "blur(10px)",
                  borderRadius: "20px",
                  padding: "25px",
                  textAlign: "center",
                  border: "1px solid rgba(255,255,255,0.2)",
                  transition: "0.4s",
                  cursor: "pointer"
                }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = "translateY(-12px) scale(1.05)"
                    e.currentTarget.style.background = "rgba(255,255,255,0.2)"
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = "none"
                    e.currentTarget.style.background = "rgba(255,255,255,0.1)"
                  }}
                >
                  <h2 style={{ fontSize: "40px" }}>{step.icon}</h2>
                  <h5 style={{ fontWeight: "bold", marginTop: "10px" }}>
                    {step.title}
                  </h5>
                  <p style={{ color: "#ddd" }}>{step.desc}</p>
                </div>
              </div>
            ))}

          </div>
        </div>

        {/* 🎯 FEATURES */}
        <div className="container mt-5 text-center">
          <h3 style={{ fontWeight: "bold" }}>
            ✨ Why Choose TripEase?
          </h3>

          <div style={{
            display: "flex",
            justifyContent: "center",
            gap: "20px",
            marginTop: "25px",
            flexWrap: "wrap"
          }}>
            {[
              "💰 Budget Friendly",
              "⚡ Fast Booking",
              "🌍 Explore India",
              "🎓 Student Focused",
              "🔒 Secure Platform"
            ].map((item, i) => (
              <div key={i} style={{
                background: "rgba(255,255,255,0.15)",
                padding: "12px 20px",
                borderRadius: "30px",
                backdropFilter: "blur(8px)",
                border: "1px solid rgba(255,255,255,0.2)",
                transition: "0.3s"
              }}
                onMouseEnter={(e) => e.currentTarget.style.background = "rgba(255,255,255,0.3)"}
                onMouseLeave={(e) => e.currentTarget.style.background = "rgba(255,255,255,0.15)"}
              >
                {item}
              </div>
            ))}
          </div>
        </div>

        {/* 📌 TIMELINE STYLE GUIDE */}
        <div className="container mt-5">
          <h3 className="text-center mb-4">📌 Quick Guide</h3>

          <div style={{
            maxWidth: "600px",
            margin: "auto",
            lineHeight: "1.8"
          }}>
            <p>👉 Step 1: Register your account</p>
            <p>👉 Step 2: Login to your dashboard</p>
            <p>👉 Step 3: Explore cities & destinations</p>
            <p>👉 Step 4: Choose your trip & book</p>
            <p>👉 Step 5: Enjoy & give feedback ⭐</p>
          </div>
        </div>

        {/* ❓ FAQ */}
        <div className="container mt-5">
          <h3 className="text-center">❓ FAQs</h3>

          <div style={{
            marginTop: "20px",
            maxWidth: "700px",
            marginInline: "auto"
          }}>
            <div style={{
              background: "rgba(255,255,255,0.1)",
              padding: "15px",
              borderRadius: "12px",
              marginBottom: "10px"
            }}>
              <b>How to register?</b>
              <p>Create account using register option.</p>
            </div>

            <div style={{
              background: "rgba(255,255,255,0.1)",
              padding: "15px",
              borderRadius: "12px",
              marginBottom: "10px"
            }}>
              <b>How to book trip?</b>
              <p>Select destination and click book.</p>
            </div>

            <div style={{
              background: "rgba(255,255,255,0.1)",
              padding: "15px",
              borderRadius: "12px"
            }}>
              <b>Is TripEase free?</b>
              <p>Yes, browsing is free for all users.</p>
            </div>
          </div>
        </div>

      </div>

      <Footer />
    </>
  );
}

export default Help;