import React from "react";
import Header from "./Header";
import Footer from "./Footer";

function AboutUs() {
  return (
    <>
      <Header />

      <div 
      className="container-fluid d-flex flex-column justify-content-center"
  style={{
    backgroundImage: "url('/trav2.jpg')",
    backgroundSize: "cover",
    backgroundPosition: "center",
    backgroundRepeat: "no-repeat",
  }}

      
      >

        {/* Title */}
        <div className="text-center mb-5">
          <h1 className="fw-bold" style={{color:"#0F4C75"}}>
            <i className="fa-solid fa-plane me-2"></i>
            About TripEase
          </h1>
          <p className="text-muted">
            Explore smart. Travel easy. Experience better.
          </p>
        </div>

        {/* Vision Mission Goal - Side by Side */}
        <div className="row text-center mb-5">

          <div className="col-md-4 mb-3">
            <div className="card shadow border-0 h-100 square-box">
              <div className="card-body">
                <i className="fa-solid fa-eye fa-2x text-success mb-3"></i>
                <h5 className="fw-bold">Vision</h5>
                <p className="text-muted">
                   To revolutionize short-trip planning with intelligent and secure AI solutions.
                </p>
              </div>
            </div>
          </div>

          <div className="col-md-4 mb-3">
            <div className="card shadow border-0 h-100 square-box">
              <div className="card-body">
                <i className="fa-solid fa-bullseye fa-2x text-warning mb-3"></i>
                <h5 className="fw-bold">Mission</h5>
                <p className="text-muted">
                  To provide an integrated platform for smart route planning, booking and travel asssistance.
                </p>
              </div>
            </div>
          </div>

          <div className="col-md-4 mb-3">
            <div className="card shadow border-0 h-100 square-box">
              <div className="card-body">
                <i className="fa-solid fa-flag-checkered fa-2x text-danger mb-3"></i>
                <h5 className="fw-bold">Goal</h5>
                <p className="text-muted">
                  To make educational trip management simple,efficient and technology-driven.
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* Image and Contact Section */}
        <div className="row align-items-center">

          {/* Image */}
          <div className="col-md-6 mb-4 text-center">
            <img
              src="/mangu.jpeg"
              alt="Travel"
              className="img-fluid rounded-circle shadow "
              style={{ height: "300px", objectFit: "cover", width: "300px" }}
            />
          </div>

          {/* Contact Info */}
          <div className="col-md-6">
            <div className="card shadow border-0 p-4">
              <h4 className="fw-bold mb-4"style={{color:"#3282B8"}}>
                <i className="fa-solid fa-address-card me-2"></i>
                Contact Information
              </h4>

              <p className="fs-5">
                <i className="fa-solid fa-user me-2 text-dark"></i>
                <strong>Name:</strong> Mangali Tiwari
              </p>

              <p className="fs-5">
                <i className="fa-solid fa-envelope me-2 text-danger"></i>
                <strong>Email:</strong> mangalitiwari@gmail.com
              </p>

              <p className="fs-5">
                <i className="fa-solid fa-phone me-2 text-success"></i>
                <strong>Phone:</strong> +91 8471088908
              </p>

            </div>
          </div>

        </div>

      </div>

      <Footer />
    </>
  );
}

export default AboutUs;