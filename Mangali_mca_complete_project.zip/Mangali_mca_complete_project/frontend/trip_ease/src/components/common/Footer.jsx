import '../../css/footer.css'

function Footer() {
  return (
    <>
      <div className="footer-section bg-dark text-light pt-5 pb-3">
        <div className="container">
          <div className="row">

            {/* Column 1 - About TripEase */}
            <div className="col-md-4 mb-4">
              <h4 className="fw-bold"style={{color:"#0F4C75"}}>
                <i className="fa-solid fa-plane-departure me-2"></i>
                TripEase
              </h4>
              <p className="small">
                TripEase is an AI-powered platform designed to simplify
                short trip planning for schools, colleges and universities.
                Smart routes, easy booking and secure travel management ✈️
              </p>
            </div>

            {/* Column 2 - Quick Links */}
            <div className="col-md-4 mb-4">
              <h5 className="fw-bold mb-3">
                <i className="fa-solid fa-link me-2 text-warning"></i>
                Quick Links
              </h5>
              <ul className="list-unstyled">
                <li className="mb-2">
                  <a href="/" className="footer-link">
                    <i className="fa-solid fa-house me-2"></i>Home
                  </a>
                </li>
                <li className="mb-2">
                  <a href="/about" className="footer-link">
                    <i className="fa-solid fa-circle-info me-2"></i>About
                  </a>
                </li>
                <li className="mb-2">
                  <a href="/contact" className="footer-link">
                    <i className="fa-solid fa-envelope me-2"></i>Contact
                  </a>
                </li>
                <li className="mb-2">
                  <a href="/help" className="footer-link">
                    <i className="fa-solid fa-life-ring me-2"></i>Help Center
                  </a>
                </li>
                <li className="mb-2">
                  <a href="/video" className="footer-link">
                    <i className="fa-solid fa-video me-2"></i>Video Guide
                  </a>
                </li>



              </ul>
            </div>

            {/* Column 3 - Contact Info */}
            <div className="col-md-4 mb-4">
              <h5 className="fw-bold mb-3">
                <i className="fa-solid fa-address-card me-2 text-success"></i>
                Reach Us
              </h5>

              <p>
                <i className="fa-solid fa-user me-2 text-light"></i>
                Mangali Tiwari
              </p>

              <p>
                <i className="fa-solid fa-envelope me-2 text-danger"></i>
                mangalitiwari12@gmail.com
              </p>

              <p>
                <i className="fa-solid fa-phone me-2 text-success"></i>
                +91 8471088908
              </p>

              {/* Social Icons */}
              <div className="mt-3">
                <i className="fa-brands fa-facebook me-3 footer-social"></i>
                <i className="fa-brands fa-instagram me-3 footer-social"></i>
                <i className="fa-brands fa-linkedin footer-social"></i>
              </div>
            </div>

          </div>

          <hr className="border-secondary" />

          <div className="text-center small">
            © 2026 TripEase | Designed by Mangali😊
          </div>

        </div>
      </div>
    </>
  )
}

export default Footer