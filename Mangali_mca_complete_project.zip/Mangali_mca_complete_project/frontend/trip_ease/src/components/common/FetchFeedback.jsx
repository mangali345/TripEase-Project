import axios from "axios"
import { useState, useEffect } from "react"
import FetchFeedbackDetails from "./FetchFeedbackDetails"

function FetchFeedback() {

    const APIURL = "http://localhost:9090/fetchFeedback"

    const [feedbackdata, setFeedbackData] = useState([])

    useEffect(() => {

        const fetchData = async () => {
            try {
                const serverResponse = await axios.get(APIURL)
                console.log(serverResponse.data)
                setFeedbackData(serverResponse.data)
            }
            catch (error) {
                console.log(error)
            }
        }

        fetchData()

    }, [])

    return (
        <>
            

            <h2 style={{ textAlign: "center", margin: "70px" }}>
                All Feedback Details
            </h2>

            <FetchFeedbackDetails feedbackArray={feedbackdata} />
            

        </>
    )
}

export default FetchFeedback