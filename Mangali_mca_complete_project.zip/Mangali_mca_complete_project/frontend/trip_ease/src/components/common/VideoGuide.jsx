import React from "react";

function VideoGuide() {
  return (
    <div className="container mt-5">
      
      {/* Header */}
      <div className="text-center mb-4">
        <h2 style={{ fontWeight: "700", color: "#0d6efd" }}>
          🎥 Video Guide
        </h2>
        <p style={{ color: "#6c757d" }}>
          Learn how to use our website step by step
        </p>
      </div>

      {/* Video Card */}
      <div className="row justify-content-center">
        <div className="col-md-8">
          <div className="card shadow" style={{ borderRadius: "15px" }}>
            
            <div className="card-body text-center">
              
              {/* YouTube Video */}
              <div className="ratio ratio-16x9">
                <iframe
                  src="https://www.youtube.com/embed/VIDEO_ID_HERE"
                  title="Help Video"
                  allowFullScreen
                ></iframe>
              </div>

              {/* Description */}
              <p className="mt-3" style={{ color: "#555" }}>
                Watch this video to understand how to login, book packages, and use all features easily.
              </p>

            </div>

          </div>
        </div>
      </div>

    </div>
  );
}

export default VideoGuide;