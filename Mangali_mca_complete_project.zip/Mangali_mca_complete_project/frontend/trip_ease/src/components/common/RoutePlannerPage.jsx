import { useState } from "react";
import axios from "axios";

export default function RoutePlannerPage() {
  const [data, setData] = useState({
    source: "",
    destination: "",
    result: "",
    loading: false
  });

  const handleGenerateRoute = async () => {
    if (!data.source || !data.destination) {
      setData((prev) => ({
        ...prev,
        result: "⚠️ Please enter both source and destination."
      }));
      return;
    }

    setData((prev) => ({
      ...prev,
      loading: true,
      result: ""
    }));

    try {
      const response = await axios.post(
        "https://api.cohere.ai/v1/chat",
        {
          model: "command-a-03-2025",
          message: `



// Create a detailed travel route plan from ${data.source} to ${data.destination}.
Provide complete route details such as fare, distance, travel modes, timings from ${data.source} to ${data.destination}
Include:
1. Best route (road/train/flight)
2. Step-by-step route plan
3. Estimated distance and travel time
4. Fare estimation (budget range)


Format the entire answer using only clean HTML tags like <h3>, <p>, <ul>, <li>.
Also include emojis/icons for travel modes wherever relevant, such as: "
                    bus 🚍, train 🚆, flight ✈️, cab 🚕, auto 🛺, metro 🚇, walking 🚶, cycling 🚴. "
                    Do NOT wrap the output inside any markdown code blocks (no backticks)
          `,
        },
        {
          headers: {
            Authorization: "Bearer Sz2MBBJF8K5eEzG22yIdZQjSZcxmWBitaIsnVD5a",
            "Content-Type": "application/json",
          },
        }
      );

      const aiText =
        response.data.text ||
        response.data.message?.content?.[0]?.text ||
        "No route found.";

      setData((prev) => ({
        ...prev,
        result: aiText
      }));
    } catch (err) {
      setData((prev) => ({
        ...prev,
        result:
          "❌ Error: " + (err.response?.data?.message || err.message)
      }));
    }

    setData((prev) => ({
      ...prev,
      loading: false
    }));
  };

  return (
    <div className="page-container d-flex justify-content-center align-items-center">
      <style>{`
        .page-container {
          min-height: 100vh;
          background: linear-gradient(135deg, #11998e, #38ef7d);
          padding: 40px 15px;
        }
        .card-custom {
          width: 100%;
          max-width: 750px;
          border-radius: 20px;
          background: #ffffff;
          box-shadow: 0 10px 25px rgba(0,0,0,0.2);
          padding: 30px;
        }
        .card-custom h1 {
          text-align: center;
          margin-bottom: 20px;
          color: #00695c;
        }
        .btn-custom {
          background: linear-gradient(90deg, #11998e, #38ef7d);
          color: white;
          border: none;
          font-weight: 600;
        }
        .btn-custom:hover {
          background: linear-gradient(90deg, #38ef7d, #11998e);
        }
        .output-box {
          margin-top: 20px;
          padding: 15px;
          background: #f1f8f6;
          border-left: 5px solid #00695c;
          border-radius: 10px;
          max-height: 400px;
          overflow-y: auto;
        }
      `}</style>

      <div className="card-custom">
        <h1>Route Planner 🚗</h1>

        <input
          type="text"
          className="form-control mb-3"
          placeholder="Enter Source (e.g., Lucknow)"
          value={data.source}
          onChange={(e) =>
            setData((prev) => ({ ...prev, source: e.target.value }))
          }
        />

        <input
          type="text"
          className="form-control mb-3"
          placeholder="Enter Destination (e.g., Delhi)"
          value={data.destination}
          onChange={(e) =>
            setData((prev) => ({ ...prev, destination: e.target.value }))
          }
        />

        <button
          className="btn btn-custom w-100"
          onClick={handleGenerateRoute}
          disabled={data.loading}
        >
          {data.loading ? "Generating Route..." : "Generate Route Plan"}
        </button>

        {data.result && (
          <div className="output-box">
            <h5>Route Details:</h5>
            <div
              dangerouslySetInnerHTML={{ __html: data.result }}
            />
          </div>
        )}
      </div>
    </div>
  );
}