import React, { useState } from "react";
import data from "./data.json";
import Header from "./Header";
import Footer from "./Footer";

export default function CityPlaces() {
  const [selectedCity, setSelectedCity] = useState("");

  const cities = data.map((item) => Object.keys(item)[0]);
  const selectedData = data.find((item) => item[selectedCity]);
  const places = selectedData ? selectedData[selectedCity] : null;

  return (
    <>
      <Header />

      {/* 🌈 BACKGROUND */}
      <div style={{
        minHeight: "100vh",
        background: "linear-gradient(135deg,#f5f7fa,#c3cfe2)",
        padding: "40px"
      }}>

        {/* 🏷️ TITLE */}
        <h1 style={{
          textAlign: "center",
          fontWeight: "bold",
          marginBottom: "30px"
        }}>
          🌍 Explore Cities & Places
        </h1>

        {/* 🔽 DROPDOWN */}
        <div style={{ textAlign: "center" }}>
          <select
            value={selectedCity}
            onChange={(e) => setSelectedCity(e.target.value)}
            style={{
              padding: "12px 20px",
              borderRadius: "25px",
              border: "none",
              outline: "none",
              boxShadow: "0 5px 15px rgba(0,0,0,0.2)",
              fontSize: "16px",
              cursor: "pointer"
            }}
          >
            <option value="">Select City</option>
            {cities.map((city, index) => (
              <option key={index} value={city}>{city}</option>
            ))}
          </select>
        </div>

        {/* 🏙️ GRID */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(280px,1fr))",
          gap: "25px",
          marginTop: "40px"
        }}>

          {places &&
            Object.keys(places).map((key, index) => (
              <div key={index} style={{
                borderRadius: "20px",
                overflow: "hidden",
                background: "rgba(255,255,255,0.7)",
                backdropFilter: "blur(10px)",
                boxShadow: "0 10px 25px rgba(0,0,0,0.2)",
                transition: "0.4s",
                cursor: "pointer"
              }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "translateY(-10px) scale(1.02)"
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "none"
                }}
              >

                {/* IMAGE */}
                <img
                  src={places[key].image}
                  alt={places[key].name}
                  style={{
                    width: "100%",
                    height: "200px",
                    objectFit: "cover"
                  }}
                />

                {/* CONTENT */}
                <div style={{ padding: "15px" }}>
                  <h3 style={{ marginBottom: "8px" }}>
                    {places[key].name}
                  </h3>

                  <p style={{
                    fontSize: "14px",
                    color: "#555"
                  }}>
                    {places[key].description}
                  </p>

                </div>

              </div>
            ))}

        </div>

        {/* EMPTY STATE */}
        {!selectedCity && (
          <p style={{
            textAlign: "center",
            marginTop: "40px",
            color: "gray"
          }}>
            Select a city to explore places ✨
          </p>
        )}

      </div>

      {/* ✅ FOOTER ADDED HERE */}
      <Footer />
    </>
  );
}