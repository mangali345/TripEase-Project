import Header from './Header'
import Footer from './Footer'
import { useState } from 'react'
import Swal from 'sweetalert2'
import axios from 'axios'

function ContactUs() {

  const APIURL = "http://localhost:9090/addContact"

  const [data, setData] = useState({
    name: "",
    email: "",
    phone: "",
    question: ""
  })

  const [validate, setValidate] = useState(false)

  const fetchData = (e) => {
    const { name, value } = e.target

    const alphaRegex = /^[A-Za-z\s]*$/
    const numberRegex = /^[0-9]*$/

    if (name === "name" && !alphaRegex.test(value)) {
      Swal.fire("Error", "Only alphabets allowed", "error")
      return
    }

    if (name === "phone" && !numberRegex.test(value)) {
      Swal.fire("Error", "Only digits allowed", "error")
      return
    }

    setData({ ...data, [name]: value })
  }

  const submitForm = async (e) => {
    e.preventDefault()

    const form = e.currentTarget

    if (!form.checkValidity()) {
      e.stopPropagation()
    }

    setValidate(true)

    try {
      const res = await axios.post(APIURL, data)

      Swal.fire({
        title: "Success 🎉",
        text: res.data,
        icon: "success"
      })

      setData({
        name: "",
        email: "",
        phone: "",
        question: ""
      })

    } catch (err) {
      Swal.fire("Error", "Server error occurred", "error")
    }
  }

  return (
    <>
      <Header />

      {/* Background (UPDATED ONLY THIS PART) */}
      <div style={{
        background: "linear-gradient(135deg, #e0eafc, #cfdef3)",
        padding: "40px 0"
      }}>

        {/* Title */}
        <div className="text-center mb-4">
          <h2 style={{ fontWeight: "700", color: "#0d6efd" }}>
            📞 Contact Us
          </h2>
          <p style={{ color: "#6c757d" }}>
            We are here to help you anytime
          </p>
        </div>

        {/* FORM + IMAGE */}
        <div className="container">
          <div className="row justify-content-center align-items-stretch">

            {/* IMAGE */}
            <div className="col-md-5 mb-3 d-flex align-items-center">
              <img
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRhqJ-ffcWZs6qNQ1KKgC9277ca6zwx0qU2iQ&s"
                alt="contact"
                style={{
                  width: "100%",
                  borderRadius: "15px",
                  boxShadow: "0 4px 10px rgba(0,0,0,0.1)"
                }}
              />
            </div>

            {/* FORM */}
            <div className="col-md-6">
              <div className="card shadow p-4" style={{ borderRadius: "20px" }}>

                <h5 className="mb-3 text-primary fw-bold">
                  Send Your Message ✉️
                </h5>

                <form
                  onSubmit={submitForm}
                  className={`needs-validation ${validate ? "was-validated" : ""}`}
                  noValidate
                >

                  {/* Name */}
                  <div className="mb-3">
                    <label className="form-label">Name</label>
                    <input
                      type="text"
                      name="name"
                      value={data.name}
                      onChange={fetchData}
                      className="form-control"
                      placeholder="Enter your name"
                      required
                    />
                  </div>

                  {/* Email */}
                  <div className="mb-3">
                    <label className="form-label">Email</label>
                    <input
                      type="email"
                      name="email"
                      value={data.email}
                      onChange={fetchData}
                      className="form-control"
                      placeholder="Enter your email"
                      required
                    />
                  </div>

                  {/* Phone */}
                  <div className="mb-3">
                    <label className="form-label">Phone</label>
                    <input
                      type="text"
                      name="phone"
                      value={data.phone}
                      onChange={fetchData}
                      className="form-control"
                      placeholder="Enter your phone"
                      required
                    />
                  </div>

                  {/* Message */}
                  <div className="mb-3">
                    <label className="form-label">Message</label>
                    <textarea
                      name="question"
                      value={data.question}
                      onChange={fetchData}
                      className="form-control"
                      rows="3"
                      placeholder="Write your message..."
                      required
                    />
                  </div>

                  {/* BUTTON */}
                  <button className="btn btn-primary w-100 py-2">
                    🚀 Submit
                  </button>

                </form>

              </div>
            </div>

          </div>
        </div>

        {/* MAP SECTION */}
        <div className="container mt-5">
          <div
            className="card shadow"
            style={{ borderRadius: "15px", overflow: "hidden" }}
          >
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.9193209383857!2d80.95672737475688!3d26.874304261741308!2m3!1f0!2f0!0f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399bfd66707a1371%3A0x49dc27c64bc0aab2!2sPrecursor%20Info%20Solutions%20Pvt.%20Ltd.!5e0!3m2!1sen!2sin!4v1770980695441!5m2!1sen!2sin"
              style={{
                border: "0",
                width: "100%",
                height: "450px",
                marginTop: "50px"
              }}
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>

      </div>

      <Footer />
    </>
  )
}

export default ContactUs