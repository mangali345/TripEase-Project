import React from "react";
import { Link } from "react-router-dom";
import "../../css/header2.css";


const Header= () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark custom-navbar">
      <div className="container-fluid">

        {/* Logo */}
        <Link className="navbar-brand d-flex align-items-center" to="/">
          <i className="fa-solid fa-compass me-2"></i>
          <span className="fw-bold text-white">TripEase✈️🌍</span>
        </Link>

        {/* Mobile Toggle */}
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarSupportedContent">

          {/* Left Side */}
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">

            <li className="nav-item">
              <Link className="nav-link custom-link active" to="/">
                <i className="fa-solid fa-house me-1"></i>
                Home
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link custom-link" to="/about">
                <i className="fa-solid fa-circle-info me-1"></i>
                About
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link custom-link" to="/contact">
                <i className="fa-solid fa-phone me-1"></i>
                Contact
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link custom-link" to="/city">
                <i className="fa-solid fa-city me-1"></i>
                City Explorer
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link custom-link" to="/fetchfeed">
                <i className="fa-solid fa-comment me-1"></i>
                Feedbacks
              </Link>
            </li>


          </ul>

          {/* Right Side Dropdowns */}
          <ul className="navbar-nav ms-auto">

            {/* Register Dropdown */}
            <li className="nav-item dropdown">
              <a
                className="nav-link custom-link dropdown-toggle"
                href="#"
                role="button"
                data-bs-toggle="dropdown"
              >
                <i className="fa-solid fa-user-plus me-1"></i>
                Register
              </a>
              <ul className="dropdown-menu dropdown-menu-end">
                <li>
                  <Link className="dropdown-item" to="/register/company">
                    <i className="fa-solid fa-handshake me-2"></i>
                    Company
                  </Link>
                </li>
                <li>
                  <Link className="dropdown-item" to="/register/user">
                    <i className="fa-solid fa-user me-2"></i>
                    User
                  </Link>
                </li>
              </ul>
            </li>

            {/* Login Dropdown */}
            <li className="nav-item dropdown">
              <a
                className="nav-link custom-link dropdown-toggle"
                href="#"
                role="button"
                data-bs-toggle="dropdown"
              >
                <i className="fa-solid fa-right-to-bracket me-1"></i>
                Login
              </a>
              <ul className="dropdown-menu dropdown-menu-end">
                <li>
                  <Link className="dropdown-item" to="/login/company">
                    <i className="fa-solid fa-handshake me-2"></i>
                    Company
                  </Link>
                </li>
                <li>
                  <Link className="dropdown-item" to="/login/user">
                    <i className="fa-solid fa-user-check me-2"></i>
                    User
                  </Link>
                </li>
              </ul>
            </li>

          </ul>

        </div>
      </div>
    </nav>
  );
};

export default Header;