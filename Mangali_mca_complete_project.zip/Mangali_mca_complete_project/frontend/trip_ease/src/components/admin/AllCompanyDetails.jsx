import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function AllCompanyDetails({ companyArray }) {

  const navigate = useNavigate();
  const [packagedata, setPackageData] = useState([{}]);

  // ✅ SHOW TRIPS
  const showTrips = async (email) => {
    alert(email);
    navigate(`/tripDetails/${email}`);

    const APIURL = `http://localhost:9090/user/showTrips/${email}`;

    try {
      const res = await axios.get(APIURL);
      console.log(res.data);
      setPackageData(res.data);
    } catch (error) {
      console.error(error);
    }
  };

  
  const updateStatus = async (email) => {
    try {
      const UPDATEURL = `http://localhost:9090/admin/authenticatePlanner/${email}`;
      
      await axios.put(UPDATEURL);

      alert("Approved Successfully ");

    } catch (error) {
      console.error(error);
      alert("Error ❌");
    }
  };

  return (
    <div className="container mt-4">

      <h3 className="text-center mb-4">
        Company Details
      </h3>

      <table className="table table-bordered text-center">
        <thead>
          <tr>
            <th>Company</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>City</th>
            <th>Address</th>
            <th>Reg No</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>
          {companyArray.map((cobj, index) => (
            <tr key={index}>
              <td>{cobj.company}</td>
              <td>{cobj.name}</td>
              <td>{cobj.email}</td>
              <td>{cobj.phone}</td>
              <td>{cobj.city}</td>
              <td>{cobj.address}</td>
              <td>{cobj.registrationNo}</td>

              <td>
                <button
                  className="btn btn-success"
                  onClick={() => updateStatus(cobj.email)}
                >
                  Approve
                </button>
              </td>

            </tr>
          ))}
        </tbody>
      </table>

    </div>
  );
}

export default AllCompanyDetails;