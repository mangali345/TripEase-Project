import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function  AdminHeader(){
  const [collapsed, setCollapsed] = useState(false);
  const [showMobile, setShowMobile] = useState(false);

  const navigate = useNavigate()

  //function for admin Logout - 09 Mar, 2026
  const logout = ()=> {
      //fetching value from localstorage
       const email=localStorage.getItem("adminEmail")
       
       if(email != null ){
         localStorage.removeItem("adminEmail") //clear all the values from browser storage
          navigate("/admin") //redirect admin to the login page after logout.
       }
  }

  return (
    <>
      {/* ===== Top Navbar ===== */}
      <nav
        className="navbar navbar-dark bg-dark fixed-top px-3"
        style={{ height: "60px" }}
      >
        <button
          className="btn btn-outline-light d-lg-none"
          onClick={() => setShowMobile(!showMobile)}
        >
          <i className="fa-solid fa-bars"></i>
        </button>

        <button
          className="btn btn-outline-light d-none d-lg-block"
          onClick={() => setCollapsed(!collapsed)}
        >
          <i className="fa-solid fa-bars"></i>
        </button>

        <span className="navbar-brand ms-2">Admin Panel</span>
      </nav>

      {/* ===== Sidebar ===== */}
      <div
        className={`bg-dark text-white position-fixed start-0 
        ${showMobile ? "d-block" : "d-none d-lg-block"}`}
        style={{
          top: "60px",
          width: collapsed ? "80px" : "240px",
          height: "calc(100vh - 60px)",
          transition: "0.3s",
        }}
      >
        <ul className="nav flex-column pt-3">

          <li className="nav-item">
            <Link className="nav-link text-white menu-item" to="#">
              <i className="fa-solid fa-gauge me-2"></i>
              {!collapsed && "Dashboard"}
            </Link>
          </li>

          <li className="nav-item">
            <Link className="nav-link text-white menu-item" to="/allContacts">
              <i className="fa-solid fa-address-book me-2"></i>
              {!collapsed && "AllContacts"}
            </Link>
          </li>

          <li className="nav-item">
            <Link className="nav-link text-white menu-item" to="/allusers">
              <i className="fa-solid fa-users me-2"></i>
              {!collapsed && " All Users"}
            </Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link text-white menu-item" to="/allplanner">
              <i className="fa-solid fa-route me-2"></i>
              {!collapsed && "All Travel Planners"}
            </Link>
          </li>

          <li className="nav-item">
            <Link className="nav-link text-white menu-item" to="/allfeedback">
              <i className="fa-solid fa-comments me-2"></i>
              {!collapsed && " All Feedbacks"}
            </Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link text-white menu-item" to="/adminedit">
              <i className="fa-solid fa-user-edit me-2"></i>
              {!collapsed && "Edit Profile"}
            </Link>
          </li>
                    <li className="nav-item">
            <Link className="nav-link text-white menu-item" to="/imageupload">
              <i className="fa-solid fa-user-plus me-2"></i>
              {!collapsed && "Profile Image Upload"}
            </Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link text-white menu-item" to="/changepass">
              <i className="fa-solid fa-key me-2"></i>
              {!collapsed && "Change Password"}
            </Link>
          </li>
          

          <li className="nav-item mt-4">
                  <button className="btn btn-link" style={{textDecoration: "none"}} onClick={()=>{logout()}}> 
                  {/* calling the logout function inside arrow function as callback because we want the logout function to run on button click, 
                  if we call it directly inside curly braces {logout()} then it will automatically get called when the component renders - 09 Mar, 2026*/}
                    <i className="fa-solid fa-right-from-bracket me-2"></i>
                    Logout
                    </button>
                </li>

        </ul>
      </div>

      {/* ===== Hover Effect ===== */}
      <style>
        {`
          .menu-item {
            padding: 12px 20px;
            transition: 0.2s;
          }

          .menu-item:hover {
            background-color: #0d6efd;
            color: white !important;
          }
        `}
      </style>
    </>
  );
};

export default AdminHeader;