import axios from 'axios'
import { useEffect, useState } from 'react'
import AdminHeader from './AdminHeader'
import { ToastContainer, toast } from 'react-toastify'
import "react-toastify/dist/ReactToastify.css";
import { useNavigate } from 'react-router-dom';

function AdminEditProfile() {

    const email = localStorage.getItem("adminEmail")

    const APIURL = `http://localhost:9090/admin/adminProfile/${email}`
    const EDITAPIURL = `http://localhost:9090/admin/editProfile/${email}`

    const [admindata, setAdmindata] = useState({ name: "", phone: "" })
    const navigate = useNavigate()

    useEffect(() => {

        const fetchData = async () => {
            try {
                const serverResponse = await axios.get(APIURL)

                if (serverResponse?.data) {
                    setAdmindata({
                        name: serverResponse.data.name || "",
                        phone: serverResponse.data.phone || ""
                    })
                }

            } catch (error) {
                console.log(error);
                toast.error("Failed to load profile ❌")
            }
        }

        fetchData()

    }, [APIURL]) // ✅ FIXED dependency

    const submitData = async (e) => {
        e.preventDefault()

        try {
            await axios.put(EDITAPIURL, admindata)

            toast.success("Profile Updated Successfully 😊")

            setTimeout(() => {
                navigate("/admindashboard")
            }, 2000)

        } catch (error) {
            console.log(error);
            toast.error("Update failed ❌")
        }
    }

    const fillData = (e) => {
        setAdmindata({ ...admindata, [e.target.name]: e.target.value })
    }

    return (
        <>
            {/* ✅ FIX: Header always on top */}
            <div style={{
                position: "fixed",
                top: 0,
                left: 0,
                width: "100%",
                zIndex: 9999
            }}>
                <AdminHeader />
            </div>

            <ToastContainer position='top-center' autoClose={2000} />

            {/* ===== BACKGROUND ===== */}
            <div style={{
                minHeight: "100vh",
                backgroundImage: "url('https://images.unsplash.com/photo-1520607162513-77705c0f0d4a')",
                backgroundSize: "cover",
                backgroundPosition: "center",
                position: "relative",
                paddingTop: "120px"
            }}>

                {/* DARK OVERLAY */}
                <div style={{
                    position: "absolute",
                    inset: 0,
                    background: "linear-gradient(rgba(0,0,0,0.75), rgba(0,0,0,0.65))",
                    pointerEvents: "none"
                }}></div>

                {/* CONTENT */}
                <div style={{
                    position: "relative",
                    zIndex: 1,
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    minHeight: "80vh"
                }}>

                    {/* CARD */}
                    <div style={{
                        width: "420px",
                        background: "rgba(255,255,255,0.95)",
                        borderRadius: "18px",
                        padding: "30px",
                        boxShadow: "0 25px 60px rgba(0,0,0,0.5)",
                        backdropFilter: "blur(10px)"
                    }}>

                        <h3 style={{
                            textAlign: "center",
                            marginBottom: "25px",
                            color: "#333",
                            fontWeight: "700"
                        }}>
                            ✏️ Edit Admin Profile
                        </h3>

                        <form onSubmit={submitData}>

                            <div className="mb-3">
                                <label className="form-label">Name</label>
                                <input
                                    type="text"
                                    name="name"
                                    value={admindata.name}
                                    required
                                    className="form-control"
                                    onChange={fillData}
                                    style={{
                                        borderRadius: "10px",
                                        padding: "10px"
                                    }}
                                />
                            </div>

                            <div className="mb-3">
                                <label className="form-label">Phone</label>
                                <input
                                    type="text"
                                    name="phone"
                                    value={admindata.phone}
                                    required
                                    className="form-control"
                                    onChange={fillData}
                                    style={{
                                        borderRadius: "10px",
                                        padding: "10px"
                                    }}
                                />
                            </div>

                            <button
                                type="submit"
                                className="btn btn-success w-100"
                                style={{
                                    borderRadius: "10px",
                                    fontWeight: "600"
                                }}
                            >
                                Save Changes
                            </button>

                        </form>

                    </div>
                </div>
            </div>
        </>
    )
}

export default AdminEditProfile