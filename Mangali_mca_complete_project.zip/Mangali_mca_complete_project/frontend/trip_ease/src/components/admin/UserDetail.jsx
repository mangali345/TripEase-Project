import React from "react"
function UserDetail({userArray})
{
    return(
        <>
        <table className="table table-success table-striped">
  <thead>
    <tr>
      
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Phone</th>
      <th scope="col">Password</th>
      <th scope="col">City</th>
    </tr>
  </thead>
  <tbody>

        {
            userArray.map((uobj)=>{
                return(
                    <tr key={uobj.id}>
                        
                        <td>{uobj.name}</td>
                        <td>{uobj.email}</td>
                        <td>{uobj.phone}</td>
                        <td>{uobj.password}</td>
                        <td>{uobj.city}</td>
                    </tr>



                )

            })
        }
        </tbody>
        </table>
        </>
    )
}
export default UserDetail