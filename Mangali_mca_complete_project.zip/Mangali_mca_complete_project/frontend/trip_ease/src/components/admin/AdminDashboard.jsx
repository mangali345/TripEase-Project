import React, { useEffect, useState } from 'react';
import AdminHeader from './AdminHeader';
import defaultProfilePic from "../../assets/mt.jpg";
import axios from 'axios';
import { useLocation } from 'react-router-dom';

function AdminDashBoard() {

  const email = localStorage.getItem("adminEmail");
  const location = useLocation();

  const APIURL = `http://localhost:9090/admin/adminProfile/${email}`;

  const [adminData, setAdminData] = useState({ name: "", phone: "" });
  const [profilePic, setProfilePic] = useState(defaultProfilePic);

  useEffect(() => {

    const fetchData = async () => {
      try {
        const response = await axios.get(APIURL);

        setAdminData(response.data);

        let imageUrl = defaultProfilePic;

        if (location.state?.imageURL) {
          imageUrl = location.state.imageURL;
        } else if (response.data.profilePic) {
          imageUrl = `http://localhost:9090/uploads/profileimages/${response.data.profilePic}`;
        }

        setProfilePic(imageUrl);

      } catch (error) {
        console.log("Error fetching admin data:", error);
      }
    };

    fetchData();

  }, []);

  return (
    <>
      {/* ✅ FIX: Header always on top */}
      <div style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100%",
        zIndex: 9999
      }}>
        <AdminHeader />
      </div>

      {/* ===== PAGE WRAPPER ===== */}
      <div style={{
        minHeight: "100vh",
        position: "relative",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        paddingTop: "100px"
      }}>

        {/* BACKGROUND IMAGE */}
        <div style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          backgroundImage: "url('https://images.unsplash.com/photo-1522071820081-009f0129c71c')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          zIndex: 0
        }}></div>

        {/* DARK OVERLAY (NO CLICK BLOCK) */}
        <div style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          background: "rgba(0,0,0,0.6)",
          pointerEvents: "none",
          zIndex: 1
        }}></div>

        {/* CARD */}
        <div style={{
          position: "relative",
          zIndex: 2,
          width: "440px",
          padding: "40px",
          borderRadius: "22px",
          background: "rgba(255,255,255,0.92)",
          boxShadow: "0 25px 60px rgba(0,0,0,0.45)",
          textAlign: "center",
          backdropFilter: "blur(8px)"
        }}>

          {/* PROFILE IMAGE */}
          <img
            src={profilePic}
            alt="profile"
            style={{
              width: "140px",
              height: "140px",
              borderRadius: "50%",
              border: "5px solid #667eea",
              objectFit: "cover",
              marginBottom: "18px",
              boxShadow: "0 8px 20px rgba(0,0,0,0.2)"
            }}
          />

          {/* NAME */}
          <h2 style={{
            color: "#333",
            marginBottom: "5px",
            fontWeight: "700"
          }}>
            Welcome, {adminData.name}
          </h2>

          <p style={{
            color: "#777",
            marginBottom: "20px",
            fontSize: "14px"
          }}>
            Admin Dashboard Profile
          </p>

          {/* INFO BOX */}
          <div style={{
            textAlign: "left",
            marginTop: "10px",
            background: "#f4f6f8",
            padding: "18px",
            borderRadius: "14px",
            boxShadow: "inset 0 0 10px rgba(0,0,0,0.05)"
          }}>

            <p style={{ margin: "10px 0", color: "#555", fontSize: "15px" }}>
              <i className='fas fa-envelope' style={{ marginRight: "10px", color: "#667eea" }}></i>
              {email}
            </p>

            <p style={{ margin: "10px 0", color: "#555", fontSize: "15px" }}>
              <i className='fas fa-phone' style={{ marginRight: "10px", color: "#667eea" }}></i>
              {adminData.phone}
            </p>

          </div>

        </div>

      </div>
    </>
  );
}

export default AdminDashBoard;