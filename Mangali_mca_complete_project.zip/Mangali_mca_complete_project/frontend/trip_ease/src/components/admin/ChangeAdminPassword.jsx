import AdminHeader from './AdminHeader'
import axios from 'axios'
import { useState } from 'react'
import { ToastContainer, toast } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'

function ChangeAdminPassword() {

    const email = localStorage.getItem("adminEmail")
    const EDITAPIURL = `http://localhost:9090/admin/updatePassword/${email}`

    const [passwordData, setPasswordData] = useState({
        oldpass: "",
        newpass: "",
        confirmpass: ""
    })

    const fetchData = (e) => {
        setPasswordData({
            ...passwordData,
            [e.target.name]: e.target.value
        })
    }

    const submitData = (e) => {
        e.preventDefault()

        if (passwordData.newpass !== passwordData.confirmpass) {
            toast.error("New Password and Confirm Password must be same")
            return
        }

        axios.patch(EDITAPIURL, passwordData)
            .then((res) => {
                if (res.data === "success") {
                    toast.success("Password changed successfully!")
                    setPasswordData({ oldpass: "", newpass: "", confirmpass: "" })
                } else {
                    toast.error("Old password is incorrect")
                }
            })
            .catch(() => toast.error("Error updating password"))
    }

    return (
        <>
            {/* 🔥 HEADER ALWAYS TOP (CLICK SAFE) */}
            <div style={{
                position: "relative",
                zIndex: 99999
            }}>
                <AdminHeader />
            </div>

            <ToastContainer position="top-right" autoClose={3000} />

            {/* PAGE */}
            <div style={{
                minHeight: "100vh",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                backgroundImage: "url('https://images.unsplash.com/photo-1520607162513-77705c0f0d4a')",
                backgroundSize: "cover",
                backgroundPosition: "center",
                position: "relative"
            }}>

                {/* ⚠️ ONLY VISUAL OVERLAY (NO CLICK BLOCK) */}
                <div style={{
                    position: "absolute",
                    inset: 0,
                    background: "rgba(0,0,0,0.65)",
                    pointerEvents: "none",
                    zIndex: 1
                }}></div>

                {/* FORM CARD */}
                <div style={{
                    position: "relative",
                    zIndex: 2,
                    width: "100%",
                    maxWidth: "420px"
                }}>

                    <div style={{
                        background: "rgba(255,255,255,0.95)",
                        padding: "30px",
                        borderRadius: "18px",
                        boxShadow: "0 25px 60px rgba(0,0,0,0.5)"
                    }}>

                        <h3 style={{ textAlign: "center", marginBottom: "20px" }}>
                            🔐 Change Password
                        </h3>

                        <form onSubmit={submitData}>

                            <input
                                type="password"
                                name="oldpass"
                                value={passwordData.oldpass}
                                onChange={fetchData}
                                placeholder="Old Password"
                                className="form-control mb-3"
                            />

                            <input
                                type="password"
                                name="newpass"
                                value={passwordData.newpass}
                                onChange={fetchData}
                                placeholder="New Password"
                                className="form-control mb-3"
                            />

                            <input
                                type="password"
                                name="confirmpass"
                                value={passwordData.confirmpass}
                                onChange={fetchData}
                                placeholder="Confirm Password"
                                className="form-control mb-3"
                            />

                            <button className="btn btn-dark w-100">
                                Update Password
                            </button>

                        </form>

                    </div>

                </div>
            </div>
        </>
    )
}

export default ChangeAdminPassword