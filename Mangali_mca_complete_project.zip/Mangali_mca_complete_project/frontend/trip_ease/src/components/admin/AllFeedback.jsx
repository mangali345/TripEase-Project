import React from "react"
import AdminHeader from './AdminHeader'
import axios from "axios"
import { useState, useEffect } from "react"
import FeedbackDetail from "./FeedbackDetail"

function AllFeedback() {

    const APIURL = "http://localhost:9090/admin/allFeedbacks"
    const [feeddata, setFeedData] = useState([{}])

    useEffect(() => {
        const fetchData = async () => {
            try {
                const serverResponse = await axios.get(APIURL)
                setFeedData(serverResponse.data)
            }
            catch (error) {
                console.log(error);
            }
        }
        fetchData()
    }, [])

    const deleteFeedback = async (id) => {
        const DELETEAPIURL = `http://localhost:9090/admin/deleteFeedback/${id}`
        try {
            await axios.delete(DELETEAPIURL)

            const updatedArray = feeddata.filter((fobj) => fobj.id !== id)
            setFeedData(updatedArray)

        } catch (error) {
            console.log(error)
        }
    }

    return (
        <>
            {/* ✅ FIX: Header always clickable */}
            <div style={{
                position: "fixed",
                top: 0,
                left: 0,
                width: "100%",
                zIndex: 9999
            }}>
                <AdminHeader />
            </div>

            {/* ===== FULL PAGE BACKGROUND ===== */}
            <div style={{
                minHeight: "100vh",
                backgroundImage: "url('https://images.unsplash.com/photo-1500530855697-b586d89ba3ee')",
                backgroundSize: "cover",
                backgroundPosition: "center",
                position: "relative",
                paddingTop: "110px"
            }}>

                {/* DARK OVERLAY (NO CLICK BLOCK) */}
                <div style={{
                    position: "absolute",
                    inset: 0,
                    background: "linear-gradient(rgba(0,0,0,0.78), rgba(0,0,0,0.65))",
                    pointerEvents: "none"
                }}></div>

                {/* CONTENT */}
                <div style={{
                    position: "relative",
                    zIndex: 1,
                    padding: "30px"
                }}>

                    {/* HEADER */}
                    <div style={{
                        textAlign: "center",
                        marginBottom: "30px"
                    }}>
                        <h1 style={{
                            color: "white",
                            fontWeight: "700",
                            marginBottom: "10px"
                        }}>
                            ⭐ User Feedback Management
                        </h1>

                        <p style={{
                            color: "#d1d1d1",
                            fontSize: "14px"
                        }}>
                            View and manage all user feedback submissions
                        </p>
                    </div>

                    {/* CARD CONTAINER */}
                    <div style={{
                        maxWidth: "1150px",
                        margin: "auto",
                        background: "rgba(255,255,255,0.92)",
                        backdropFilter: "blur(10px)",
                        borderRadius: "18px",
                        padding: "25px",
                        boxShadow: "0 25px 60px rgba(0,0,0,0.5)"
                    }}>

                        {/* TOP BAR */}
                        <div style={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            marginBottom: "15px"
                        }}>
                            <h4 style={{ margin: 0, color: "#333" }}>
                                💬 All Feedbacks
                            </h4>

                            <span style={{
                                background: "#ff9800",
                                color: "white",
                                padding: "5px 12px",
                                borderRadius: "20px",
                                fontSize: "12px"
                            }}>
                                Total: {feeddata.length}
                            </span>
                        </div>

                        {/* TABLE / COMPONENT */}
                        <FeedbackDetail
                            feedArray={feeddata}
                            deleteById={deleteFeedback}
                        />

                    </div>

                </div>
            </div>
        </>
    )
}

export default AllFeedback