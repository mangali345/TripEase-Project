import React, { useState, useEffect } from "react";
import AdminHeader from "../admin/AdminHeader";
import axios from "axios";
import AllCompanyDetails from "./AllCompanyDetails";

function AllCompany() {

  const APIURL = "http://localhost:9090/user/allTravelPlanner";

  const [companydata, setCompanyData] = useState([]);

  useEffect(() => {

    const fetchData = async () => {
      try {
        const serverResponse = await axios.get(APIURL);
        setCompanyData(serverResponse.data);
      } catch (error) {
        console.log(error);
      }
    };

    fetchData();

  }, []);

  return (
    <>
      {/* ✅ FIX: Header always on top */}
      <div style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100%",
        zIndex: 9999
      }}>
        <AdminHeader />
      </div>

      {/* ===== PAGE WRAPPER ===== */}
      <div style={{
        minHeight: "100vh",
        backgroundImage: "url('https://images.unsplash.com/photo-1501785888041-af3ef285b470')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        position: "relative",
        paddingTop: "110px"
      }}>

        {/* DARK OVERLAY (NO CLICK BLOCK) */}
        <div style={{
          position: "absolute",
          inset: 0,
          background: "linear-gradient(rgba(0,0,0,0.75), rgba(0,0,0,0.65))",
          pointerEvents: "none",
          zIndex: 0
        }}></div>

        {/* CONTENT */}
        <div style={{
          position: "relative",
          zIndex: 1,
          padding: "30px"
        }}>

          {/* HEADER */}
          <div style={{
            textAlign: "center",
            marginBottom: "30px"
          }}>
            <h1 style={{
              color: "white",
              fontWeight: "700",
              marginBottom: "10px"
            }}>
              🏢 Travel Planner Companies
            </h1>

            <p style={{
              color: "#d1d1d1",
              fontSize: "14px"
            }}>
              Manage all registered travel planner companies
            </p>
          </div>

          {/* CARD CONTAINER */}
          <div style={{
            maxWidth: "1150px",
            margin: "auto",
            background: "rgba(255,255,255,0.92)",
            backdropFilter: "blur(10px)",
            borderRadius: "18px",
            padding: "25px",
            boxShadow: "0 25px 60px rgba(0,0,0,0.5)"
          }}>

            {/* TOP BAR */}
            <div style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: "15px"
            }}>
              <h4 style={{ margin: 0, color: "#333" }}>
                📊 Company List
              </h4>

              <span style={{
                background: "#28a745",
                color: "white",
                padding: "5px 12px",
                borderRadius: "20px",
                fontSize: "12px"
              }}>
                Total: {companydata.length}
              </span>
            </div>

            {/* DATA TABLE */}
            <AllCompanyDetails companyArray={companydata} />

          </div>

        </div>
      </div>
    </>
  );
}

export default AllCompany;