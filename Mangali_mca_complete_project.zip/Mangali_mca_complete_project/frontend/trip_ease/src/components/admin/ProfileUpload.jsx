import React, { useState, useRef } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import AdminHeader from './AdminHeader'

function ProfileUpload() {

    const fileRef = useRef(null)
    const navigate = useNavigate()

    const UPLOADURL = "http://localhost:9090/admin/uploadPic"

    const [profilePic, setProfilePic] = useState(null)
    const email = localStorage.getItem("adminEmail")

    const [profileData, setProfileData] = useState({
        email: email,
        description: ""
    })

    const fetchData = (e) => {
        const { name, value, files, type } = e.target

        if (type === "file") {
            const file = files[0]
            if (!file) return

            setProfilePic(file)
        } else {
            setProfileData({ ...profileData, [name]: value })
        }
    }

    const submitForm = async (e) => {
        e.preventDefault()

        const formData = new FormData()

        formData.append(
            "profileImageDetail",
            new Blob([JSON.stringify(profileData)], { type: 'application/json' })
        )

        formData.append("imageFile", profilePic)

        try {
            const serverResponse = await axios.post(UPLOADURL, formData)

            navigate("/adminDashBoard", {
                state: { imageURL: serverResponse.data.imageURL }
            })

        } catch (err) {
            console.log(err)
        }
    }

    return (
        <>
            {/* 🔥 HEADER ALWAYS TOP */}
            <div style={{ position: "relative", zIndex: 9999 }}>
                <AdminHeader />
            </div>

            {/* PAGE */}
            <div style={{
                minHeight: "100vh",
                backgroundImage: "url('https://images.unsplash.com/photo-1504384308090-c894fdcc538d')",
                backgroundSize: "cover",
                backgroundPosition: "center",
                position: "relative",
                paddingTop: "100px"
            }}>

                {/* OVERLAY (NON CLICK BLOCKING) */}
                <div style={{
                    position: "absolute",
                    inset: 0,
                    background: "rgba(0,0,0,0.6)",
                    zIndex: 1,
                    pointerEvents: "none"
                }}></div>

                {/* CONTENT */}
                <div style={{
                    position: "relative",
                    zIndex: 2,
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    minHeight: "80vh"
                }}>

                    <div style={{
                        width: "460px",
                        background: "rgba(255,255,255,0.95)",
                        borderRadius: "18px",
                        padding: "30px",
                        boxShadow: "0 25px 60px rgba(0,0,0,0.5)"
                    }}>

                        <h3 style={{ textAlign: "center", marginBottom: "20px" }}>
                            📸 Upload Admin Profile Picture
                        </h3>

                        <form onSubmit={submitForm}>

                            <input
                                type="file"
                                className="form-control mb-3"
                                onChange={fetchData}
                                ref={fileRef}
                            />

                            <textarea
                                name="description"
                                className="form-control mb-3"
                                rows="4"
                                value={profileData.description}
                                onChange={fetchData}
                            />

                            <button className="btn btn-dark w-100">
                                Upload Image
                            </button>

                        </form>

                    </div>

                </div>
            </div>
        </>
    )
}

export default ProfileUpload