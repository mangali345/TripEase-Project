import React from 'react'
import AdminHeader from './AdminHeader'
import axios from 'axios'
import { useState, useEffect } from 'react'
import ContactDetail from './ContactDetail'

function AllContacts() {

    const APIURL = "http://localhost:9090/admin/allContacts"

    const [contactdata, setContactData] = useState([{}])

    useEffect(() => {
        const fetchData = async () => {
            try {
                const serverResponse = await axios.get(APIURL)
                setContactData(serverResponse.data)
            }
            catch (error) {
                console.log(error);
            }
        }

        fetchData()
    }, [])

    // DELETE CONTACT
    const deleteContact = async (id) => {

        const DELETEAPIURL = `http://localhost:9090/admin/deleteContact/${id}`

        try {
            await axios.delete(DELETEAPIURL)

            const updatedArray = contactdata.filter((cobj) => {
                return cobj.id != id
            })

            setContactData(updatedArray)

        }
        catch (err) {
            console.log(err);
        }
    }

    return (
        <>
            {/* ✅ FIX: AdminHeader always on top */}
            <div style={{
                position: "fixed",
                top: 0,
                left: 0,
                width: "100%",
                zIndex: 9999
            }}>
                <AdminHeader />
            </div>

            {/* ===== BACKGROUND WRAPPER ===== */}
            <div style={{
                minHeight: "100vh",
                backgroundImage: "url('https://images.unsplash.com/photo-1521737604893-d14cc237f11d')",
                backgroundSize: "cover",
                backgroundPosition: "center",
                position: "relative",
                paddingTop: "110px"
            }}>

                {/* DARK OVERLAY (NO CLICK BLOCK) */}
                <div style={{
                    position: "absolute",
                    inset: 0,
                    background: "linear-gradient(rgba(0,0,0,0.75), rgba(0,0,0,0.65))",
                    pointerEvents: "none",
                    zIndex: 0
                }}></div>

                {/* CONTENT */}
                <div style={{
                    position: "relative",
                    zIndex: 1,
                    padding: "30px"
                }}>

                    {/* HEADER */}
                    <div style={{ textAlign: "center", marginBottom: "30px" }}>
                        <h1 style={{
                            color: "white",
                            fontWeight: "700",
                            marginBottom: "10px"
                        }}>
                            📩 Contact Management
                        </h1>

                        <p style={{
                            color: "#d1d1d1",
                            fontSize: "14px"
                        }}>
                            Manage all user queries and messages
                        </p>
                    </div>

                    {/* CARD */}
                    <div style={{
                        maxWidth: "1100px",
                        margin: "auto",
                        background: "rgba(255,255,255,0.92)",
                        backdropFilter: "blur(10px)",
                        borderRadius: "18px",
                        padding: "25px",
                        boxShadow: "0 25px 60px rgba(0,0,0,0.5)"
                    }}>

                        {/* TOP BAR */}
                        <div style={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            marginBottom: "15px"
                        }}>
                            <h4 style={{ margin: 0, color: "#333" }}>
                                📬 All Contact Requests
                            </h4>

                            <span style={{
                                background: "#ff6b6b",
                                color: "white",
                                padding: "5px 12px",
                                borderRadius: "20px",
                                fontSize: "12px"
                            }}>
                                Total: {contactdata.length}
                            </span>
                        </div>

                        {/* TABLE */}
                        <ContactDetail
                            contactArray={contactdata}
                            deleteById={deleteContact}
                        />

                    </div>

                </div>
            </div>
        </>
    )
}

export default AllContacts