import React, { useState } from "react"
import Header from "../common/Header"
import Footer from "../common/Footer"
import '../../css/admin_login.css'
import axios from "axios"
import { useNavigate } from "react-router-dom"

function AdminLogin() {
  const navigate = useNavigate()

  const APIURL = "http://localhost:9090/admin/login"
  const [validate, setValidate] = useState(false)
  const [data, setData] = useState({
    email: "",
    password: ""
  })

  const fetchData = (e) => {
    setData({
      ...data,
      [e.target.name]: e.target.value
    })
  }

  const submitForm = async (e) => {
    e.preventDefault()

    const form = e.currentTarget
    if (!form.checkValidity()) {
      setValidate(true)
      return
    }

    try {
      const serverResponse = await axios.post(APIURL, data)

      const serverMessage = serverResponse.data

      if (serverMessage === "success") {
        localStorage.setItem("adminEmail", data.email)
        navigate("/admindashboard")
      } else {
        alert(serverMessage)
      }

    } catch (error) {
      console.log(error)
      alert("Login failed!")
    }
  }

  return (
    <>
      <Header />

      {/* ===== Background Section ===== */}
      <div style={{
        minHeight: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        backgroundImage: "url('https://images.unsplash.com/photo-1557682250-33bd709cbe85')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        paddingTop: "100px"
      }}>

        {/* Overlay */}
        <div style={{
          position: "absolute",
          width: "100%",
          height: "100%",
          background: "rgba(0,0,0,0.6)"
        }}></div>

        {/* Card */}
        <div style={{
          position: "relative",
          width: "850px",
          display: "flex",
          background: "rgba(255,255,255,0.95)",
          borderRadius: "20px",
          overflow: "hidden",
          boxShadow: "0 20px 50px rgba(0,0,0,0.4)"
        }}>

          {/* Image Side */}
          <div style={{
            flex: 1,
            backgroundImage: "url('/hii.jpg')",
            backgroundSize: "cover",
            backgroundPosition: "center"
          }}></div>

          {/* Form Side */}
          <div style={{
            flex: 1,
            padding: "40px"
          }}>

            <h3 style={{
              textAlign: "center",
              marginBottom: "25px",
              color: "#333",
              fontWeight: "600"
            }}>
              Admin Login
            </h3>

            <form
              onSubmit={submitForm}
              noValidate
              className={`needs-validation ${validate ? 'was-validated' : ''}`}
            >

              {/* Email */}
              <div className="form-floating mb-3">
                <input
                  type="email"
                  className="form-control"
                  placeholder="Enter your email"
                  required
                  name="email"
                  value={data.email}
                  onChange={fetchData}
                />
                <label>Email</label>
                <div className="invalid-feedback">
                  Email Required
                </div>
              </div>

              {/* Password */}
              <div className="form-floating mb-3">
                <input
                  type="password"
                  className="form-control"
                  placeholder="Password"
                  required
                  name="password"
                  value={data.password}
                  onChange={fetchData}
                />
                <label>Password</label>
                <div className="invalid-feedback">
                  Password Required
                </div>
              </div>

              {/* Button */}
              <button
                className="btn w-100"
                style={{
                  background: "linear-gradient(135deg, #667eea, #764ba2)",
                  color: "white",
                  padding: "12px",
                  fontWeight: "600",
                  borderRadius: "10px",
                  border: "none",
                  transition: "0.3s"
                }}
                onMouseOver={(e) => e.target.style.transform = "scale(1.03)"}
                onMouseOut={(e) => e.target.style.transform = "scale(1)"}
              >
                Login
              </button>

            </form>

          </div>
        </div>
      </div>

      <Footer />
    </>
  )
}

export default AdminLogin