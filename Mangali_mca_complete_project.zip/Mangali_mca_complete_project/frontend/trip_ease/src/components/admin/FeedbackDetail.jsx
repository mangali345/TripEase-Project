import React from "react"

function FeedbackDetail({feedArray, deleteById})
{
    return(
        <>

         <table className="table table-success table-striped">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Email</th>
      <th scope="col">Review</th>
      <th scope="col">Rating</th>
      <th scope="col">Remove Feedback</th>
      
    </tr>
  </thead>
  <tbody>

        {
            feedArray.map((fobj)=>{
                return(
                    <tr key={fobj.id}>
                        <td>{fobj.id}</td>
                        <td>{fobj.email}</td>
                        <td>{fobj.review}</td>
                        <td>{fobj.rating}</td>
                        <th><button className="btn btn-danger" onClick={
                            ()=>{deleteById(fobj.id)}
                        }>Delete</button></th>
                    </tr>



                )

            })
        }
        </tbody>
        </table>
        </>
    )
}
export default FeedbackDetail