import axios from 'axios'
import { useEffect, useState } from 'react'
import TravelPlannerHeader from './TravelPlannerHeader'
import { ToastContainer, toast } from 'react-toastify'
import "react-toastify/dist/ReactToastify.css";
import { useNavigate } from 'react-router-dom';

function TpEditProfile() {

    const email = localStorage.getItem("travelplannerEmail")
    const APIURL = `http://localhost:9090/travelplanner/travelplannerProfile/${email}`
    const EDITAPIURL = `http://localhost:9090/travelplanner/editProfile/${email}`

    const [plannerdata, setPlannerdata] = useState({
        name: "",
        phone: "",
        city: "",
        address: ""
    })

    const navigate = useNavigate()

    useEffect(() => {
        const fetchData = async () => {
            try {
                const serverResponse = await axios.get(APIURL)

                setPlannerdata({
                    name: serverResponse.data.name,
                    phone: serverResponse.data.phone,
                    city: serverResponse.data.city,
                    address: serverResponse.data.address
                })

            } catch (error) {
                console.log(error);
            }
        }

        fetchData()
    }, [APIURL])

    const submitData = async (e) => {
        e.preventDefault()
        try {
            const serverResponse = await axios.put(EDITAPIURL, plannerdata)

            toast.success("Profile Updated Successfully 😊")

            setTimeout(() => {
                navigate("/planner/home")
            }, 3000)

        } catch (error) {
            console.log(error);
            toast.error("Failed to update profile 😔")
        }
    }

    const fillData = (e) => {
        setPlannerdata({ ...plannerdata, [e.target.name]: e.target.value })
    }

    return (
        <>
            <TravelPlannerHeader />
            <ToastContainer position='top-center' autoClose={3000} />

            <div style={{
                minHeight: "100vh",
                backgroundImage: "url('https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1')",
                backgroundSize: "cover",
                backgroundPosition: "center",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                paddingTop: "80px"
            }}>

                {/* Overlay */}
                <div style={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%",
                    backgroundColor: "rgba(0,0,0,0.5)",
                    zIndex: 0
                }}></div>

                <div className="container" style={{ position: "relative", zIndex: 1 }}>
                    <div className="row justify-content-center">
                        <div className="col-md-8 col-lg-5">

                            <div style={{
                                borderRadius: "20px",
                                backdropFilter: "blur(10px)",
                                background: "rgba(255,255,255,0.9)",
                                boxShadow: "0 10px 30px rgba(0,0,0,0.3)",
                                padding: "30px"
                            }}>

                                <h3 className="text-center mb-4" style={{ fontWeight: "bold" }}>
                                    <i className="fas fa-user-edit me-2 text-primary"></i>
                                    Edit Profile
                                </h3>

                                <form onSubmit={submitData}>

                                    <div className='mb-3'>
                                        <label style={{ fontWeight: "500" }}>Name</label>
                                        <input
                                            type="text"
                                            name="name"
                                            value={plannerdata.name}
                                            required
                                            className='form-control'
                                            onChange={fillData}
                                            style={{ borderRadius: "10px", padding: "10px" }}
                                        />
                                    </div>

                                    <div className='mb-3'>
                                        <label style={{ fontWeight: "500" }}>Phone</label>
                                        <input
                                            type="text"
                                            name="phone"
                                            value={plannerdata.phone}
                                            required
                                            className='form-control'
                                            onChange={fillData}
                                            style={{ borderRadius: "10px", padding: "10px" }}
                                        />
                                    </div>

                                    <div className='mb-3'>
                                        <label style={{ fontWeight: "500" }}>City</label>
                                        <input
                                            type="text"
                                            name="city"
                                            value={plannerdata.city}
                                            required
                                            className='form-control'
                                            onChange={fillData}
                                            style={{ borderRadius: "10px", padding: "10px" }}
                                        />
                                    </div>

                                    <div className='mb-3'>
                                        <label style={{ fontWeight: "500" }}>Address</label>
                                        <textarea
                                            name="address"
                                            value={plannerdata.address}
                                            required
                                            className='form-control'
                                            rows="3"
                                            onChange={fillData}
                                            style={{ borderRadius: "10px", padding: "10px" }}
                                        ></textarea>
                                    </div>

                                    <div className='text-center mt-4'>
                                        <button style={{
                                            background: "linear-gradient(45deg, #4facfe, #00f2fe)",
                                            border: "none",
                                            padding: "10px 25px",
                                            borderRadius: "25px",
                                            color: "#fff",
                                            fontWeight: "bold",
                                            transition: "0.3s"
                                        }}>
                                            Save Changes
                                        </button>
                                    </div>

                                </form>

                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </>
    )
}

export default TpEditProfile;