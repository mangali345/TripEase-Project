import TravelPlannerHeader from './TravelPlannerHeader'
import axios from 'axios'
import { useState } from 'react'
import { ToastContainer, toast } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'

function ChangeTpPassword() {
    
    const email = localStorage.getItem("travelplannerEmail")

    const EDITAPIURL = `http://localhost:9090/travelplanner/updatePassword/${email}`

    const [passwordData, setPasswordData] = useState({
        oldpass: "",
        newpass: "",
        confirmpass: ""
    })

    const fetchData = (e) => {
        setPasswordData({
            ...passwordData,
            [e.target.name]: e.target.value
        })
    }

    const submitData = (e) => {

        e.preventDefault()

        if (passwordData.newpass !== passwordData.confirmpass) {
            toast.error("New Password and Confirm Password must be same")
            return
        }

        axios.put(EDITAPIURL, passwordData)
            .then((res) => {

                if (res.data === "success") {

                    toast.success("Password changed successfully!")

                    setPasswordData({
                        oldpass: "",
                        newpass: "",
                        confirmpass: ""
                    })
                }
                else {
                    toast.error("Old password is incorrect. Please try again.")
                }

            })
            .catch((err) => {
                console.log(err)
                toast.error("Error updating password")
            })
    }

    return (
        <>
            <TravelPlannerHeader />

            <ToastContainer position="top-right" autoClose={3000} />

            <div style={{
                minHeight: "100vh",
                backgroundImage: "url('https://images.unsplash.com/photo-1501785888041-af3ef285b470')",
                backgroundSize: "cover",
                backgroundPosition: "center",
                display: "flex",
                justifyContent: "center",
                alignItems: "center"
            }}>

                {/* Overlay */}
                <div style={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%",
                    backgroundColor: "rgba(0,0,0,0.5)"
                }}></div>

                <div style={{
                    position: "relative",
                    zIndex: 1,
                    width: "350px",
                    padding: "30px",
                    borderRadius: "20px",
                    background: "rgba(255,255,255,0.9)",
                    backdropFilter: "blur(10px)",
                    boxShadow: "0 10px 30px rgba(0,0,0,0.3)"
                }}>

                    <h2 style={{
                        textAlign: "center",
                        marginBottom: "20px",
                        fontWeight: "bold"
                    }}>
                        🔐 Change Password
                    </h2>

                    <form onSubmit={submitData}>

                        <div style={{ marginBottom: "15px" }}>
                            <label>Old Password</label><br />
                            <input
                                type="password"
                                name="oldpass"
                                value={passwordData.oldpass}
                                onChange={fetchData}
                                required
                                style={{
                                    width: "100%",
                                    padding: "10px",
                                    borderRadius: "10px",
                                    border: "1px solid #ccc",
                                    marginTop: "5px"
                                }}
                            />
                        </div>

                        <div style={{ marginBottom: "15px" }}>
                            <label>New Password</label><br />
                            <input
                                type="password"
                                name="newpass"
                                value={passwordData.newpass}
                                onChange={fetchData}
                                required
                                style={{
                                    width: "100%",
                                    padding: "10px",
                                    borderRadius: "10px",
                                    border: "1px solid #ccc",
                                    marginTop: "5px"
                                }}
                            />
                        </div>

                        <div style={{ marginBottom: "20px" }}>
                            <label>Confirm New Password</label><br />
                            <input
                                type="password"
                                name="confirmpass"
                                value={passwordData.confirmpass}
                                onChange={fetchData}
                                required
                                style={{
                                    width: "100%",
                                    padding: "10px",
                                    borderRadius: "10px",
                                    border: "1px solid #ccc",
                                    marginTop: "5px"
                                }}
                            />
                        </div>

                        <button
                            type="submit"
                            style={{
                                width: "100%",
                                padding: "10px",
                                borderRadius: "25px",
                                border: "none",
                                background: "linear-gradient(45deg, #4facfe, #00f2fe)",
                                color: "#fff",
                                fontWeight: "bold",
                                cursor: "pointer",
                                transition: "0.3s"
                            }}
                        >
                            Update Password
                        </button>

                    </form>

                </div>
            </div>
        </>
    )
}

export default ChangeTpPassword;