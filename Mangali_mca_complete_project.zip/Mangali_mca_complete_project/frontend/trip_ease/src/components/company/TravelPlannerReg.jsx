import React from "react"
import Footer from "../common/Footer"
import Header from "../common/Header"
import { useState } from "react";
import Swal from 'sweetalert2'
import axios from 'axios'

function TravelPlannerReg()
{
  const APIURL="http://localhost:9090/travelplanner/registration"
  const[data,setData]=useState({name:"",email:"",password:"",company:"",phone:"",city:"",address:"",registrationNo:""})
  const [validate, setValidate]=useState(false)
     const fetchData=(e)=>{
      console.log(e.target); //object return
      const{name, value} = e.target //destructure name means control name
  
      const alphaRegex= /^[A-Za-z\s]*$/;
      const numberRegex= /^[0-9]*$/;
       if((name==="name") && !alphaRegex.test(value))
                  {
                  // alert("Only alphabets are allowed!");
          
                  Swal.fire({
            title: "Format Error!!!",
            text: "input only alphabet",
            icon: "error"
          });
          return;
                      }
                      if((name==="phone") && !numberRegex.test(value))
                      {
                      // alert("Only digits are allowed!");
                       Swal.fire({
                title: "Format Error!!!",
                text: "input only digit",
                icon: "error"
              });
                      return;
                      }
                      setData({...data,[name]:value})
              
                 }
                 const submitForm= async(e)=>{
          e.preventDefault();
           // alert("in function")
           console.log(e.currentTarget);
           const form= e.currentTarget
           if (!form.checkValidity()) {
               e.preventDefault()
               e.stopPropagation()
             }
             setValidate(true)
             try{
      const serverResponse=await axios.post(APIURL,data)
      console.log("send by spring boot"+serverResponse);
      console.log(serverResponse.data);
      
      

    }
    catch(error)
    {
      console.log(error);
      

    }
           
       
         }
     //code to check email existence
         const checkEmail=async(email)=>
         {
               const APIURLCheckEmail = `http://localhost:9090/travelplanner/checkEmail/${email}`
               try{
                       const serverResponse=await axios.get(APIURLCheckEmail)
                       console.log(serverResponse.data);
                       if(serverResponse.data==='exists'){
                        alert(email+"already exists please take another one")
                        document.getElementById("email").value=""
                       
                       }
               }
               catch(err)
               {
                console.log(err);
                
               }
         }

          
  
  
    return(
        <>
        <Header/>
        <div
  className="d-flex justify-content-center align-items-center "
style={{ background:  "linear-gradient(135deg, #1e3c72, #2a5298)" }}
>
  <div
    className="card shadow-lg p-4"
    style={{ width: "100%", maxWidth: "500px", borderRadius: "20px" }}
  >
    <h3 className="text-center mb-4">Travel Planner Registration</h3>

    <form onSubmit={submitForm}>

      {/* Full Name */}
      <div className="form-floating mb-3 position-relative">
        <i className="fa-solid fa-user position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
        <input
          type="text"
          className="form-control ps-5"
          id="name"
          placeholder="Full Name"
          required name="name" value={data.name}onChange={fetchData}
        />
        <label htmlFor="name" className="ms-4">Full Name</label>
      </div>

      {/* Email */}
      <div className="form-floating mb-3 position-relative">
        <i className="fa-solid fa-envelope position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
        <input
          type="email"
          className="form-control ps-5"
          id="email"
          placeholder="Email"
          required name="email" value={data.email}onChange={fetchData}
          onBlur={()=>{
                checkEmail(data.email)
              }}
              
        />
        <label htmlFor="email" className="ms-4">Email Address</label>
      </div>

      {/* Password */}
      <div className="form-floating mb-3 position-relative">
        <i className="fa-solid fa-lock position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
        <input
          type="password"
          className="form-control ps-5"
          id="password"
          placeholder="Password"
          required name="password" value={data.password}onChange={fetchData}
        />
        <label htmlFor="password" className="ms-4">Password</label>
      </div>

      {/* Company */}
      <div className="form-floating mb-3 position-relative">
        <i className="fa-solid fa-building position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
        <input
          type="text"
          className="form-control ps-5"
          id="company"
          placeholder="Company Name"
          required name="company" value={data.company}onChange={fetchData}
        />
        <label htmlFor="company" className="ms-4">Company Name</label>
      </div>

      {/* Phone */}
      <div className="form-floating mb-3 position-relative">
        <i className="fa-solid fa-phone position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
        <input
          type="tel"
          className="form-control ps-5"
          id="phone"
          placeholder="Phone"
          required name="phone" value={data.phone}onChange={fetchData}
        />
        <label htmlFor="phone" className="ms-4">Phone Number</label>
      </div>

      {/* City */}
      <div className="form-floating mb-3 position-relative">
        <i className="fa-solid fa-city position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
        <input
          type="text"
          className="form-control ps-5"
          id="city"
          placeholder="City"
          required name="city" value={data.city}onChange={fetchData}
        />
        <label htmlFor="city" className="ms-4">City</label>
      </div>

      {/* Address */}
      <div className="form-floating mb-3 position-relative">
        <i className="fa-solid fa-location-dot position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
        <textarea
          className="form-control ps-5"
          placeholder="Address"
          id="address"
          required name="address" value={data.address}onChange={fetchData}
          style={{ height: "90px" }}
        ></textarea>
        <label htmlFor="address" className="ms-4">Address</label>
      </div>

      {/* Registration Number */}
      <div className="form-floating mb-4 position-relative">
        <i className="fa-solid fa-id-card position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
        <input
          type="text"
          className="form-control ps-5"
          id="registrationNo"
          placeholder="Registration Number"
          required name="registrationNo" value={data.registrationNo}onChange={fetchData}
        />
        <label htmlFor="registrationNo" className="ms-4">
          Registration Number
        </label>
      </div>

      <button type="submit" className="btn btn-primary w-100 py-2">
        <i className="fa-solid fa-user-plus me-2"></i>
        Register
      </button>

    </form>
  </div>
</div>
<Footer/>
        </>
    )
}
export default TravelPlannerReg