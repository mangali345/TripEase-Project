import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

function TravelPlannerHeader() {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();

  // ✅ Check correct localStorage key
  useEffect(() => {
    if (!localStorage.getItem("travelplannerEmail")) {
      navigate("/login/user");
    }
  }, [navigate]);

  const logout = () => {
    localStorage.removeItem("travelplannerEmail");
    navigate("/login/company");
  };

  return (
    <>
      <nav
        className="navbar navbar-dark fixed-top px-3"
        style={{ background: "linear-gradient(90deg, #141e30, #243b55)", height: "60px", zIndex: 1000 }}
      >
        <div className="container-fluid d-flex justify-content-between">
          <span className="navbar-brand mb-0 h5 text-white">Travel Planner Dashboard</span>
          <button className="btn text-white" onClick={() => setIsOpen(!isOpen)}>
            <i className="fa-solid fa-bars fs-4"></i>
          </button>
        </div>
      </nav>

      <div className="user-sidebar" style={{ right: isOpen ? "0" : "-260px" }}>
        <div className="text-center text-white mb-4">
          <i className="fa-solid fa-user-circle fs-1 mb-2"></i>
          <h6>Welcome Planner</h6>
        </div>

        <ul className="nav flex-column px-3">
                    <li className="nav-item mb-2">
            <Link to="/tpedit" className="nav-link menu-item text-white" onClick={() => setIsOpen(false)}>
              <i className="fa-solid fa-user-pen me-2"></i> Edit Profile
            </Link>
          </li>
          <li className="nav-item mb-2">
            <Link to="/changetppass" className="nav-link menu-item text-white" onClick={() => setIsOpen(false)}>
              <i className="fa-solid fa-lock me-2"></i> Change Password
            </Link>
          </li>
          <li className="nav-item mb-2">
            <Link to="/tpimageupload" className="nav-link menu-item text-white" onClick={() => setIsOpen(false)}>
              <i className="fa-solid fa-upload me-2"></i> Profile Upload
            </Link>
          </li>
          <li className="nav-item mb-2">
            <Link to="/trippack" className="nav-link menu-item text-white" onClick={() => setIsOpen(false)}>
              <i className="fa fa-umbrella-beach"></i> Trip Package
            </Link>
          </li>
          <li className="nav-item mb-2">
            <Link to="/mytrip" className="nav-link menu-item text-white" onClick={() => setIsOpen(false)}>
              <i className="fa fa-list"></i> View Packages
            </Link>
          </li>
          <li className="nav-item mb-2">
            <Link to="/request" className="nav-link menu-item text-white" onClick={() => setIsOpen(false)}>
              <i className="fa fa-clipboard-list"></i> Booking Requests
            </Link>
          </li>

          <li className="nav-item">
            <button className="nav-link menu-item text-white" onClick={logout} style={{ border: "none", background: "none", padding: 0 }}>
              <i className="fa-solid fa-right-from-bracket me-2"></i> Logout
            </button>
          </li>
        </ul>
      </div>

      {isOpen && (
        <div onClick={() => setIsOpen(false)} style={{ position: "fixed", top: 0, left: 0, width: "100%", height: "100%", backgroundColor: "rgba(0,0,0,0.3)", zIndex: 998 }} />
      )}

      <style>{`
        body { margin: 0; }
        .user-sidebar { position: fixed; top: 60px; width: 260px; height: calc(100vh - 60px); background: linear-gradient(180deg, #0f2027, #203a43, #2c5364); padding-top: 40px; box-shadow: -4px 0 15px rgba(0,0,0,0.3); transition: right 0.3s ease; z-index: 999; }
        .menu-item { border-radius: 8px; transition: all 0.3s ease; font-weight: 500; cursor: pointer; }
        .menu-item:hover { background: linear-gradient(90deg, #00c6ff, #0072ff); padding-left: 15px; color: #fff !important; }
        .menu-item i { transition: transform 0.3s ease; }
        .menu-item:hover i { transform: scale(1.2); }
      `}</style>
    </>
  );
}

export default TravelPlannerHeader;