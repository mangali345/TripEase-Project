import React, { useEffect, useState } from 'react';
import TravelPlannerHeader from './TravelPlannerHeader';
import defaultProfilePic from "../../assets/mt.jpg";
import axios from 'axios';
import { useLocation } from 'react-router-dom';

function TravelPlannerHome() {

  const email = localStorage.getItem("travelplannerEmail");
  const location = useLocation();

  const APIURL = `http://localhost:9090/travelplanner/travelplannerProfile/${email}`;

  const [travelplannerData, setTravelPlannerData] = useState({ email:"",name: "", phone: "",company:"" });
  const [profilePic, setProfilePic] = useState(defaultProfilePic);

  useEffect(() => {

    const fetchData = async () => {

      try {

        const response = await axios.get(APIURL);

        setTravelPlannerData(response.data);

        let imageUrl = defaultProfilePic;

        if (location.state?.imageURL) {
          imageUrl = location.state.imageURL;
        }
        else if (response.data.profilePic) {
          imageUrl = `http://localhost:9090/uploads/tpprofileimages/${response.data.profilePic}`;
        }

        setProfilePic(imageUrl);

      } catch (error) {
        console.log("Error fetching admin data:", error);
      }

    };

    fetchData();

  }, []);

  return (
    <>
      <TravelPlannerHeader />

      <div style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "100vh",
        backgroundImage: "url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        position: "relative"
      }}>

        {/* Overlay */}
        <div style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          backgroundColor: "rgba(0,0,0,0.4)"
        }}></div>

        <div style={{
          background: "#fff",
          padding: "40px",
          borderRadius: "20px",
          width: "350px",
          textAlign: "center",
          boxShadow: "0 10px 25px rgba(0,0,0,0.2)",
          zIndex: 1
        }}>

          <img
            src={profilePic}
            alt="profile"
            style={{
              width: "130px",
              height: "130px",
              borderRadius: "50%",
              border: "4px solid #4facfe",
              objectFit: "cover",
              marginBottom: "15px"
            }}
          />

          <h2 style={{ marginBottom: "15px", color: "#333" }}>
            Hello {travelplannerData.name}
          </h2>

          <div style={{ color: "#555", fontSize: "15px" }}>
            <p style={{ margin: "8px 0" }}>
              <i className='fas fa-envelope' style={{ marginRight: "8px", color: "#4facfe" }}></i>
              {email}
            </p>

            <p style={{ margin: "8px 0" }}>
              <i className='fas fa-phone' style={{ marginRight: "8px", color: "#4facfe" }}></i>
              {travelplannerData.phone}
            </p>

            <p style={{ margin: "8px 0" }}>
              <i className='fas fa-building' style={{ marginRight: "8px", color: "#4facfe" }}></i>
              {travelplannerData.company}
            </p>
          </div>

        </div>
      </div>

    </>
  );
}

export default TravelPlannerHome;