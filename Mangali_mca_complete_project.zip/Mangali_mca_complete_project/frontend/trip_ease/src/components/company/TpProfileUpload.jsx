import React, { useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import TravelPlannerHeader from './TravelPlannerHeader'

function TpProfileUpload() {

    const navigate = useNavigate()
    const UPLOADURL = "http://localhost:9090/travelplanner/uploadPic"

    const [profilePic, setProfilePic] = useState(null)
    const email = localStorage.getItem("travelplannerEmail")

    const [profileData, setProfileData] = useState({
        email: email,
        description: ""
    })

    const fetchData = (e) => {

        const { name, value, files, type } = e.target

        if (type === "file") {
            setProfilePic(files[0])
        } else {
            setProfileData({ ...profileData, [name]: value })
        }
    }

    const submitForm = async (e) => {

        e.preventDefault()

        const formData = new FormData()

        formData.append(
            "profileImageDetail",
            new Blob([JSON.stringify(profileData)], { type: 'application/json' })
        )

        formData.append("imageFile", profilePic)

        try {

            const serverResponse = await axios.post(UPLOADURL, formData)

            navigate("/travelplannerhome", {
                state: { imageURL: serverResponse.data.imageURL }
            })

        }
        catch (err) {
            console.log(err)
        }
    }

    return (
        <>
            <TravelPlannerHeader />

            <div style={{
                minHeight: "100vh",
                backgroundImage: "url('https://images.unsplash.com/photo-1500530855697-b586d89ba3ee')",
                backgroundSize: "cover",
                backgroundPosition: "center",
                display: "flex",
                justifyContent: "center",
                alignItems: "center"
            }}>

                {/* Overlay */}
                <div style={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%",
                    backgroundColor: "rgba(0,0,0,0.5)"
                }}></div>

                <div style={{
                    position: "relative",
                    zIndex: 1,
                    width: "420px",
                    padding: "30px",
                    borderRadius: "20px",
                    background: "rgba(255,255,255,0.9)",
                    backdropFilter: "blur(10px)",
                    boxShadow: "0 10px 30px rgba(0,0,0,0.3)"
                }}>

                    <h3 style={{
                        textAlign: "center",
                        marginBottom: "20px",
                        fontWeight: "bold"
                    }}>
                        📸 Upload Profile Picture
                    </h3>

                    <form onSubmit={submitForm}>

                        <div style={{ marginBottom: "15px" }}>
                            <label style={{ fontWeight: "600" }}>
                                Select Image
                            </label>

                            <input
                                type="file"
                                accept="image/*"
                                name="profilePic"
                                className="form-control"
                                onChange={fetchData}
                                required
                                style={{
                                    marginTop: "5px",
                                    borderRadius: "10px",
                                    padding: "8px"
                                }}
                            />
                        </div>

                        <div style={{ marginBottom: "20px" }}>
                            <label style={{ fontWeight: "600" }}>
                                Description
                            </label>

                            <textarea
                                name="description"
                                className="form-control"
                                rows="4"
                                placeholder="Write something about your profile..."
                                onChange={fetchData}
                                value={profileData.description}
                                style={{
                                    marginTop: "5px",
                                    borderRadius: "10px",
                                    padding: "10px"
                                }}
                            />
                        </div>

                        <div style={{ textAlign: "center" }}>
                            <button
                                style={{
                                    background: "linear-gradient(45deg, #4facfe, #00f2fe)",
                                    border: "none",
                                    padding: "10px 25px",
                                    borderRadius: "25px",
                                    color: "#fff",
                                    fontWeight: "bold",
                                    cursor: "pointer"
                                }}
                            >
                                Upload Image
                            </button>
                        </div>

                    </form>

                </div>

            </div>
        </>
    )
}

export default TpProfileUpload;