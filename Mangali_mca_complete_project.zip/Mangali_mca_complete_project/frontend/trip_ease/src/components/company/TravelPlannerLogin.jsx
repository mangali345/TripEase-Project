import axios from "axios"
import { useNavigate } from "react-router-dom"
import React, { useState } from "react"
import Header from "../common/Header"
function TravelPlannerLogin()
{
  const navigate =useNavigate()
  
  const APIURL="http://localhost:9090/travelplanner/login"
    const [validate, setValidate] = useState(false)
    const [data, setData] = useState({
      email: "",
      password: ""
    })
    // Input change handle karne ke liye
  const fetchData = (e) => {
    setData({
      ...data, 
      [e.target.name]: e.target.value
    })
  }
  // Form submit function
  const submitForm = async (e) => {
    e.preventDefault()  

    const form = e.currentTarget
    if (!form.checkValidity()) {
      setValidate(true)
      return
    }
    try {
      const serverResponse = await axios.post(APIURL, data)
      console.log("Response from Spring Boot:", serverResponse)
      console.log("Response data:", serverResponse.data)
      const serverMessage= serverResponse.data

            if(serverMessage==="Login Successful")
      {
        //navigation or redirect to dashboard
        localStorage.setItem("travelplannerEmail",data.email)//it is built-in javascript object
        navigate("/travelplannerhome")
        

      }
      else{
        alert(serverMessage)
      }



      alert("Login successful!") 
    } catch(error) {
      console.log(error)
      alert("Login failed! Check console for details.")
    }
  }


    return(
        <>
        <Header/>
        <div className="container-fluid">
      <div className="row vh-100">

        {/* Left Side Image */}
        <div
          className="col-md-6 d-none d-md-block"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e')",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        ></div>

        {/* Right Side Form */}
        <div className="col-md-6 d-flex align-items-center justify-content-center bg-light">
          <div className="card shadow p-4" style={{ width: "350px" }}>
            <h3 className="text-center text-primary mb-4">
              Travel Planner Login
            </h3>

            <form onSubmit={submitForm} noValidate>
              {/* Email */}
              <div className="mb-3">
                <label className="form-label">Email</label>
                <input
                  type="email"
                  className="form-control"
                  placeholder="Enter your email"
                  required
                  name="email"
                  value={data.email}
                  onChange={fetchData}
                />
              </div>

              {/* Password */}
              <div className="mb-3">
                <label className="form-label">Password</label>
                <input
                  type="password"
                  className="form-control"
                  placeholder="Enter your password"
                  required
                  name="password"
                  value={data.password}
                  onChange={fetchData}
                />
              </div>

              {/* Button */}
              <div className="d-grid">
                <button type="submit" className="btn btn-primary">
                  Login
                </button>
              </div>
            </form>

          </div>
        </div>

      </div>
    </div>
        </>
    )
}
export default TravelPlannerLogin