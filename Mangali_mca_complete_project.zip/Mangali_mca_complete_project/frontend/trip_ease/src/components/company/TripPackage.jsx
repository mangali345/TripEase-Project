import React, { useState } from "react";
import TravelPlannerHeader from "./TravelPlannerHeader";
import axios from "axios";

function TripPackage() {

    const email = localStorage.getItem("travelplannerEmail");
    const APIURL = "http://localhost:9090/travelplanner/addTrip";

    const [data, setData] = useState({
        email: email,
        tripname: "",
        duration: "",
        charge: "",
        date: "",
        destination: "",
        description: ""
    });

    const [errors, setErrors] = useState({});

    const handleChange = (e) => {
        setData({
            ...data,
            [e.target.name]: e.target.value
        });
    };

    const validate = () => {
        let err = {};

        if (!data.tripname.trim()) err.tripname = "Trip name is required";
        if (!data.duration.trim()) err.duration = "Duration is required";

        if (!data.charge) {
            err.charge = "Charge is required";
        } else if (isNaN(data.charge) || data.charge <= 0) {
            err.charge = "Enter valid charge";
        }

        if (!data.date) err.date = "Date is required";

        setErrors(err);
        return Object.keys(err).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (validate()) {

            const sendData = {
                plannerEmail: data.email,
                tripName: data.tripname,
                destination: data.destination,
                duration: data.duration,
                chargeperPerson: parseInt(data.charge),
                description: data.description,
                tripDate: data.date
            };

            try {
                await axios.post(APIURL, sendData);
                alert("Trip Package Added Successfully 🚀");

                setData({
                    email: email,
                    tripname: "",
                    duration: "",
                    charge: "",
                    date: "",
                    destination: "",
                    description: ""
                });

            } catch (error) {
                console.error(error);
                alert("Server Error ❌");
            }
        }
    };

    return (
        <>
            <TravelPlannerHeader />

            <div style={{
                minHeight: "100vh",
                backgroundImage: "url('https://images.unsplash.com/photo-1528127269322-539801943592')", // 👈 NEW TRAVEL PACKAGE IMAGE
                backgroundSize: "cover",
                backgroundPosition: "center",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                position: "relative",
                padding: "90px"
            }}>

                {/* Overlay */}
                <div style={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%",
                    backgroundColor: "rgba(0,0,0,0.55)"
                }}></div>

                {/* Card */}
                <div style={{
                    width: "450px",
                    background: "rgba(255,255,255,0.92)",
                    backdropFilter: "blur(12px)",
                    padding: "30px",
                    borderRadius: "20px",
                    boxShadow: "0 10px 30px rgba(0,0,0,0.4)",
                    position: "relative",
                    zIndex: 1
                }}>

                    <h2 style={{
                        textAlign: "center",
                        marginBottom: "20px",
                        fontWeight: "bold",
                        color: "#333"
                    }}>
                        🧳 Add Trip Package
                    </h2>

                    <form onSubmit={handleSubmit}>

                        <input type="email" name="email" value={data.email} readOnly style={inputStyle} />

                        <input type="text" name="tripname" placeholder="Trip Name"
                            value={data.tripname} onChange={handleChange} style={inputStyle} />
                        <p style={errorStyle}>{errors.tripname}</p>

                        <input type="text" name="destination" placeholder="Destination"
                            value={data.destination} onChange={handleChange} style={inputStyle} />

                        <input type="text" name="duration" placeholder="Duration"
                            value={data.duration} onChange={handleChange} style={inputStyle} />
                        <p style={errorStyle}>{errors.duration}</p>

                        <input type="number" name="charge" placeholder="Charge per Person"
                            value={data.charge} onChange={handleChange} style={inputStyle} />
                        <p style={errorStyle}>{errors.charge}</p>

                        <input type="date" name="date"
                            value={data.date} onChange={handleChange} style={inputStyle} />
                        <p style={errorStyle}>{errors.date}</p>

                        <input type="text" name="description" placeholder="Description"
                            value={data.description} onChange={handleChange} style={inputStyle} />

                        <button type="submit" style={btnStyle}>
                            Add Package 🚀
                        </button>

                    </form>
                </div>
            </div>

           
        </>
    );
}

const inputStyle = {
    width: "100%",
    padding: "10px",
    margin: "8px 0",
    borderRadius: "10px",
    border: "1px solid #ccc",
    outline: "none"
};

const errorStyle = {
    color: "red",
    fontSize: "12px",
    margin: "0 0 5px 0"
};

const btnStyle = {
    width: "100%",
    padding: "12px",
    marginTop: "10px",
    background: "linear-gradient(45deg, #4facfe, #00f2fe)",
    color: "#fff",
    border: "none",
    borderRadius: "25px",
    fontWeight: "bold",
    cursor: "pointer"
};

export default TripPackage;