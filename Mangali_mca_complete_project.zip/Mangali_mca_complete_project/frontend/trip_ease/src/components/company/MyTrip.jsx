import React, { useEffect, useState } from 'react'
import axios from 'axios'
import TravelPlannerHeader from './TravelPlannerHeader'

function MyTrip() {
  const plannerEmail = localStorage.getItem("travelplannerEmail")
  const [packages, setPackages] = useState([])

  const APIURL = `http://localhost:9090/travelplanner/viewPackages/${plannerEmail}`

  useEffect(() => {
    const fetchTrips = async () => {
      try {
        const response = await axios.get(APIURL)
        setPackages(response.data)
      } catch (error) {
        console.error("Error fetching trips:", error)
      }
    }

    if (plannerEmail) {
      fetchTrips()
    }
  }, [plannerEmail])

  return (
    <>
      <TravelPlannerHeader />

      <div style={{
  minHeight: "100vh",
  backgroundImage: "url('https://images.unsplash.com/photo-1500530855697-b586d89ba3ee')", // 👈 NEW IMAGE
  backgroundSize: "cover",
  backgroundPosition: "center",
  backgroundAttachment: "fixed",
  paddingTop: "100px",
  paddingBottom: "40px",
  position: "relative"
}}>

        {/* Overlay */}
        <div style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          backgroundColor: "rgba(0,0,0,0.6)"
        }}></div>

        <div className="container" style={{ position: "relative", zIndex: 1 }}>

          <div className="text-center mb-5">
            <h2 style={{ fontWeight: "700", color: "#fff" }}>
              ✈️ Explore Travel Packages
            </h2>
            <p style={{ color: "#ddd" }}>
              Packages offered by <strong>{plannerEmail}</strong>
            </p>
          </div>

          <div className="row">
            {packages.length > 0 ? (
              packages.map((pkg, index) => {
                const tripDate = pkg.tripDate ? new Date(pkg.tripDate) : null
                const isActive = tripDate && tripDate >= new Date()

                return (
                  <div className="col-md-4 mb-4" key={index}>
                    <div style={{
                      borderRadius: "20px",
                      background: "rgba(255,255,255,0.95)",
                      backdropFilter: "blur(10px)",
                      boxShadow: "0 10px 30px rgba(0,0,0,0.3)",
                      padding: "20px",
                      textAlign: "center",
                      transition: "0.3s",
                      height: "100%"
                    }}>

                      <span style={{
                        background: "#0d6efd",
                        color: "#fff",
                        padding: "5px 12px",
                        borderRadius: "20px",
                        fontSize: "12px"
                      }}>
                        ✨ Premium Package
                      </span>

                      <h5 style={{
                        fontWeight: "bold",
                        color: "#0d6efd",
                        marginTop: "10px"
                      }}>
                        {pkg.tripName}
                      </h5>

                      {tripDate && (
                        isActive ? (
                          <p style={{ color: "green", fontWeight: "500" }}>
                            🟢 Booking Open
                          </p>
                        ) : (
                          <p style={{ color: "red", fontWeight: "500" }}>
                            🔴 Booking Expired
                          </p>
                        )
                      )}

                      <p>📍 <strong>{pkg.destination}</strong></p>

                      <p>⏳ {pkg.duration}</p>

                      <p>
                        📅 {
                          tripDate
                            ? tripDate.toLocaleDateString("en-IN")
                            : "N/A"
                        }
                      </p>

                      <h4 style={{ color: "green", margin: "10px 0" }}>
                        ₹{pkg.chargeperPerson} / Person
                      </h4>

                      <p style={{ fontSize: "14px", color: "#555" }}>
                        {pkg.description}
                      </p>

                    </div>
                  </div>
                )
              })
            ) : (
              <div className="text-center">
                <h5 style={{ color: "#fff" }}>No Packages Found 😔</h5>
              </div>
            )}
          </div>

        </div>
      </div>
    </>
  )
}

export default MyTrip;