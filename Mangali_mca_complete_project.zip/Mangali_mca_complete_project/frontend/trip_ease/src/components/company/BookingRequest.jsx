import React, { useEffect, useState } from "react";
import axios from "axios";
import Swal from "sweetalert2";
import TravelPlannerHeader from "./TravelPlannerHeader";

function BookingRequest() {

  const plannerEmail = localStorage.getItem("travelplannerEmail");  
  const APIURL = `http://localhost:9090/travelplanner/booking-requests/${plannerEmail}`;
  const UPDATEURL = "http://localhost:9090/travelplanner/update-booking-status";

  const [bookings, setBookings] = useState([]);

  // Fetch bookings
  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const response = await axios.get(APIURL);
        setBookings(response.data);
      } catch (error) {
        Swal.fire({
          title: "Error",
          text: "Unable to fetch booking requests",
          icon: "error"
        });
      }
    };
    fetchBookings();
  }, [APIURL]);

  // 🔥 UPDATED FUNCTION (instant UI update)
  const updateStatus = async (bookingId, newStatus) => {

    // ✅ instant UI update
    setBookings((prev) =>
      prev.map((b) =>
        b.bookingId === bookingId
          ? { ...b, bookingStatus: newStatus }
          : b
      )
    );

    try {
      await axios.put(`${UPDATEURL}/${bookingId}`, {
        bookingStatus: newStatus
      });

      Swal.fire({
        title: "Success",
        text: `Booking marked as ${newStatus}`,
        icon: "success"
      });

    } catch (error) {

      Swal.fire({
        title: "Error",
        text: "Update failed",
        icon: "error"
      });
    }
  };

  return (
    <>
      <TravelPlannerHeader/>

      {/* 🔥 PREMIUM UI CSS */}
      <style>{`
        body {
          background: linear-gradient(135deg, #ea66cbff, #584ba2ff);
        }

        .booking-request-page {
          padding: 40px;
          min-height: 100vh;
        }

        .booking-request-title {
          text-align: center;
          font-size: 32px;
          font-weight: bold;
          color: white;
          margin-bottom: 30px;
        }

        .booking-request-container {
          background: rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(15px);
          border-radius: 20px;
          padding: 25px;
          box-shadow: 0 8px 32px rgba(0,0,0,0.2);
        }

        .booking-request-table {
          width: 100%;
          border-collapse: collapse;
          color: white;
        }

        .booking-request-table thead {
          background: rgba(0,0,0,0.3);
        }

        .booking-request-table th {
          padding: 15px;
        }

        .booking-request-table td {
          padding: 14px;
        }

        .booking-request-table tbody tr:hover {
          background: rgba(255,255,255,0.15);
        }

        .trip-name {
          color: #00eaff;
          font-weight: bold;
        }

        .whatsapp-link {
          color: #25D366;
          font-weight: bold;
          text-decoration: none;
        }

        .status-badge {
          padding: 6px 14px;
          border-radius: 30px;
          font-size: 12px;
          font-weight: bold;
        }

        .pending { background: #ffc107; color: black; }
        .accepted { background: #28a745; color: white; }
        .rejected { background: #dc3545; color: white; }

        .action-buttons {
          display: flex;
          justify-content: center;
          gap: 6px;
        }

        .btn {
          border: none;
          padding: 7px 14px;
          border-radius: 20px;
          cursor: pointer;
          transition: 0.3s;
        }

        .accept { background: #28a745; color: white; }
        .reject { background: #dc3545; color: white; }
        .pending-btn { background: #ffc107; }

        .btn:hover {
          transform: scale(1.1);
        }

        .no-data {
          text-align: center;
          color: white;
        }
      `}</style>

      <div className="booking-request-page mt-4">
        <h3 className="booking-request-title">
          Booking Request Dashboard
        </h3>

        <div className="booking-request-container">
          {bookings.length === 0 ? (
            <p className="no-data">No booking requests available.</p>
          ) : (
            <table className="booking-request-table">
              <thead>
                <tr>
                  <th>User</th>
                  <th>WhatsApp No</th>
                  <th>Trip Name</th>
                  <th>Persons</th>
                  <th>Date</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                {bookings.map((booking) => (
                  <tr key={booking.bookingId}>
                    <td>{booking.userName}</td>

                    <td>
                      <a
                        href={`https://wa.me/+91${booking.whatsappNo}`}
                        target="_blank"
                        rel="noreferrer"
                        className="whatsapp-link"
                      >
                        {booking.whatsappNo}
                      </a>
                    </td>

                    <td className="trip-name">
                      {booking.tripPackage?.tripName}
                    </td>

                    <td>{booking.totalPerson}</td>

                    <td>
                      {new Date(booking.bookingRequestDate).toLocaleDateString()}
                    </td>

                    <td>
                      <span className={`status-badge ${booking.bookingStatus.toLowerCase()}`}>
                        {booking.bookingStatus}
                      </span>
                    </td>

                    <td className="action-buttons">
                      <button
                        className="btn accept"
                         onClick={() => updateStatus(booking.bookingId, "Accepted")}
                      >
                        Accept
                      </button>

                      <button
                        className="btn reject"
                        onClick={() => updateStatus(booking.bookingId, "Rejected")}
                      >
                        Reject
                      </button>
                    </td>

                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}

export default BookingRequest;