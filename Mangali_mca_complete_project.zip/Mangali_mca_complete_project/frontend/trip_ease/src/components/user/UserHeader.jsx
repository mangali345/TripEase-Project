import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

function UserHeader() {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();

  // Auto-redirect if user not logged in
  useEffect(() => {
    if (!localStorage.getItem("userEmail")) {
      navigate("/login/user");
    }
  }, [navigate]);

  // Logout function
  const logout = () => {
    const email = localStorage.getItem("userEmail");
    if (email) {
      localStorage.removeItem("userEmail"); // Clear user info
      navigate("/login/user"); // Redirect to login
    }
  };

  return (
    <>
      {/* Navbar */}
      <nav
        className="navbar navbar-dark fixed-top px-3"
        style={{ backgroundColor: "#4620cd", height: "60px" }}
      >
        <div className="container-fluid d-flex justify-content-between">
          <span className="navbar-brand mb-0 h5 text-white">User Dashboard</span>

          <button className="btn text-white" onClick={() => setIsOpen(!isOpen)}>
            <i className="fa-solid fa-bars fs-4"></i>
          </button>
        </div>
      </nav>

      {/* Sidebar */}
      <div
        className="user-sidebar"
        style={{
          right: isOpen ? "0" : "-250px",
        }}
      >
        {/* User Section */}
        <div className="text-center text-white mb-4">
          <i className="fa-solid fa-user-circle fs-1 mb-2"></i>
          <h6>Hello User</h6>
        </div>

        {/* Menu */}
        <ul className="nav flex-column px-3">
          

          <li className="nav-item mb-2">
            <Link
              to="/feed"
              className="nav-link menu-item text-white"
              onClick={() => setIsOpen(false)}
            >
              <i className="fa-solid fa-comment-dots me-2"></i> Feedback
            </Link>

          </li>

         
          <li className="nav-item mb-2">
            <Link
              to="/useredit"
              className="nav-link menu-item text-white"
              onClick={() => setIsOpen(false)}
            >
              <i className="fa-solid fa-user-pen me-2"></i> Edit Profile
            </Link>
          </li>
           <li className="nav-item mb-2">
            <Link
              to="/uimageupload"
              className="nav-link menu-item text-white"
              onClick={() => setIsOpen(false)}
            >
              <i className="fa-solid fa-upload me-2"></i>Profile Upload
            </Link>
          </li>
          <li className="nav-item mb-2">
            <Link
              to="/changeupass"
              className="nav-link menu-item text-white"
              onClick={() => setIsOpen(false)}
            >
              <i className="fa-solid fa-lock me-2"></i> Change Password
            </Link>
          </li>
          <li className="nav-item mb-2">
            <Link
              to="/alltp"
              className="nav-link menu-item text-white"
              onClick={() => setIsOpen(false)}
            >
              <i className="fa-solid fa-flag me-2"></i> All Travelplanner
            </Link>
          </li>
          <li className="nav-item mb-2">
            <Link
              to="/userroutepp"
              className="nav-link menu-item text-white"
              onClick={() => setIsOpen(false)}
            >
              <i className="fa-solid fa-route me-2"></i> Route Planner
            </Link>
          </li>
          <li className="nav-item mb-2">
            <Link
              to="/status"
              className="nav-link menu-item text-white"
              onClick={() => setIsOpen(false)}
            >
              <i className="fa-solid fa-spinner me-2"></i>Trip Status
            </Link>
          </li>

          {/* Logout */}
          <li className="nav-item">
            <button
              className="nav-link menu-item text-white"
              onClick={logout}
              style={{ border: "none", background: "none", padding: 0 }}
            >
              <i className="fa-solid fa-right-from-bracket me-2"></i> Logout
            </button>
          </li>
        </ul>
      </div>

      {/* Overlay */}
      {isOpen && (
        <div
          onClick={() => setIsOpen(false)}
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            backgroundColor: "rgba(0,0,0,0.3)",
            zIndex: 998,
          }}
        />
      )}

      {/* Styles */}
      <style>{`
        .user-sidebar {
          position: fixed;
          top: 0;
          width: 250px;
          height: 100vh;
          background-color: #4620cd;
          transition: right 0.3s ease;
          padding-top: 70px;
          z-index: 999;
        }

        .menu-item {
          border-radius: 6px;
          transition: all 0.3s ease;
        }

        .menu-item:hover {
          background-color: #3bb4ffff;
          transform: translateX(5px);
          color: #ffffff !important;
        }
      `}</style>
    </>
  );
}

export default UserHeader;