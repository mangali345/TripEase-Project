import React from "react"
 
import Header from "../common/Header"
import Footer from "../common/Footer"
import { useState } from "react";
import Swal from 'sweetalert2'
import axios from 'axios'



function UserReg(){
  const APIURL = "http://localhost:9090/registration"
  
    
  const[data, setData]=useState({name:"",email:"",phone:"",password:"",city:""})

   const [validate, setValidate]=useState(false)
   const fetchData=(e)=>{
    console.log(e.target); //object return
    const{name, value} = e.target //destructure name means control name

    const alphaRegex= /^[A-Za-z\s]*$/;
    const numberRegex= /^[0-9]*$/;


    if((name==="name") && !alphaRegex.test(value))
            {
            // alert("Only alphabets are allowed!");
    
            Swal.fire({
      title: "Format Error!!!",
      text: "input only alphabet",
      icon: "error"
    });
    
            
            return;
            }
            if((name==="phone") && !numberRegex.test(value))
            {
            // alert("Only digits are allowed!");
             Swal.fire({
      title: "Format Error!!!",
      text: "input only digit",
      icon: "error"
    });
            return;
            }
            setData({...data,[name]:value})
    
       }
    
         const submitForm= async(e)=>{
          e.preventDefault();
           // alert("in function")
           console.log(e.currentTarget);
           const form= e.currentTarget
           if (!form.checkValidity()) {
               e.preventDefault()
               e.stopPropagation()
             }
             setValidate(true)
            //  console.log(`name is ${data.name}`);
            //  console.log(`email is ${data.email}`);
            //  console.log(`phone is ${data.phone}`);
            //  console.log(`password is ${data.password}`);
            //  console.log(`city is ${data.city}`);
             try{
      const serverResponse=await axios.post(APIURL,data)
      console.log("send by spring boot"+serverResponse);
      console.log(serverResponse.data);
      
      

    }
    catch(error)
    {
      console.log(error);
      

    }
           
       
         }
         //code to check email existence
         const checkEmail=async(email)=>
         {
               const APIURLCheckEmail = `http://localhost:9090/user/checkEmail/${email}`
               try{
                       const serverResponse=await axios.get(APIURLCheckEmail)
                       console.log(serverResponse.data);
                       if(serverResponse.data==='exists'){
                        alert(email+"already exists please take another one")
                        document.getElementById("email").value=""
                       
                       }
               }
               catch(err)
               {
                console.log(err);
                
               }
         }

    return(
        <>
        <Header/>

    <div
      className="d-flex justify-content-center align-items-center vh-100"
      style={{ background: "linear-gradient(135deg, #667eea, #764ba2)" }}
    >
      <div
        className="card shadow-lg p-4"
        style={{ width: "100%", maxWidth: "450px", borderRadius: "20px" }}
      >
        <h3 className="text-center mb-4">Create Account</h3>

        <form onSubmit={submitForm}
        noValidate className={`needs-validation ${validate?'was-validated':''}`}>

          <div className="form-floating mb-3 position-relative">
            <i className="fa-solid fa-user position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
            <input
              type="text"
              className="form-control ps-5"
              id="name"
              placeholder="Full Name" required name="name"value={data.name}onChange={fetchData}
            />
            <label htmlFor="name" className="ms-4">Full Name</label>
            <div className="invalid-feedback">
                          Name Required
                            </div>
          </div>

          <div className="form-floating mb-3 position-relative">
            <i className="fa-solid fa-envelope position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
            <input
              type="email"
              className="form-control ps-5"
              id="email"
              placeholder="Email"required name="email"value={data.email}onChange={fetchData}
              onBlur={()=>{
                checkEmail(data.email)
              }}
              
            />
            <label htmlFor="email" className="ms-4">Email Address</label>
            <div className="invalid-feedback">
                          Email Required
                            </div>
          </div>

          <div className="form-floating mb-3 position-relative">
            <i className="fa-solid fa-phone position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
            <input
              type="tel"
              className="form-control ps-5"
              id="phone"
              placeholder="Phone"required name="phone"value={data.phone}onChange={fetchData}
            />
            <label htmlFor="phone" className="ms-4">Phone Number</label>
            <div className="invalid-feedback">
                          Phone Required
                            </div>
          </div>

          <div className="form-floating mb-3 position-relative">
            <i className="fa-solid fa-lock position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
            <input
              type="password"
              className="form-control ps-5"
              id="password"
              placeholder="Password" required name="password"value={data.password}onChange={fetchData}
            />
            <label htmlFor="password" className="ms-4">Password</label>
            <div className="invalid-feedback">
                          Password Required
                            </div>
          </div>

          <div className="form-floating mb-4 position-relative">
            <i className="fa-solid fa-city position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
            <select
              className="form-select ps-5"
              id="city" required name="city"value={data.city}onChange={fetchData}
            >
              <option value="">Select City</option>
              <option>Delhi</option>
              <option>Mumbai</option>
              <option>Lucknow</option>
              <option>Kolkata</option>
              <option>Bangalore</option>
            </select>
            <label htmlFor="city" className="ms-4">City</label>
            <div className="invalid-feedback">
                          City Required
                            </div>
          </div>

          <button type="submit" className="btn btn-primary w-100 py-2">
            <i className="fa-solid fa-user-plus me-2"></i>
            Register
          </button>

        </form>
      </div>
    </div>
  


        <Footer/>

       
        </>
    )
}
export default UserReg