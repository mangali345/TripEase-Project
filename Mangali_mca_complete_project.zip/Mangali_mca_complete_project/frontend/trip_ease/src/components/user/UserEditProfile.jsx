import axios from 'axios'
import { useEffect, useState } from 'react'
import UserHeader from './UserHeader'
import { ToastContainer, toast } from 'react-toastify'
import "react-toastify/dist/ReactToastify.css";
import { useNavigate } from 'react-router-dom';

function UserEditProfile() {

    const email = localStorage.getItem("userEmail")

    const APIURL = `http://localhost:9090/user/userProfile/${email}`
    const EDITAPIURL = `http://localhost:9090/user/editProfile/${email}`

    const [userdata, setUserdata] = useState({ name: "", phone: "" })
    const navigate = useNavigate()

    useEffect(() => {
        const fetchData = async () => {
            try {
                const serverResponse = await axios.get(APIURL)

                setUserdata({
                    name: serverResponse.data.name,
                    phone: serverResponse.data.phone
                })

            } catch (error) {
                console.log(error);
            }
        }

        fetchData()
    }, [APIURL])

    const submitData = async (e) => {
        e.preventDefault()
        try {
            const serverResponse = await axios.put(EDITAPIURL, userdata)

            toast.success("Profile Updated Successfully 😊")

            setTimeout(() => {
                navigate("/user/home")
            }, 3000)

        } catch (error) {
            console.log(error);
            toast.error("Failed to update profile 😔")
        }
    }

    const fillData = (e) => {
        setUserdata({ ...userdata, [e.target.name]: e.target.value })
    }

    return (
        <>
            <UserHeader />
            <ToastContainer position='top-center' autoClose={3000} />

            <div
                style={{
                    minHeight: "100vh",
                    paddingTop: "120px", // header gap fix
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "flex-start",
                    backgroundImage: "url('https://images.unsplash.com/photo-1496307042754-b4aa456c4a2d')",
                    backgroundSize: "cover",
                    backgroundPosition: "center"
                }}
            >
                {/* Overlay */}
                <div style={{
                    position: "fixed",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%",
                    background: "rgba(0,0,0,0.55)",
                    zIndex: 0
                }}></div>

                <div
                    style={{
                        position: "relative",
                        zIndex: 1,
                        width: "420px",
                        padding: "35px",
                        borderRadius: "20px",
                        background: "rgba(255,255,255,0.95)",
                        boxShadow: "0 20px 50px rgba(0,0,0,0.3)"
                    }}
                >
                    <h3
                        style={{
                            textAlign: "center",
                            marginBottom: "25px",
                            color: "#333",
                            fontWeight: "600"
                        }}
                    >
                        Edit Profile
                    </h3>

                    <form onSubmit={submitData}>

                        {/* Name */}
                        <div style={{ marginBottom: "20px" }}>
                            <label style={{ fontSize: "14px", color: "#555" }}>
                                Name
                            </label>
                            <input
                                type="text"
                                name="name"
                                value={userdata.name}
                                required
                                onChange={fillData}
                                style={{
                                    width: "100%",
                                    padding: "12px",
                                    borderRadius: "10px",
                                    border: "1px solid #ccc",
                                    marginTop: "5px"
                                }}
                            />
                        </div>

                        {/* Phone */}
                        <div style={{ marginBottom: "25px" }}>
                            <label style={{ fontSize: "14px", color: "#555" }}>
                                Phone
                            </label>
                            <input
                                type="text"
                                name="phone"
                                value={userdata.phone}
                                required
                                onChange={fillData}
                                style={{
                                    width: "100%",
                                    padding: "12px",
                                    borderRadius: "10px",
                                    border: "1px solid #ccc",
                                    marginTop: "5px"
                                }}
                            />
                        </div>

                        {/* Button */}
                        <button
                            type="submit"
                            style={{
                                width: "100%",
                                padding: "12px",
                                borderRadius: "10px",
                                border: "none",
                                background: "linear-gradient(135deg, #667eea, #764ba2)",
                                color: "#fff",
                                fontSize: "16px",
                                fontWeight: "600",
                                cursor: "pointer",
                                boxShadow: "0 8px 20px rgba(102,126,234,0.4)",
                                transition: "0.3s"
                            }}
                            onMouseOver={(e) =>
                                (e.target.style.transform = "scale(1.03)")
                            }
                            onMouseOut={(e) =>
                                (e.target.style.transform = "scale(1)")
                            }
                        >
                            Save Changes
                        </button>

                    </form>
                </div>
            </div>
        </>
    )
}

export default UserEditProfile;