import React, { useEffect, useState } from "react";
import axios from "axios";
import UserHeader from "./UserHeader";

function BookingtripStatus() {

  const userEmail = localStorage.getItem("userEmail");
  const APIURL = `http://localhost:9090/user/viewBooking/${userEmail}`;

  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    axios.get(APIURL)
      .then(res => setBookings(res.data))
      .catch(err => console.log(err));
  }, []);

  return (
    <>
    <UserHeader/>
      <style>{`
        body {
          margin: 0;
          font-family: 'Poppins', sans-serif;
          background: linear-gradient(135deg, #5f2c82, #49a09d);
        }

        .page {
          padding: 40px;
          min-height: 100vh;
        }

        .title {
          text-align: center;
          color: white;
          font-size: 34px;
          font-weight: bold;
          margin-bottom: 40px;
          letter-spacing: 1px;
        }

        .card-container {
          display: flex;
          flex-wrap: wrap;
          gap: 25px;
          justify-content: center;
        }

        .card {
          width: 320px;
          padding: 20px;
          border-radius: 20px;
          background: rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(15px);
          color: white;
          box-shadow: 0 10px 30px rgba(0,0,0,0.3);
          transition: 0.3s;
          position: relative;
          overflow: hidden;
        }

        .card:hover {
          transform: translateY(-10px) scale(1.02);
          box-shadow: 0 15px 40px rgba(0,0,0,0.4);
        }

        .card::before {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 5px;
          background: linear-gradient(90deg, #00f2fe, #4facfe);
        }

        .field {
          margin: 8px 0;
          font-size: 14px;
        }

        .label {
          font-weight: bold;
          color: #00eaff;
        }

        .status {
          padding: 5px 12px;
          border-radius: 20px;
          font-size: 12px;
          font-weight: bold;
          display: inline-block;
        }

        .accepted { background: #28a745; }
        .rejected { background: #dc3545; }
        .pending { background: #ffc107; color: black; }

        .response-box {
          margin-top: 8px;
          padding: 10px;
          border-radius: 10px;
          background: rgba(0,0,0,0.3);
          font-size: 13px;
        }

        .no-data {
          color: white;
          text-align: center;
          font-size: 18px;
        }
      `}</style>

      <div className="page mt-4">

        <div className="title">✨ My Booking Status</div>

        <div className="card-container">

          {bookings.length === 0 ? (
            <p className="no-data">No bookings found</p>
          ) : (
            bookings.map((b) => (
              <div key={b.bookingId} className="card">

                <div className="field">
                  <span className="label">👤 User:</span> {b.userEmail}
                </div>

                <div className="field">
                  <span className="label">🧑‍💼 Planner:</span> {b.plannerEmail}
                </div>

                <div className="field">
                  <span className="label">👥 Persons:</span> {b.totalPerson}
                </div>

                <div className="field">
                  <span className="label">📅 Date:</span>{" "}
                  {new Date(b.bookingRequestDate).toLocaleDateString()}
                </div>

                <div className="field">
                  <span className="label">📌 Status:</span>{" "}
                  <span className={`status ${b.bookingStatus.toLowerCase()}`}>
                    {b.bookingStatus}
                  </span>
                </div>

                <div className="field">
                  <span className="label">💬 Response:</span>
                  <div className="response-box">
                    {b.plannerResponse || "No response yet"}
                  </div>
                </div>

              </div>
            ))
          )}

        </div>
      </div>
    </>
  );
}

export default BookingtripStatus;