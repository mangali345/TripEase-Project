import React, { useEffect, useState } from 'react';
import UserHeader from './UserHeader';
import defaultProfilePic from "../../assets/mt.jpg";
import axios from 'axios';
import { useLocation } from 'react-router-dom';

function UserDashBoard() {

  const email = localStorage.getItem("userEmail");
  const location = useLocation();

  const APIURL = `http://localhost:9090/user/userProfile/${email}`;

  const [userData, setUserData] = useState({ name: "", phone: "" });
  const [profilePic, setProfilePic] = useState(defaultProfilePic);

  useEffect(() => {

    const fetchData = async () => {

      try {

        const response = await axios.get(APIURL);

        setUserData(response.data);

        let imageUrl = defaultProfilePic;

        if (location.state?.imageURL) {
          imageUrl = location.state.imageURL;
        }

        else if (response.data.profilePic) {
          imageUrl = `http://localhost:9090/uploads/userprofileimages/${response.data.profilePic}`;
        }

        setProfilePic(imageUrl);

      } catch (error) {
        console.log("Error fetching admin data:", error);
      }

    };

    fetchData();

  }, []);

  return (
    <>
      <UserHeader />

      <div style={{
        height: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        backgroundImage: "url('https://images.unsplash.com/photo-1503264116251-35a269479413')",
        backgroundSize: "cover",
        backgroundPosition: "center"
      }}>

        {/* Overlay for dark effect */}
        <div style={{
          position: "absolute",
          width: "100%",
          height: "100%",
          backgroundColor: "rgba(0,0,0,0.5)"
        }}></div>

        <div style={{
          position: "relative",
          background: "rgba(255,255,255,0.95)",
          padding: "40px 30px",
          borderRadius: "15px",
          textAlign: "center",
          width: "320px",
          boxShadow: "0 10px 25px rgba(0,0,0,0.3)",
          backdropFilter: "blur(8px)"
        }}>

          <img
            src={profilePic}
            alt="profile"
            style={{
              width: "130px",
              height: "130px",
              borderRadius: "50%",
              border: "4px solid #667eea",
              marginBottom: "15px",
              objectFit: "cover"
            }}
          />

          <h2 style={{ marginBottom: "10px", color: "#333" }}>
            Hello, {userData.name}
          </h2>

          <div style={{ marginTop: "10px" }}>
            <p style={{ margin: "8px 0", color: "#555" }}>
              <i className='fas fa-envelope' style={{ marginRight: "8px", color: "#667eea" }}></i>
              {email}
            </p>

            <p style={{ margin: "8px 0", color: "#555" }}>
              <i className='fas fa-phone' style={{ marginRight: "8px", color: "#667eea" }}></i>
              {userData.phone}
            </p>
          </div>

        </div>

      </div>

    </>
  );
}

export default UserDashBoard;