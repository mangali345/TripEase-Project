import React, { useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import UserHeader from "./UserHeader";

function BookTrips() {
  const { tripId, plannerEmail } = useParams(); 
  const email = localStorage.getItem("userEmail");


  const APIURL = "http://localhost:9090/user/bookTrip";

  const [data, setData] = useState({
    tripId: tripId,           
    plannerEmail: plannerEmail, 
    userEmail:  email,   
    userName: "",
    whatsappNo: "",
    totalPerson: "",
    userMessage: ""
  });

  const handleChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  const submitForm = async (e) => {
    e.preventDefault();

    if (!data.userEmail) {
      alert("User email not found! Login first.");
      return;
    }

    const sendData = {
      tripId: parseInt(data.tripId),
      plannerEmail: data.plannerEmail,
      userEmail: data.userEmail,
      userName: data.userName,
      whatsappNo: data.whatsappNo,
      totalPerson: parseInt(data.totalPerson),
      userMessage: data.userMessage,
      plannerResponse: "",
      bookingStatus: "pending",
      bookingRequestDate: new Date().toISOString() 
    };

    try {
      const res = await axios.post(APIURL, sendData);
      console.log("Response:", res.data);
      alert("Booking Successful ❤️");

      
      setData({ ...data, userName: "", whatsappNo: "", totalPerson: "", userMessage: "" });
    } catch (error) {
      console.log("ERROR:", error.response?.data || error);
      alert("Something went wrong ❌");
    }
  };

  return (
    <>
    <UserHeader/>


      <div
        className="container-fluid py-5 mt-5"
        style={{
          backgroundImage: "url('/trav2.jpg')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          minHeight: "100vh"
        }}
      >
        <div className="row justify-content-center">
          <div className="col-md-6">
            <div
              className="card shadow p-4 rounded-4"
              style={{ backgroundColor: "rgba(0,0,0,0.6)", color: "white" }}
            >
              <h2 className="text-center mb-4 fw-bold">Book Trip</h2>

              <form onSubmit={submitForm}>
                
                <input
                  className="form-control mb-3"
                  name="tripId"
                  value={data.tripId}
                  readOnly
                />
                <input
                  className="form-control mb-3"
                  name="plannerEmail"
                  value={data.plannerEmail}
                  readOnly
                />

                
                <input
                  className="form-control mb-3"
                  name="userEmail"
                  placeholder="User Email"
                  value={data.userEmail}
                  readOnly
                />
                <input
                  className="form-control mb-3"
                  name="userName"
                  placeholder="Your Name"
                  value={data.userName}
                  onChange={handleChange}
                  required
                />
                <input
                  className="form-control mb-3"
                  name="whatsappNo"
                  placeholder="WhatsApp No"
                  value={data.whatsappNo}
                  onChange={handleChange}
                  required
                />
                <input
                  className="form-control mb-3"
                  type="number"
                  name="totalPerson"
                  placeholder="Total Person"
                  value={data.totalPerson}
                  onChange={handleChange}
                  required
                />
                <textarea
                  className="form-control mb-3"
                  name="userMessage"
                  placeholder="Message"
                  value={data.userMessage}
                  onChange={handleChange}
                  required
                />

                <button className="btn btn-primary w-100">Book Now</button>
              </form>
            </div>
          </div>
        </div>
      </div>

      
    </>
  );
}

export default BookTrips;