import React, { useState } from "react";
import axios from "axios"
import { useNavigate } from "react-router-dom";
function TravelPlannerDetails({ companyArray }) {

  const navigate=useNavigate()
const [packagedata,setPackageData]=useState([{}])

  const showTrips=async(email)=>{

  alert(email)
  navigate(`/tripDetails/${email}`)

const emailId=email
const APIURL=`http://localhost:9090/user/showTrips/${emailId}`
//try catch here
try{
   const serverResponse=      await axios.get(APIURL)
    console.log(serverResponse.data);
    setPackageData(serverResponse.data)
}
catch(error)
{
  console.error(error)
}
    // const data=JSON.stringify(packagedata)
    // navigate("/tripDetails",{

    //   state:{tp:data}
    // })
     

  }
  return (
    <div className="container mt-4">
      
      {/* Heading */}
      <h3
        className="text-center mb-4"
        style={{
          fontWeight: "700",
          color: "#0d6efd",
          letterSpacing: "1px",
        }}
      >
        Company Details
      </h3>

      <div className="row">
        {companyArray.map((cobj, index) => {
          return (
            <div className="col-md-4 mb-4" key={index}>
              
              <div
                className="card h-100"
                style={{
                  borderRadius: "15px",
                  border: "none",
                  boxShadow: "0 10px 25px rgba(0,0,0,0.08)",
                }}
              >

                {/* Card Header */}
                <div
                  className="card-header text-white text-center"
                  style={{
                    background:
                      "linear-gradient(90deg,#0d6efd,#4dabf7)",
                    borderTopLeftRadius: "15px",
                    borderTopRightRadius: "15px",
                    fontWeight: "600",
                  }}
                >
                  {cobj.companyname}
                </div>

                {/* Card Body */}
                <div className="card-body">
                  <p>
                    <strong>Name:</strong> {cobj.name}
                  </p>

                  <p>
                    <strong>Email:</strong>{" "}
                    <span style={{ color: "#0d6efd" }}>
                      {cobj.email}
                    </span>
                  </p>

                  <p>
                    <strong>Phone:</strong> {cobj.phone}
                  </p>

                  <p>
                    <strong>City:</strong>{" "}
                    <span
                      style={{
                        background: "#e7f1ff",
                        padding: "4px 10px",
                        borderRadius: "15px",
                        color: "#0d6efd",
                        fontSize: "13px",
                      }}
                    >
                      {cobj.city}
                    </span>
                  </p>

                  <p>
                    <strong>Address:</strong> {cobj.address}
                  </p>

                  <p>
                    <strong>Registration No:</strong>{" "}
                    {cobj.registrationNo}
                  </p>
                </div>

                {/* Buttons */}
                <div className="card-footer text-center bg-white border-0 pb-3">
                  <button className="btn btn-primary me-2" onClick={()=>{

                      showTrips(cobj.email)

                  }}  >
                    viewPackages
                  </button>

                  {/* <a
                    href={`https://wa.me/91${cobj.phone}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-success"
                  >
                    WhatsApp
                  </a> */}
                  <a href={`https://wa.me/+91${cobj.phone}?text= hello}`}>Chat</a>
                </div>

              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default TravelPlannerDetails;