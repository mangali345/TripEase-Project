import UserHeader from './UserHeader'
import axios from 'axios'
import { useState } from 'react'
import { ToastContainer, toast } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'

function ChangeUserPassword() {
    const email = localStorage.getItem("userEmail")
    const EDITAPIURL = `http://localhost:9090/user/updatePassword/${email}`

    const [passwordData, setPasswordData] = useState({
        oldpass: "",
        newpass: "",
        confirmpass: ""
    })

    const fetchData = (e) => {
        setPasswordData({
            ...passwordData,
            [e.target.name]: e.target.value
        })
    }

    const submitData = (e) => {
        e.preventDefault()

        if (passwordData.newpass !== passwordData.confirmpass) {
            toast.error("New Password and Confirm Password must be same")
            return
        }

        axios.patch(EDITAPIURL, passwordData)
            .then((res) => {
                if (res.data === "success") {
                    toast.success("Password changed successfully!")
                    setPasswordData({ oldpass: "", newpass: "", confirmpass: "" })
                } else {
                    toast.error("Old password is incorrect. Please try again.")
                }
            })
            .catch((err) => {
                console.log(err)
                toast.error("Error updating password")
            })
    }

    return (
        <>
            <UserHeader />

            <ToastContainer position="top-center" autoClose={3000} />

            <div
                style={{
                    minHeight: "100vh",
                    paddingTop: "120px", // header gap fix
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "flex-start",
                    backgroundImage: "url('https://images.unsplash.com/photo-1555949963-aa79dcee981c')",
                    backgroundSize: "cover",
                    backgroundPosition: "center"
                }}
            >
                {/* Overlay */}
                <div style={{
                    position: "fixed",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%",
                    background: "rgba(0,0,0,0.6)",
                    zIndex: 0
                }}></div>

                <div
                    style={{
                        position: "relative",
                        zIndex: 1,
                        width: "400px",
                        padding: "35px",
                        borderRadius: "20px",
                        background: "rgba(255,255,255,0.95)",
                        boxShadow: "0 20px 50px rgba(0,0,0,0.3)"
                    }}
                >
                    <h3
                        style={{
                            textAlign: "center",
                            marginBottom: "25px",
                            color: "#333",
                            fontWeight: "600"
                        }}
                    >
                        Change Password
                    </h3>

                    <form onSubmit={submitData}>

                        {/* Old Password */}
                        <div style={{ marginBottom: "18px" }}>
                            <label style={{ fontSize: "14px", color: "#555" }}>
                                Old Password
                            </label>
                            <input
                                type="password"
                                name="oldpass"
                                value={passwordData.oldpass}
                                onChange={fetchData}
                                required
                                style={{
                                    width: "100%",
                                    padding: "12px",
                                    borderRadius: "10px",
                                    border: "1px solid #ccc",
                                    marginTop: "5px"
                                }}
                            />
                        </div>

                        {/* New Password */}
                        <div style={{ marginBottom: "18px" }}>
                            <label style={{ fontSize: "14px", color: "#555" }}>
                                New Password
                            </label>
                            <input
                                type="password"
                                name="newpass"
                                value={passwordData.newpass}
                                onChange={fetchData}
                                required
                                style={{
                                    width: "100%",
                                    padding: "12px",
                                    borderRadius: "10px",
                                    border: "1px solid #ccc",
                                    marginTop: "5px"
                                }}
                            />
                        </div>

                        {/* Confirm Password */}
                        <div style={{ marginBottom: "25px" }}>
                            <label style={{ fontSize: "14px", color: "#555" }}>
                                Confirm New Password
                            </label>
                            <input
                                type="password"
                                name="confirmpass"
                                value={passwordData.confirmpass}
                                onChange={fetchData}
                                required
                                style={{
                                    width: "100%",
                                    padding: "12px",
                                    borderRadius: "10px",
                                    border: "1px solid #ccc",
                                    marginTop: "5px"
                                }}
                            />
                        </div>

                        {/* Button */}
                        <button
                            type="submit"
                            style={{
                                width: "100%",
                                padding: "12px",
                                borderRadius: "10px",
                                border: "none",
                                background: "linear-gradient(135deg, #667eea, #764ba2)",
                                color: "#fff",
                                fontSize: "16px",
                                fontWeight: "600",
                                cursor: "pointer",
                                boxShadow: "0 8px 20px rgba(102,126,234,0.4)",
                                transition: "0.3s"
                            }}
                            onMouseOver={(e) =>
                                (e.target.style.transform = "scale(1.03)")
                            }
                            onMouseOut={(e) =>
                                (e.target.style.transform = "scale(1)")
                            }
                        >
                            Update Password
                        </button>

                    </form>
                </div>
            </div>
        </>
    )
}

export default ChangeUserPassword;