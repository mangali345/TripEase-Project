import React, { useState } from "react";
import UserHeader from "./UserHeader";
import axios from "axios";

function Feedback() {
  const APIURL = "http://localhost:9090/user/feedback";

  const email = localStorage.getItem("userEmail");

  const [data, setData] = useState({
    email: "",
    review: "",
    rating: 0
  });

  const fetchData = (e) => {
    setData({
      ...data,
      [e.target.name]: e.target.value
    });
  };

  const submitForm = async (e) => {
    e.preventDefault();

    try {
      const serverResponse = await axios.post(APIURL, data);
      console.log("Response:", serverResponse.data);

      alert("Feedback Submitted Successfully ❤️");

      setData({
        email: "",
        review: "",
        rating: 0
      });

    } catch (error) {
      console.log("Error:", error);
      alert("Something went wrong ❌");
    }
  };

  return (
    <>
    <UserHeader/>
      <div
        style={{
          minHeight: "100vh",
          paddingTop: "120px", // ✅ header se gap
          paddingBottom: "50px",
          display: "flex",
          justifyContent: "center",
          alignItems: "flex-start",
          backgroundImage: "url('https://images.unsplash.com/photo-1522202176988-66273c2fd55f')",
          backgroundSize: "cover",
          backgroundPosition: "center"
        }}
      >
        {/* Overlay */}
        <div style={{
          position: "fixed",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          background: "rgba(0,0,0,0.5)",
          zIndex: 0
        }}></div>

        <div
          style={{
            position: "relative",
            zIndex: 1,
            width: "420px",
            padding: "35px",
            borderRadius: "18px",
            background: "rgba(255,255,255,0.95)",
            boxShadow: "0 15px 40px rgba(0,0,0,0.3)",
            textAlign: "center"
          }}
        >
          <h2 style={{ marginBottom: "8px", color: "#333" }}>
            Feedback
          </h2>

          <p style={{ fontSize: "14px", color: "#666", marginBottom: "20px" }}>
            Tell us about your experience
          </p>

          <form onSubmit={submitForm}>

            {/* Email */}
            <div style={{ marginBottom: "15px", textAlign: "left" }}>
              <label style={{ fontSize: "14px" }}>Email</label>
              <input
                type="email"
                name="email"
                value={email}
                readOnly
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid #ccc",
                  marginTop: "5px",
                  background: "#f5f5f5"
                }}
              />
            </div>

            {/* Review */}
            <div style={{ marginBottom: "15px", textAlign: "left" }}>
              <label style={{ fontSize: "14px" }}>Review</label>
              <textarea
                name="review"
                value={data.review}
                onChange={fetchData}
                rows="4"
                placeholder="Write your feedback..."
                required
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: "8px",
                  border: "1px solid #ccc",
                  marginTop: "5px",
                  resize: "none"
                }}
              ></textarea>
            </div>

            {/* Rating */}
            <div style={{ marginBottom: "18px" }}>
              <label style={{ display: "block", marginBottom: "6px" }}>
                Rating
              </label>

              {[1, 2, 3, 4, 5].map((star) => (
                <span
                  key={star}
                  onClick={() =>
                    setData({
                      ...data,
                      rating: star
                    })
                  }
                  style={{
                    fontSize: "32px",
                    cursor: "pointer",
                    color: star <= data.rating ? "#ffb400" : "#ccc",
                    margin: "0 3px"
                  }}
                >
                  ★
                </span>
              ))}
            </div>

            {/* Submit */}
            <button
              type="submit"
              style={{
                width: "100%",
                padding: "11px",
                borderRadius: "8px",
                border: "none",
                background: "#667eea",
                color: "#fff",
                fontWeight: "600",
                cursor: "pointer"
              }}
            >
              Submit Feedback
            </button>

          </form>
        </div>
      </div>

      
    </>
  );
}

export default Feedback;