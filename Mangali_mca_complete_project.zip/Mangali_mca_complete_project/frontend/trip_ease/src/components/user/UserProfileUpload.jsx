import React, { useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import UserHeader from './UserHeader'

function UserProfileUpload() {

    const navigate = useNavigate()
    const UPLOADURL = "http://localhost:9090/user/uploadPic"

    const [profilePic, setProfilePic] = useState(null)
    const email = localStorage.getItem("userEmail")

    const [profileData, setProfileData] = useState({
        email: email,
        description: ""
    })

    const fetchData = (e) => {

        const { name, value, files, type } = e.target

        if (type === "file") {
            setProfilePic(files[0])
        } else {
            setProfileData({ ...profileData, [name]: value })
        }
    }

    const submitForm = async (e) => {

        e.preventDefault()

        const formData = new FormData()

        formData.append(
            "profileImageDetail",
            new Blob([JSON.stringify(profileData)], { type: 'application/json' })
        )

        formData.append("imageFile", profilePic)

        try {

            const serverResponse = await axios.post(UPLOADURL, formData)

            navigate("/userDashBoard", {
                state: { imageURL: serverResponse.data.imageURL }
            })

        }
        catch (err) {
            console.log(err)
        }
    }

    return (
        <>
            <UserHeader />

            <div
                style={{
                    minHeight: "100vh",
                    paddingTop: "120px", // header gap fix
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "flex-start",
                    backgroundImage: "url('https://images.unsplash.com/photo-1508780709619-79562169bc64')",
                    backgroundSize: "cover",
                    backgroundPosition: "center"
                }}
            >
                {/* Overlay */}
                <div style={{
                    position: "fixed",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%",
                    background: "rgba(0,0,0,0.55)",
                    zIndex: 0
                }}></div>

                <div
                    style={{
                        position: "relative",
                        zIndex: 1,
                        width: "450px",
                        padding: "35px",
                        borderRadius: "20px",
                        background: "rgba(255,255,255,0.95)",
                        boxShadow: "0 20px 50px rgba(0,0,0,0.3)"
                    }}
                >

                    <h3
                        style={{
                            textAlign: "center",
                            marginBottom: "25px",
                            color: "#333",
                            fontWeight: "600"
                        }}
                    >
                        Upload Profile Picture
                    </h3>

                    <form onSubmit={submitForm}>

                        {/* Image Upload */}
                        <div style={{ marginBottom: "20px" }}>
                            <label style={{ fontWeight: "600", fontSize: "14px" }}>
                                Select Image
                            </label>

                            <input
                                type="file"
                                accept="image/*"
                                name="profilePic"
                                onChange={fetchData}
                                required
                                style={{
                                    width: "100%",
                                    padding: "10px",
                                    marginTop: "6px",
                                    borderRadius: "10px",
                                    border: "1px solid #ccc",
                                    background: "#f9f9f9"
                                }}
                            />
                        </div>

                        {/* Description */}
                        <div style={{ marginBottom: "25px" }}>
                            <label style={{ fontWeight: "600", fontSize: "14px" }}>
                                Description
                            </label>

                            <textarea
                                name="description"
                                rows="4"
                                placeholder="Write something about your profile..."
                                onChange={fetchData}
                                value={profileData.description}
                                style={{
                                    width: "100%",
                                    padding: "12px",
                                    marginTop: "6px",
                                    borderRadius: "10px",
                                    border: "1px solid #ccc",
                                    resize: "none"
                                }}
                            />
                        </div>

                        {/* Button */}
                        <button
                            style={{
                                width: "100%",
                                padding: "12px",
                                borderRadius: "10px",
                                border: "none",
                                background: "linear-gradient(135deg, #667eea, #764ba2)",
                                color: "#fff",
                                fontSize: "16px",
                                fontWeight: "600",
                                cursor: "pointer",
                                boxShadow: "0 8px 20px rgba(102,126,234,0.4)",
                                transition: "0.3s"
                            }}
                            onMouseOver={(e) =>
                                (e.target.style.transform = "scale(1.03)")
                            }
                            onMouseOut={(e) =>
                                (e.target.style.transform = "scale(1)")
                            }
                        >
                            Upload Image
                        </button>

                    </form>

                </div>

            </div>
        </>
    )
}

export default UserProfileUpload