import React, { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import axios from 'axios'
import UserHeader from './UserHeader'
import Footer from '../common/Footer'

function TripDetails() {

  const { emailId } = useParams()
  const navigate = useNavigate()

  const APIURL = `http://localhost:9090/user/showTrips/${emailId}`

  const [data, setData] = useState([])

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get(APIURL)
        console.log("DATA:", res.data)
        setData(res.data)
      } catch (err) {
        console.log(err)
      }
    }
    fetchData()
  }, [emailId])


  //userTrips 

  const     userTrips=(id,plannerEmail)=>{


    alert(id+plannerEmail)

    navigate(`/bookTrips/${id}/${plannerEmail}`)

  }

  return (
    <>
      <div className="main-bg">

        <UserHeader/>

        <div className="container mt-5 text-center">

          {/* ✈️ INTERACTIVE HEADING */}
          <h2 className="trip-heading mb-5 mt-5">
            ✈️ All Trips of <span className="email-text">{emailId}</span>
          </h2>

          <div className="row justify-content-center">

            {!Array.isArray(data) || data.length === 0 ? (
              <h5 className="text-warning">No trips found</h5>
            ) : (
              data.map((trip, index) => (
                <div 
                  className="col-lg-4 col-md-6 col-sm-10 mb-4 d-flex justify-content-center"
                  key={trip.id || index}
                >

                  <div className="card trip-card text-center">

                    <div className="card-body">

                      <h5 className="card-title text-white mb-3">
                        {trip.tripName}
                      </h5>

                      <p className="card-text text-light">
                        <strong>Destination:</strong> {trip.destination}
                      </p>

                      <p className="card-text text-light">
                        <strong>Duration:</strong> {trip.duration}
                      </p>

                      <p className="card-text fw-bold text-warning fs-5">
                        ₹{trip.chargeperPerson}
                      </p>

                      <p className="card-text text-light">
                        📅{new Date(trip.tripDate).toLocaleDateString("en-IN",{
                          day:"numeric",
                          month:"short",
                          year:"numeric"
                        })

                        }
                      </p>

                      {/* ✅ UPDATED BUTTON */}
                      <button 
                        className="card-footer text-center bg-white border-0 pb-3 w-100 mt-2"
                        onClick={() => {


                            // navigate("/bookTrips")
                        userTrips(trip.id,trip.plannerEmail)
                        }}
                      >
                        Book Now
                      </button>

                    </div>

                  </div>

                </div>
              ))
            )}

          </div>

          {/* 🎨 Styling */}
          <style>
            {`
              /* 🌍 Background */
              .main-bg {
                min-height: 100vh;
                background: linear-gradient(
                    rgba(0, 0, 0, 0.45),
                    rgba(0, 0, 0, 0.45)
                  ),
                  url("https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1600&q=60");
                background-size: cover;
                background-position: center;
                background-repeat: no-repeat;
              }

              /* ✈️ Heading */
              .trip-heading {
                font-size: 2.5rem;
                font-weight: 800;
                letter-spacing: 1px;
                color: #fff;
                position: relative;
                display: inline-block;
                padding-bottom: 10px;
              }

              .email-text {
                background: linear-gradient(45deg, #4e73df, #1cc88a);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                font-weight: bold;
                transition: all 0.3s ease;
              }

              .email-text:hover {
                text-shadow: 0px 0px 10px rgba(28, 200, 138, 0.9);
                transform: scale(1.05);
              }

              .trip-heading::after {
                content: "";
                width: 60%;
                height: 4px;
                background: linear-gradient(90deg, #4e73df, #1cc88a);
                position: absolute;
                left: 20%;
                bottom: 0;
                border-radius: 5px;
                transition: width 0.4s ease;
              }

              .trip-heading:hover::after {
                width: 100%;
                left: 0;
              }

              /* 💎 Cards */
              .trip-card {
                width: 100%;
                max-width: 300px;
                background: linear-gradient(135deg, #4e73df, #1cc88a);
                border-radius: 15px;
                transition: transform 0.3s ease, box-shadow 0.3s ease;
                padding: 10px;
              }

              .trip-card:hover {
                transform: translateY(-10px) scale(1.03);
                box-shadow: 0 10px 25px rgba(0,0,0,0.4);
              }

              /* Button hover */
              .trip-card button:hover {
                background-color: #f8f9fa;
                font-weight: bold;
              }
            `}
          </style>

        </div>

      </div>

      <Footer/>
    </>
  )
}

export default TripDetails