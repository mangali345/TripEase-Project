import React, { useState } from "react";
import Header from "../common/Header";
import Footer from "../common/Footer";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function User() {
  const navigate = useNavigate();

  const APIURL = "http://localhost:9090/user/login";
  const [validate, setValidate] = useState(false);
  const [data, setData] = useState({
    email: "",
    password: "",
  });

  const fetchData = (e) => {
    setData({
      ...data,
      [e.target.name]: e.target.value,
    });
  };

  const submitForm = async (e) => {
    e.preventDefault();

    const form = e.currentTarget;
    if (!form.checkValidity()) {
      setValidate(true);
      return;
    }

    try {
      const serverResponse = await axios.post(APIURL, data);
      const serverMessage = serverResponse.data;

      if (serverMessage === "Login Successful") {
        localStorage.setItem("userEmail", data.email);
        navigate("/userdashboard");
      } else {
        alert(serverMessage);
      }

      alert("Login successful!");
    } catch (error) {
      console.log(error);
      alert("Login failed! Check console for details.");
    }
  };

  // 🔥 Styles (same file)
  const styles = {
    container: {
      minHeight: "100vh",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      background: "linear-gradient(135deg, #f5f7fa, #c3cfe2)",
    },
    card: {
      display: "flex",
      width: "850px",
      background: "#fff",
      borderRadius: "12px",
      boxShadow: "0 10px 25px rgba(0,0,0,0.15)",
      overflow: "hidden",
    },
    imageSection: {
      flex: 1,
      background: "#eee",
    },
    image: {
      width: "100%",
      height: "100%",
      objectFit: "cover",
    },
    formSection: {
      flex: 1,
      padding: "40px",
      textAlign: "center",
    },
    input: {
      width: "100%",
      padding: "12px",
      marginBottom: "20px",
      borderRadius: "6px",
      border: "1px solid #ccc",
      outline: "none",
      fontSize: "14px",
    },
    button: {
      width: "100%",
      padding: "12px",
      background: "#ff9800",
      color: "#fff",
      border: "none",
      borderRadius: "6px",
      fontWeight: "bold",
      cursor: "pointer",
    },
    subtitle: {
      fontSize: "14px",
      color: "gray",
      marginBottom: "20px",
    },
    extra: {
      marginTop: "15px",
      fontSize: "13px",
      color: "#555",
    },
  };

  return (
    <>
      <Header />

      <div style={styles.container}>
        <div style={styles.card}>
          
          {/* Image */}
          <div style={styles.imageSection}>
            <img src="/hii.jpg" alt="login" style={styles.image} />
          </div>

          {/* Form */}
          <div style={styles.formSection}>
            <h2>User Login</h2>
            <p style={styles.subtitle}>
              Welcome back! Please login to continue
            </p>

            <form onSubmit={submitForm} noValidate>
              <input
                type="email"
                placeholder="Enter your email"
                required
                name="email"
                value={data.email}
                onChange={fetchData}
                style={styles.input}
              />

              <input
                type="password"
                placeholder="Enter your password"
                required
                name="password"
                value={data.password}
                onChange={fetchData}
                style={styles.input}
              />

              <button type="submit" style={styles.button}>
                Login
              </button>
            </form>

            <div style={styles.extra}>
              Forgot Password? | Create Account
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}
export default User;