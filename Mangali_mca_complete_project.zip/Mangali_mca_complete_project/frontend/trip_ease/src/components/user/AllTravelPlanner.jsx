import React, { useState, useEffect } from "react";
import UserHeader from "../user/UserHeader";
import axios from "axios";
import TravelPlannerDetails from "./TravelPlannerDetails";

function AllTravelPlanner() {

  const APIURL = "http://localhost:9090/user/allTravelPlanner";

  const [companydata, setCompanyData] = useState([]);

  useEffect(() => {

    const fetchData = async () => {
      try {
        const serverResponse = await axios.get(APIURL);
        console.log(serverResponse.data);

        setCompanyData(serverResponse.data); // store array
      } catch (error) {
        console.log(error);
      }
    };

    fetchData();

  }, []);

  return (
    <>
      <UserHeader />
      <TravelPlannerDetails companyArray={companydata} />
    </>
  );
}

export default AllTravelPlanner;